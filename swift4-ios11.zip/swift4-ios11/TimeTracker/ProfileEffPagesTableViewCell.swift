//
//  ProfileEffPagesTableViewCell.swift
//  TimeTracker
//
//  Created by Anton on 22/12/2016.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class ProfileEffPagesTableViewCell: UITableViewCell, UIPageViewControllerDataSource {

    var profilePresenter: ProfilePresenter? {didSet {setupPageViewController()}}
    
    var pageViewControllerWasSetUp: Bool = false
    
    var effPageViewController = UIPageViewController(transitionStyle: UIPageViewControllerTransitionStyle.scroll, navigationOrientation: UIPageViewControllerNavigationOrientation.horizontal, options: nil)
    
    
    
    func handleRefresh() {
        pageViewControllerWasSetUp = false
        setupPageViewController()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code

        //setupPageViewController()
        self.effPageViewController.view.frame = self.frame
        self.addSubview(self.effPageViewController.view)
    }
    
    func setupPageViewController() {
        
        if profilePresenter?.userId != nil && !pageViewControllerWasSetUp {
        
            
            /////////// Setting up Page View Controller ///////////
            effPageViewController.dataSource = self
            
            let initialContentViewController = effPageAtIndex(0)
            var viewControllers = [Any]()
            viewControllers.append(initialContentViewController as Any)
            
            effPageViewController.setViewControllers(viewControllers as? [UIViewController], direction: .forward, animated: false, completion: nil)

            
            pageViewControllerWasSetUp = true
        
        }
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    
    
    // Scroll page left
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        let viewController = viewController as! StatisticsViewController
        var index = viewController.presenter.index as Int

        index -= 1
        
        return effPageAtIndex(index)
    }
    
    
    // Scroll page right
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        let viewController = viewController as! StatisticsViewController
        var index = viewController.presenter.index as Int
        
        index += 1
        
        return effPageAtIndex(index)
    }
    
    func effPageAtIndex(_ index: Int) -> StatisticsViewController? {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "Statistics View Controller") as! StatisticsViewController
        viewController.presenter.index = index
        viewController.presenter.profilePresenter = profilePresenter

        return viewController
  
    }
    

}
