//
//  CalendarTableViewCell.swift
//  TimeTracker
//
//  Created by Anton on 22/06/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class CalendarTableViewCell: UITableViewCell {
    
    var loggedUserRole: LoggedUserRole {
        return TimeTracker.data.loggedUserRole
    }


    @IBOutlet weak var eventTitle: UILabel!
    @IBOutlet weak var eventLessonNumber: UILabel!
    @IBOutlet weak var eventStartingTime: UILabel!
    @IBOutlet weak var eventEndingTime: UILabel!
    @IBOutlet weak var eventType: UILabel!
    @IBOutlet weak var eventLessonGroup: UILabel!
    @IBOutlet weak var eventLessonComment: UILabel!
    @IBOutlet weak var eventRoomNumber: UILabel!
    @IBOutlet weak var eventColorBar: UIView!
    @IBOutlet weak var eventExamType: UILabel!
    

    @IBOutlet weak var line1pxConstraint: NSLayoutConstraint!
    
    var event = TimeTableEvent() {
        didSet {
            updateUI()
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        updateUI()
        
        
        
        line1pxConstraint.constant = 1/UIScreen.main.scale

        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        

    }

    
    fileprivate func updateUI()
    {
        
        // Clear all labels
        eventLessonNumber?.text = nil
        eventStartingTime?.text = nil
        eventEndingTime?.text = nil
        eventType?.text = nil
        eventTitle?.text = nil
        eventLessonGroup?.text = nil
        eventLessonComment?.text = nil
        eventRoomNumber?.text = nil
 
        // Updating labels
        
        /* // Закоменчено тк решили не использовать номера пар вообще
        let lessonNumber = event.lessonNumber ?? 0
        var lessonNumberText = ""
        if (lessonNumber > 0) {lessonNumberText = String(lessonNumber) + " пара"}
        eventLessonNumber?.text = lessonNumberText
        */
        
        eventLessonNumber = nil
        
        eventStartingTime?.text = contvertTimeToString(event.startingTime)
        eventEndingTime?.text = contvertTimeToString(event.endingTime)
        
        if event.typeName != "" {
            eventType?.text = event.typeName
        }
        else {
            eventType?.text = "Занятие"
        }
        
        eventTitle?.text = event.title
        eventLessonComment?.text = event.lessonComment
        if (event.roomNumber != nil) {
            if (event.roomNumber! != "") {eventRoomNumber?.text = "ауд. " + event.roomNumber!}
        }
        
        
        ////////////////////////////////////////////////////////
        ////////                                         ///////
        ////////        GROUPS OR TEACHER ON LESSON      ///////
        ////////                                         ///////
        ////////////////////////////////////////////////////////
        
        
        if  (LoadedData.timeTable.viewPersonId == event.lessonTutor?.id) || (event.categoty == .prosmotr) {
        
            /// Setting Label
            eventLessonGroup?.attributedText = makeEventGroupString(event.lessonGroups)
            
        }
        else {
            
            /// Setting Label
            eventLessonGroup?.attributedText = makeEventTutorString(event.lessonTutor)

        }

        
        
            
            
            
            
        
        if (event.typeColor != nil) {
            eventColorBar?.backgroundColor = UIColor(hexString: event.typeColor!)
        }
        
        if (event.categoty == .exam) {
            eventExamType?.text = "ЭКЗАМЕН"
        }

        if (event.categoty == .prosmotr) {
            eventExamType?.text = "ПРОСМОТР"
        }
        
        //eventLessonComment?.text = contvertDateToString(event.date)
        //eventLessonComment?.text = String(event.id)

    }
}

