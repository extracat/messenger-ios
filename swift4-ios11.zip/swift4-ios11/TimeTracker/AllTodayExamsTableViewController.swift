//
//  AllTodayExamsTableViewController.swift
//  TimeTracker
//
//  Created by Anton on 13/06/2017.
//  Copyright © 2017 HSE. All rights reserved.
//

import UIKit

class AllTodayExamsPresenter {
    weak private var myView : AllTodayExamsTableViewController?
    
    var callbackStatus = CallbackStatus.pending
    
    func attachView(view:AllTodayExamsTableViewController){
        myView = view
    }
    
    func detachView() {
        myView = nil
    }
    
    func updateTableData() {

        myView?.events.removeAll()
        for event in events {
            if event.categoty == .prosmotr {
                myView?.events.append(event)
            }
        }
        
        myView?.tableView.reloadData()
    }
    
    var events = [TimeTableEvent]()
    
    
    func refreshTableData() {
        loadTableData(needToRefresh: true)
    }
    
    func loadTableData(needToRefresh: Bool = false) {
        
        callbackStatus = TimeTracker.data.getEvents(startDate: Date(), endDate: Date().addDays(1), completionHandler: updateEvents)
    }
    
    
    func updateEvents(newEvents: [TimeTableEvent]?, requestStatus: RequestStatus) {
 
        
        //// Analysing Callback
        switch requestStatus {
            
        case .success:
            //// If request was successful
            
            self.events.removeAll()
            callbackStatus = .noData
            
            if newEvents != nil {
                events = newEvents!
                callbackStatus = .alreadyLoaded
            }
            else {
                callbackStatus = .noData
            }

            updateTableData()

            
        case .error(let errorMsg):
            //// If there was an error
            
            self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
            
        }
        
        
        }
    
}




class AllTodayExamsTableViewController: UITableViewController {

    var events = [TimeTableEvent]()
    
    let presenter = AllTodayExamsPresenter()
    
    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
        
        presenter.refreshTableData()
        refreshControl.endRefreshing()
        
    }
    
    
    func alert(title: String, message: String, action: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: action, style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter.attachView(view: self)
        
        self.tableView.estimatedRowHeight = 44.0
        self.tableView.rowHeight = UITableViewAutomaticDimension
        
        // Loading DATA
        presenter.loadTableData()
        
        // Refresher
        self.refreshControl?.addTarget(self, action: #selector(AllTodayExamsTableViewController.handleRefresh(_:)), for: UIControlEvents.valueChanged)
        

    }
    
    
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        let count = events.count
        if count > 0 {return count}
        else {return 1}
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
         self.navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     
        
        var cell = UITableViewCell()
        
        let count = events.count
        if count > 0 {
            
            let thisCellEvent = events[indexPath.row]

            
/////////////////////////////////////////////////////////
// Временно все можно

thisCellEvent.userCanReadSheet = true
thisCellEvent.userCanEditSheet = true

/////////////////////////////////////////////////////////

            
            self.tableView.estimatedRowHeight = 44.0
            self.tableView.rowHeight = UITableViewAutomaticDimension
            
            cell = tableView.dequeueReusableCell(withIdentifier: "Prosmotr Cell", for: indexPath)

            // Configure the cell...
            
            if let thisCell = cell as? CalendarTableViewCell {
                thisCell.event = thisCellEvent // SENDING MODEL DATA TO CELL
                if (!thisCellEvent.userCanReadSheet) {
                    thisCell.accessoryType = .none
                    thisCell.selectionStyle = .none
                } else {
                    thisCell.accessoryType = .disclosureIndicator
                    thisCell.selectionStyle = .default
                }

            }

        }
            
        else {
            
            if presenter.callbackStatus == .pending {
                cell = tableView.dequeueReusableCell(withIdentifier: "Loading Prosmotr", for: indexPath)
            }
            else {
                cell = tableView.dequeueReusableCell(withIdentifier: "No Prosmotr", for: indexPath)
            }     
            
            self.tableView.rowHeight = self.view.frame.size.height - 108
            
        }
        return cell


       
    }
    
    
    // MARK: - Navigation
    
    
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        

        
        if identifier == "Show Prosmotr Sheet" {
            
            if let event = (sender as? CalendarTableViewCell)?.event {
                if !event.userCanReadSheet {
                    return false
                }
            }
        }
        
        
        return true
    }
    
    
    
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
              
        if segue.identifier == "Show Prosmotr Sheet" {
            if let prosmotrSheetVC = (segue.destination as? ProsmotrSheetTableViewController) {
                
                let event = (sender as? CalendarTableViewCell)?.event
                
                prosmotrSheetVC.presenter.title = "Просмотр"
                prosmotrSheetVC.presenter.event = event
            }
        }
        
        
        
    }

    
    
}

