//
//  CalendarTableViewController.swift
//  TimeTracker
//
//  Created by Anton on 22/06/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class CalendarPresenter {
    weak private var myView : CalendarTableViewController?
    
    func attachView(view:CalendarTableViewController){
        myView = view
    }
    
    func detachView() {
        myView = nil
    }
    
    var loggedUserRole: LoggedUserRole {
        return TimeTracker.data.loggedUserRole
    }
    

    var needToRefresh = false
    var userId: Int? {
        didSet {
            if userId != nil && userId != oldValue {
                self.loadTableData()
            }
        }
    }
    var user: User?
 
    
    func refreshTableData() {
        
        needToRefresh = true
        loadTableData(needToRefresh: true)
        
    }
    
    
    
    func loadTableData(needToRefresh: Bool = false) {
        
        if userId == nil {
            Debug.mode.output("Не задан пользователь", type: .error)
            return
        }
        
        if LoadedData.timeTable.viewPersonId != TimeTracker.data.loggedUserId && LoadedData.timeTable.viewPersonId != nil && LoadedData.timeTable.viewType == .Person {
                _ = TimeTracker.data.getUserWorkTimes(userId: userId!, needToRefresh: needToRefresh, completionHandler: updateWorkTimeData)
        
        }
    }
    
    
    
    
    
    
    func updateWorkTimeData(user: User?, requestStatus: RequestStatus) {
        
        //// Analysing Callback
        switch requestStatus {
            
        case .success:
            //// If request was successful
            if user != nil {
                self.myView?.tableData.workTime = user!.workTime
                self.myView?.tableView.reloadData()
            }
            
        case .error( _):
            //// If there was an error
            
            Debug.mode.output("API вернуло ошибку", type: .error)
            
        }
        
    }
    
    
}



class CalendarTableViewController: UITableViewController {

    
    // NEW MODEL
    let presenter = CalendarPresenter()

    struct TableData {
        var workTime = [JsonUserWorkTime]()
    }
    
    var tableData = TableData()

    
    
    
    // OLD MODEL
    
    var pageIndex: Int!
    var thisPageState: CalendarViewState!
    var day: TimeTableDay?
    var calendarViewController:CalendarViewController?
    var noDataInTable: Bool = false
    var pendingDataInTable: Bool = false
    
    // Because we should not rotate weeks, if the user is doing that himself
    var navigatedFromWeekPageController = false
    
    
    // this gesture we needs for only one reason -
    // to let us know if page swiped and we can reset 
    // navigatedFromWeekPageController
    @IBOutlet var touchDownRecognizer: TouchDownGestureRecognizer!
    @IBAction func tappedCalendarView(_ sender: TouchDownGestureRecognizer) {
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        presenter.attachView(view: self)
        
        touchDownRecognizer.parent = self
        
        
        thisPageState = LoadedData.timeTable.convertDayPageIndexToState(pageIndex)
        
        day = LoadedData.timeTable.getDay(thisPageState)
   
        // Cell's height
        tableView.estimatedRowHeight = tableView.rowHeight
        tableView.rowHeight = UITableViewAutomaticDimension
        
        // Refresher
        self.refreshControl?.addTarget(self, action: #selector(CalendarTableViewController.handleRefresh(_:)), for: UIControlEvents.valueChanged)

       
    }
 
    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
        
        LoadedData.timeTable.loadedWeeks.removeAll()
        LoadedData.timeTable.loadTimeTableDataForWeek(thisPageState.weeknum)
        presenter.refreshTableData()
        
        refreshControl.endRefreshing()

    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        // Setting the state of parent view controller
        
        
        if (!navigatedFromWeekPageController)  // Because we should not rotate weeks, if the user is doing that himself
        {
            calendarViewController?.navigateToWeek(thisPageState!.weeknum)
        }
        
        
        calendarViewController?.calendarState = thisPageState
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        updateUI()
    }
    
    func updateUI() {
        
        day = LoadedData.timeTable.getDay(thisPageState)
        
        self.tableView.reloadData()
        
        if (noDataInTable || pendingDataInTable) {
            
            // Cell's height
            self.tableView.rowHeight = self.view.frame.size.height
            
        } else {
            
            // Cell's height
            tableView.estimatedRowHeight = 44.0
            tableView.rowHeight = UITableViewAutomaticDimension
            
        }
        
        LoadedData.timeTable.loadTimeTableDataForWeek(thisPageState.weeknum - 1)
        LoadedData.timeTable.loadTimeTableDataForWeek(thisPageState.weeknum + 1)
        
        presenter.userId = LoadedData.timeTable.viewPersonId
        
    }
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        
        var additionalRows = 0
        
        if LoadedData.timeTable.viewPersonId != TimeTracker.data.loggedUserId && LoadedData.timeTable.viewPersonId != nil && LoadedData.timeTable.viewType == .Person {
            additionalRows = 1
        }
        
        if LoadedData.timeTable.api.requestStatus == .pending {
            pendingDataInTable = true
        }
        else {
            pendingDataInTable = false
        }

        
        if (day != nil) {
            if (day!.events.count == 0) {
                noDataInTable = true
                pendingDataInTable = false
                return 1 + additionalRows
            }
            else {
                noDataInTable = false
                pendingDataInTable = false
                return day!.events.count + additionalRows
            }
        }
        else {
            noDataInTable = true
            return 1 + additionalRows

        }
      
    }


    
    
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = UITableViewCell()

        var additionalRows = 0
        
        // First Cell Will Be Cell with Working Time of Person
        if LoadedData.timeTable.viewPersonId != TimeTracker.data.loggedUserId && LoadedData.timeTable.viewPersonId != nil && LoadedData.timeTable.viewType == .Person {
            additionalRows = 1
            
            if indexPath.row == 0 {
                cell = tableView.dequeueReusableCell(withIdentifier: "Calendar Worktime Cell", for: indexPath)
                self.tableView.rowHeight = 38
                
                if let thisCell = cell as? CalendarWorkTimeTableViewCell {
                    thisCell.workTimeLabel.text = tableData.workTime.getWorkTime(convertWeekdayToJsonWeekDay(thisPageState.weekday))
                    if thisCell.workTimeLabel.text! != "Выходной" {
                        thisCell.workTimeLabel.text = "Время работы: \(thisCell.workTimeLabel.text!)"
                    }
                }

                
                return cell
            }
        }
        
        
        
        if (pendingDataInTable) {
            cell = tableView.dequeueReusableCell(withIdentifier: "Loading Cell", for: indexPath)
            self.tableView.rowHeight = self.view.frame.size.height - 38
            return cell
        } else {
            if (noDataInTable) {
                cell = tableView.dequeueReusableCell(withIdentifier: "No Data Cell", for: indexPath)
                self.tableView.rowHeight = self.view.frame.size.height - 38
                return cell
            }
        }
        

        
        self.tableView.estimatedRowHeight = 44.0
        self.tableView.rowHeight = UITableViewAutomaticDimension
        
        if (day == nil) {return cell}
        if (day!.events.count == 0) {return cell}
        
        let thisCellEvent = day!.events[indexPath.row - additionalRows]
      
        if let thisEventCat = thisCellEvent.categoty {
            
            switch thisEventCat {
                
            case .lesson :
                cell = tableView.dequeueReusableCell(withIdentifier: "Tutor Cell", for: indexPath)
                
            case .freetime :
                cell = tableView.dequeueReusableCell(withIdentifier: "Break Cell", for: indexPath)

            case .exam :
                cell = tableView.dequeueReusableCell(withIdentifier: "Exam Cell", for: indexPath)

            case .prosmotr :
                cell = tableView.dequeueReusableCell(withIdentifier: "Prosmotr Cell", for: indexPath)

            }
        
    
/////////////////////////////////////////////////////////
// Временно все можно
            
thisCellEvent.userCanReadSheet = true
thisCellEvent.userCanEditSheet = true
            
/////////////////////////////////////////////////////////
            
            
            
            // Configure the cell...

            if let thisCell = cell as? CalendarTableViewCell {
                thisCell.event = thisCellEvent // SENDING MODEL DATA TO CELL
                if (!thisCellEvent.userCanReadSheet) {
                    thisCell.accessoryType = .none
                    thisCell.selectionStyle = .none
                } else {
                    thisCell.accessoryType = .disclosureIndicator
                    thisCell.selectionStyle = .default
                }
                
            }
        
        }
       
       return cell
    }
  
 


   

    
    
    // MARK: - Navigation
    
    
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {

        if identifier == "Show Attendance Sheet" {
            if let event = (sender as? CalendarTableViewCell)?.event {
                if !event.userCanReadSheet {
                    return false
                }
            }
        }
     
        if identifier == "Show Examination Sheet" {
            
            if let event = (sender as? CalendarTableViewCell)?.event {
                if !event.userCanReadSheet {
                    return false
                }
            }
        }
        
        if identifier == "Show Prosmotr Sheet" {
            
            if let event = (sender as? CalendarTableViewCell)?.event {
                if !event.userCanReadSheet {
                    return false
                }
            }
        }
        
       
        return true
    }
    

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        
        if segue.identifier == "Show Attendance Sheet" {
            if let attSheetVC = (segue.destination as? AttendanceSheetTableViewController) {
                
                let event = (sender as? CalendarTableViewCell)?.event
                
                attSheetVC.presenter.title = "Ведомость"
                attSheetVC.presenter.event = event
            }
        }
        
        
        if segue.identifier == "Show Examination Sheet" {
            if let examSheetVC = (segue.destination as? ExaminationSheetTableViewController) {
                
                let event = (sender as? CalendarTableViewCell)?.event
                
                examSheetVC.presenter.title = "Экзамен"
                examSheetVC.presenter.event = event
            }
        }
        
        if segue.identifier == "Show Prosmotr Sheet" {
            if let prosmotrSheetVC = (segue.destination as? ProsmotrSheetTableViewController) {
                
                let event = (sender as? CalendarTableViewCell)?.event
                
                prosmotrSheetVC.presenter.title = "Просмотр"
                prosmotrSheetVC.presenter.event = event
            }
        }
       
        
        
    }


}
