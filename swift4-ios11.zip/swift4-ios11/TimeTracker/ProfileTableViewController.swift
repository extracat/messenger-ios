//
//  ProfileTableViewController.swift
//  TimeTracker
//
//  Created by Anton on 12/10/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit



struct ProjectListItemData {
    var id: Int!
    var title: String?
    var status: String?
    var time: String?
}


class ProfilePresenter {
    weak private var myView : ProfileTableViewController?
    
    func attachView(view:ProfileTableViewController){
        myView = view
    }
    
    func detachView() {
        myView = nil
    }
    
    var loggedUserRole: LoggedUserRole {
        return TimeTracker.data.loggedUserRole
    }
    
    var projectsCallbackStatus: CallbackStatus = CallbackStatus.pending
    var needToRefresh = false
    
    var filter = ProjectsListFiter()
    
    var userId: Int?
    
    var month = Date() {
        didSet {
            if oldValue != month {
                loadProjects(needToRefresh: needToRefresh)
            }
        }
    }
    
    var user: User? {
        didSet{
            if user != nil {
                
                /// UserData for All logged users
                self.myView?.tableData.surname = user!.surname ?? ""
                self.myView?.tableData.fullName = "\(user!.name ?? "") \(user!.patronymic ?? "")"
                self.myView?.tableData.image = user!.image
                
                
                // Only for logged users as Teachers And Workers
                if loggedUserRole == .teachingAndProjects {
                    
                    self.myView?.tableData.email = user!.email
                    self.myView?.tableData.phone = user!.phone

                }


                self.myView?.tableView.reloadData()
                
            }
        }
    }
    
    var projects = [JsonProjectData]() {
        didSet{
            
            // Only for logged users as Teachers And Workers
            if loggedUserRole == .teachingAndProjects {
                
                
                /// Projects
                self.myView?.tableData.projects.removeAll()
                for project in projects {
                    
                    var projectStatusString = ""
                    if project.status == .completed {projectStatusString = "✓ "}
                    if project.status == .inProgress {projectStatusString = "▹ "}
                    
                    let projectNameString = "\(project.name ?? "")"
                    self.myView?.tableData.projects.append(ProjectListItemData(id: project.id, title: projectNameString, status: projectStatusString, time: ""))
                }
                if projects.count == 0 {
                    projectsCallbackStatus = .noData
                }
                self.myView?.tableView.reloadData()
            }
            
        }
    }
    
    
    
    
    func refreshTableData() {

        needToRefresh = true
        month = Date()
        user?.statistics.removeAll()
        loadTableData(needToRefresh: true)

    }
    
    
    
    func loadTableData(needToRefresh: Bool = false) {
        
        if userId == nil {
            self.myView?.alert(title: "Ошибка", message: "Не задан пользователь", action: "ОК")
            return
        }
        
        _ = TimeTracker.data.getUserData(userId: userId!, needToRefresh: needToRefresh, completionHandler: updateUserData)
        _ = TimeTracker.data.getUserImage(userId: userId!, needToRefresh: needToRefresh, completionHandler: updateUserData)
        _ = TimeTracker.data.getUserWorkTimes(userId: userId!, needToRefresh: needToRefresh, completionHandler: updateWorkTimeData)



        
    }
    

    
    func loadProjects(needToRefresh: Bool = false) {
        
        if userId == nil {
            self.myView?.alert(title: "Ошибка", message: "Не задан пользователь", action: "ОК")
            return
        }
        
        
        // Only for logged users as Teachers And Workers
        if loggedUserRole == .teachingAndProjects {
            
            if !needToRefresh {
                self.myView?.tableData.projects.removeAll()   // if month changes - we clear projets list
                self.myView?.tableView.reloadData()           // and refresh table (and "loading" will be presented)
            }
            

            filter.userId = userId!
            //filter.status = .completed
            //filter.endedInInterval = getDatesIntervalForMonth(month)
            filter.workTimeInInterval = getDatesIntervalForMonth(month)
            projectsCallbackStatus = TimeTracker.data.getProjectsList(filter: filter, needToRefresh: needToRefresh, completionHandler: updateProjectsData)
            
        }

    }
    
    func updateProjectsWorktimeData(worktimeArray :[UsersProjectsWorktimeData]? , requestStatus: RequestStatus) {
    
        //// Analysing Callback
        switch requestStatus {
        
        case .success:
        //// If request was successful
            
            if worktimeArray == nil {return}
            if self.myView == nil {return}
            if self.myView?.tableData.projects.count == 0 {return}
            
            for (i, _) in self.myView!.tableData.projects.enumerated() {
                
                let projectId = self.myView!.tableData.projects[i].id
                let worktimeData = worktimeArray!.getByFilter(userId: userId!, projectId: projectId!, timeInterval: getDatesIntervalForMonth(month))
                let worktime = convertToString(worktimeData?.workTimeInHours, whenNil: "")
                if worktime != "" {self.myView!.tableData.projects[i].time = "\(worktime) ч"}
            }
            self.myView?.tableView.reloadData()
        
        case .error(let errorMsg):
        //// If there was an error
        
        self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
    
        }

    }
    
    func updateUserData(user: User?, requestStatus: RequestStatus) {
        
        //// Analysing Callback
        switch requestStatus {
            
        case .success:
            //// If request was successful
            
            self.user = user
            
        case .error(let errorMsg):
            //// If there was an error
            
            self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
            
        }
        
    }
    
    func updateWorkTimeData(user: User?, requestStatus: RequestStatus) {
        
        //// Analysing Callback
        switch requestStatus {
            
        case .success:
            //// If request was successful
            if user != nil {
                self.myView?.tableData.workTime = user!.workTime
                self.myView?.tableView.reloadData()
            }
            
        case .error(let errorMsg):
            //// If there was an error
            
            self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
            
        }
        
    }
    
    func updateProjectsData(projectsList: [JsonProjectData]?, filter: ProjectsListFiter?, requestStatus: RequestStatus) {
        
        needToRefresh = false
        
        if filter != self.filter {
            loadProjects()
        }
        
        //// Analysing Callback
        switch requestStatus {
            
        case .success:
            //// If request was successful
            self.projects.removeAll()
            if projectsList != nil {
                self.projects = projectsList!
                
                _ = TimeTracker.data.getUsersProjectsWorktimeData(projects: projects,
                                                                  userId: userId!,
                                                                  timeInterval: getDatesIntervalForMonth(month),
                                                                  completionHandler: updateProjectsWorktimeData)
            }

            
            
        case .error(let errorMsg):
            //// If there was an error
            
            self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
            
        }
        
    }
    
}


class ProfileTableViewController: UITableViewController {
    
    let presenter = ProfilePresenter()
    
    var needToRefresh: Bool = false


    
    struct TableData {
        
        var surname: String?
        var fullName: String?
        var email: String?
        var phone: String?
        var image: UIImage?
        
        var efficiency: Float?
        var workLoadK: Float?
        var projectsLoadK: Float?
        var schedulesLoadK: Float?
        var workTime = [JsonUserWorkTime]()
        
        var projects = [ProjectListItemData]()
    }
    
    var projectsSectionTitle: String {
        let year = getYear(presenter.month)
        var yearString = ""
        if year != getTodayYear() {yearString = " \(year)"}
        
        let title = "Проекты в \(getMonthName(presenter.month, grammaticalCase: .prepositional))\(yearString)"
        
        return title
    }
    
    struct TableSection {  // Defines Sections in this table
        var id = ""
        var title = ""
        var heightForHeader = CGFloat(24.0)
        var heightForFooter = CGFloat(24.0)
        
    }
    
    var tableData = TableData()
    fileprivate var tableSections = [TableSection]()
    
    
    
    func alert(title: String, message: String, action: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: action, style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
        
        needToRefresh = true
        presenter.refreshTableData()
        refreshControl.endRefreshing()
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        presenter.attachView(view: self)
        
        // Defines Sections in this table
        

        tableSections.append(TableSection(id: "header", title: "", heightForHeader: CGFloat.leastNormalMagnitude, heightForFooter: CGFloat.leastNormalMagnitude))
        
        // Only for logged users as Teachers And Workers
        if presenter.loggedUserRole == .teachingAndProjects {
            tableSections.append(TableSection(id: "effpages",       title: "",          heightForHeader: CGFloat.leastNormalMagnitude,   heightForFooter: CGFloat(24.0)  ))
            tableSections.append(TableSection(id: "projects",       title: projectsSectionTitle,   heightForHeader: CGFloat(24.0), heightForFooter: CGFloat(24.0)  ))
            tableSections.append(TableSection(id: "otherprojects",  title: "",          heightForHeader: CGFloat.leastNormalMagnitude,   heightForFooter: CGFloat(24.0)  ))
            tableSections.append(TableSection(id: "worktime",       title: "Рабочий график",  heightForHeader: CGFloat(24.0), heightForFooter: CGFloat(24.0)  ))
            tableSections.append(TableSection(id: "contacts",       title: "Контакты",  heightForHeader: CGFloat(24.0), heightForFooter: CGFloat(24.0)  ))
        }
        
        /// Cell's height
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 140
        
        
        // Loading DATA
        presenter.loadTableData()
        
        // Refresher
        self.refreshControl?.addTarget(self, action: #selector(ProfileTableViewController.handleRefresh(_:)), for: UIControlEvents.valueChanged)
        
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        
        
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
    
        self.navigationController?.isNavigationBarHidden = false
        
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return tableSections.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        let id = tableSections[section].id
        
        switch id {
            
        case "header": // Name, photo, etc section
            
            return 1
         
        case "effpages": // Eff and Load section
            return 1
            
        case "projects": // Completed in this month projects list section
            if tableData.projects.count == 0 {return 1}
            return tableData.projects.count
            
        case "otherprojects":  // Other projects section
            return 2
            
        case "worktime":  // Contacts section
            return 1
            
        case "contacts":  // Contacts section
            return 2
            
        default:
            return 0
        }
        
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = UITableViewCell()
        
        let id = tableSections[indexPath.section].id
        
        switch id {
            
        case "header": // Name, photo, etc section
            
            cell = tableView.dequeueReusableCell(withIdentifier: "Profile Header Cell", for: indexPath)
            if let thisCell = cell as? ProfileHeaderTableViewCell {
                
                
                thisCell.labelLastName?.text = tableData.surname
                thisCell.labelName?.text = tableData.fullName
                thisCell.userImage = tableData.image
            }
            
        case "effpages": // Eff and Load section
            
            cell = tableView.dequeueReusableCell(withIdentifier: "Eff Pages Cell", for: indexPath)
            if let thisCell = cell as? ProfileEffPagesTableViewCell {
                
                thisCell.profilePresenter = self.presenter
                if needToRefresh {
                    thisCell.handleRefresh()
                    needToRefresh = false
                }
                
            }
 
        case "projects": // Project list section
            
            cell = tableView.dequeueReusableCell(withIdentifier: "Profile Projects Cell", for: indexPath)
            if tableData.projects.count > 0 {
                if let thisCell = cell as? ProjectsTableViewCell {
                    thisCell.projectWorktimeLabel?.text = tableData.projects[indexPath.row].time
                    thisCell.projectStatusLabel?.text = tableData.projects[indexPath.row].status
                    thisCell.projectNameLabel?.text = tableData.projects[indexPath.row].title
                    thisCell.id = tableData.projects[indexPath.row].id
                }
            }
            else {
                cell = UITableViewCell()
                if presenter.projectsCallbackStatus == .noData || presenter.projectsCallbackStatus == .alreadyLoaded {
                    cell.textLabel?.text = "Проектов нет"
                }
                if presenter.projectsCallbackStatus == .pending {
                    cell.textLabel?.text = "Загружается..."
                }
                cell.textLabel?.textColor = UIColor.lightGray
            }
            
            
        case "otherprojects":  // Other projects section
            
            switch indexPath.row {
            case 0:
                cell = tableView.dequeueReusableCell(withIdentifier: "Profile InProgress Cell", for: indexPath)

            case 1:
                cell = tableView.dequeueReusableCell(withIdentifier: "Profile Completed Cell", for: indexPath)

            default:
                break
            }
            
            
        case "worktime":
            
            cell = tableView.dequeueReusableCell(withIdentifier: "Profile Worktime Cell", for: indexPath)
            if let thisCell = cell as? ProfileWorkTimeTableViewCell {
                
                thisCell.day1TimeLabel.text = tableData.workTime.getWorkTime(.Monday)
                thisCell.day2TimeLabel.text = tableData.workTime.getWorkTime(.Tuesday)
                thisCell.day3TimeLabel.text = tableData.workTime.getWorkTime(.Wednesday)
                thisCell.day4TimeLabel.text = tableData.workTime.getWorkTime(.Thursday)
                thisCell.day5TimeLabel.text = tableData.workTime.getWorkTime(.Friday)
                thisCell.day6TimeLabel.text = tableData.workTime.getWorkTime(.Saturday)
                thisCell.day7TimeLabel.text = tableData.workTime.getWorkTime(.Sunday)

            }
            
        case "contacts":  // Contacts section
            
            cell = tableView.dequeueReusableCell(withIdentifier: "Profile Contacts Cell", for: indexPath)
            if let thisCell = cell as? ProfileContactsTableViewCell {
                
                switch indexPath.row {
                case 0:
                    thisCell.contactLabel?.text = tableData.phone
                case 1:
                    thisCell.contactLabel?.text = tableData.email
                default:
                    break
                }
                
            }

            
        default:
            break
        }
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        let id = tableSections[section].id
        if id == "projects" {return projectsSectionTitle}
        
        return tableSections[section].title
        
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return tableSections[section].heightForHeader
        
    }
    
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        return tableSections[section].heightForFooter
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let section = indexPath.section
        let row = indexPath.row
        if tableSections[section].id == "contacts" {
            switch row {
                
            case 0:
                let urlString = "tel://\(self.tableData.phone?.stringByCleanUpPhoneNumber() ?? "")"
                if let url = URL(string: urlString) {
                    UIApplication.shared.openURL(url)
                }
                
            case 1:
                let urlString = "mailto://\(self.tableData.email?.replacingOccurrences(of: " ", with: "") ?? "")"
                if let url = URL(string: urlString) {
                    UIApplication.shared.openURL(url)
                }
                
            default:
                break
            }
        }
        self.tableView.deselectRow(at: indexPath, animated: true)
    }
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let id = tableSections[indexPath.section].id
        var height = UITableViewAutomaticDimension
        
        switch id {
        case "effpages": // Eff and Load section
            height = 290
  
        default:
            break
        }
        
        return CGFloat(height)
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "Show Completed Projects List" {
            if let vc = (segue.destination as? ProjectsTableViewController) {
                
                vc.presenter.userId = self.presenter.userId
                vc.presenter.projectsStatus = .completed
                vc.title = "Завершенные"
                
            }
        }
        
        if segue.identifier == "Show InProgress Projects List" {
            if let vc = (segue.destination as? ProjectsTableViewController) {
                
                vc.presenter.userId = self.presenter.userId
                vc.presenter.projectsStatus = .inProgress
                vc.title = "Текущие"
                
            }
        }
        
        if segue.identifier == "Show Project Info" {
            if let vc = (segue.destination as? ProjectInfoTableViewController) {
                let id = (sender as? ProjectsTableViewCell)?.id
                if id != nil {
                    vc.presenter.projectId = id
                    vc.title = "Завершенные"
                }
                
            }
        }
        

    }
    
    
}
