//
//  LoginViewController.swift
//  TimeTracker
//
//  Created by Anton on 15/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit


class LoginPresenter {
    
    weak private var myView : LoginViewController?
    
    func attachView(view:LoginViewController){
        myView = view
    }
    
    func detachView() {
        myView = nil
    }
    
    var login: String?
    var password: String?
    
    func tryToAutoLogin() {

        //TimeTracker.data.clearLogin()
        
        TimeTracker.data.readLogin()
        login = TimeTracker.data.login
        password = TimeTracker.data.password
     
        myView?.emailTextField.text = login
        myView?.passwordTextField.text = password
      
        tryToLogin()
        
    }
    
    func tryToLogin() {
        if (login != nil && password != nil) {
            if (login! != "" && password! != "") {
                _ = TimeTracker.data.login(login: login!, password: password!, completionHandler: loginComplete)
                myView?.spinner.startAnimating()
            }
        }
    }
    
    
    func loginComplete(user: User?, requestStatus: RequestStatus) {
        
        
        //// Analysing Callback
        switch requestStatus {
            
        case .success:
            //// If request was successful
            if (TimeTracker.data.loggedIn == true) {
                
                
                TimeTracker.data.login = login
                TimeTracker.data.password = password
                TimeTracker.data.saveLogin()   // Saving login and password after sucsessful login

                
                
                LoadedData.timeTable.viewType = .Person
                LoadedData.timeTable.viewPersonId = TimeTracker.data.loggedUserId
                
                myView?.spinner.stopAnimating()
                myView?.performSegue(withIdentifier: "Login", sender: self)
                
            }
            else {
                myView?.spinner.stopAnimating()
                self.myView?.alert(title: "Ошибка", message: "Права пользователя не определены", action: "ОК")
            }
            
        case .error(let errorMsg):
            //// If there was an error
            
            var msg = ""
            if let loginMsg = TimeTracker.data.loginResult.errorMsg {msg = loginMsg}
            else {msg = errorMsg}
             
            myView?.spinner.stopAnimating()
            self.myView?.alert(title: "Ошибка", message: msg, action: "ОК")
            
        }

    }
}

class LoginViewController: UIViewController, UITextFieldDelegate {

    let presenter = LoginPresenter()
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    var spinner: UIActivityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.white)
    
    var screenHeightWithoutKeyboard:CGFloat = 0.0
    
    
    @IBAction func pressedLoginButton(_ sender: UIButton) {
       
        presenter.login = emailTextField.text
        presenter.password = passwordTextField.text
        presenter.tryToLogin()
        
    }
    
    func alert (title: String, message: String, action: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: action, style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter.attachView(view: self)
        
        screenHeightWithoutKeyboard = self.view.frame.size.height
        
        spinner.center = CGPoint(x: view.center.x, y: (view.frame.size.height - view.center.y)/2 + view.center.y)
        view.addSubview(spinner)
    
        self.emailTextField.delegate = self;
        self.passwordTextField.delegate = self;
        
        NotificationCenter.default.addObserver(self, selector: #selector(LoginViewController.keyboardWillShow(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(LoginViewController.keyboardWillHide(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    
        presenter.tryToAutoLogin()
    
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    @objc func keyboardWillShow(_ notification: Notification) {
        
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            self.view.frame.size.height = screenHeightWithoutKeyboard - keyboardSize.height
        }
        
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        self.view.frame.size.height = screenHeightWithoutKeyboard
    }

}
