//
//  UsersTableViewController.swift
//  TimeTracker
//
//  Created by Anton on 19/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class SearchPresenter {
    
    weak private var myView : SearchTableViewController?
    
    func attachView(view:SearchTableViewController){
        myView = view
    }
    
    func detachView() {
        myView = nil
    }
    
    
    var usersList: [JsonUserData]? {
        didSet {
            self.myView?.tableData.removeAll()
            if usersList != nil {
                for user in usersList! {
                    let tableCellText = "\(user.surname ?? "") \(user.name ?? "")"
                    let textForCell = TextAndId(tableCellText, id: user.id)
                    self.myView?.tableData.append(textForCell)
                }
            }
            self.myView?.tableView.reloadData()
        }
    }
    
    
    func refreshTableData() {
        loadTableData(needToRefresh: true)
    }
    
    func loadTableData(needToRefresh: Bool = false) {
        
        let callBackStatus = TimeTracker.data.getUsersList(needToRefresh: needToRefresh, right: .Teaching, completionHandler: {(usersList, requestStatus) in
            
            //// Analysing Callback
            switch requestStatus {
                
            case .success:
                //// If request was successful
                
                self.usersList = usersList
                
            case .error(let errorMsg):
                //// If there was an error
                
                self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
                
            }
        })
        
        Debug.mode.output("CallBackStatus: \(callBackStatus)", type: .none)
    }
    
}


class SearchTableViewController: UITableViewController, UISearchBarDelegate, UISearchControllerDelegate, UISearchResultsUpdating {
    let presenter = SearchPresenter()
    var tableData = [TextAndId]()
    
    /// State restoration values.
    enum RestorationKeys : String {
        case viewControllerTitle
        case searchControllerIsActive
        case searchBarText
        case searchBarIsFirstResponder
    }
    
    struct SearchControllerRestorableState {
        var wasActive = false
        var wasFirstResponder = false
    }

    
    static let nibName = "Search Table Cell"
    static let tableViewCellIdentifier = "Search Table Cell"

    
    /// Search controller to help us with filtering.
    var searchController: UISearchController!
    
    /// Secondary search results table view.
    var resultsTableController: ResultsTableController!
    
    /// Restoration state for UISearchController
    var restoredState = SearchControllerRestorableState()
    
    
    func alert (title: String, message: String, action: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: action, style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter.attachView(view: self)
        
        let nib = UINib(nibName: SearchTableViewController.nibName, bundle: nil)
        
        // Required if our subclasses are to use `dequeueReusableCellWithIdentifier(_:forIndexPath:)`.
        tableView.register(nib, forCellReuseIdentifier: SearchTableViewController.tableViewCellIdentifier)
        
        
        resultsTableController = ResultsTableController()
        
        // We want to be the delegate for our filtered table so didSelectRowAtIndexPath(_:) is called for both tables.
        resultsTableController.tableView.delegate = self
        
        searchController = UISearchController(searchResultsController: resultsTableController)
        searchController.searchResultsUpdater = self
        searchController.searchBar.sizeToFit()
        tableView.tableHeaderView = searchController.searchBar
        
        searchController.delegate = self
        searchController.dimsBackgroundDuringPresentation = false // default is YES
        searchController.searchBar.delegate = self    // so we can monitor text changes + others
        searchController.searchBar.searchBarStyle = UISearchBarStyle.minimal
        searchController.searchBar.backgroundColor = UIColor(hexString: "#f7f7f7")
        searchController.searchBar.tintColor = UIColor.ttDuskBlueColor()
        searchController.searchBar.showsCancelButton = true
        
        /*
         Search is now just presenting a view controller. As such, normal view controller
         presentation semantics apply. Namely that presentation will walk up the view controller
         hierarchy until it finds the root view controller or one that defines a presentation context.
        */
        definesPresentationContext = true
        

        
        // Loading DATA
        presenter.loadTableData()
        
        
    }
    
    func updateUI(){
        
        self.tableView.reloadData()
        
        
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // Restore the searchController's active state.
        if restoredState.wasActive {
            searchController.isActive = restoredState.wasActive
            restoredState.wasActive = false
            
            if restoredState.wasFirstResponder {
                searchController.searchBar.becomeFirstResponder()
                restoredState.wasFirstResponder = false
            }
        }
        searchController.isActive = true
        
    }
    
    // MARK: UISearchBarDelegate
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        // Closes This Modal View
        self.dismiss(animated: false, completion: nil)
    }
    
    // MARK: UISearchControllerDelegate
    
    func presentSearchController(_ searchController: UISearchController) {
        
    }
    
    func willPresentSearchController(_ searchController: UISearchController) {
        
    }
    
    func didPresentSearchController(_ searchController: UISearchController) {
        
    }
    
    func willDismissSearchController(_ searchController: UISearchController) {
    }
    
    func didDismissSearchController(_ searchController: UISearchController) {
    }
    
    override func dismiss(animated flag: Bool, completion: (() -> Void)?) {
        super.dismiss(animated: false, completion: nil)
    }

    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: SearchTableViewController.tableViewCellIdentifier, for: indexPath) as! TableViewCellWithID
       
        // Configure the cell...
        cell.textLabel?.text = tableData[indexPath.row].text
        cell.id = tableData[indexPath.row].id
 
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedPerson: TextAndId
        
        // Check to see which table view cell was selected.
        if tableView === self.tableView {
            selectedPerson = tableData[indexPath.row]
        }
        else {
            selectedPerson = resultsTableController.filteredData[indexPath.row]
        }
        
        LoadedData.timeTable.viewType = .Person
        LoadedData.timeTable.viewPersonId = selectedPerson.id!
        LoadedData.timeTable.viewPersonName = selectedPerson.text!
        LoadedData.timeTable.viewGroupId = nil
        LoadedData.timeTable.viewGroupName = nil
        
        LoadedData.timeTable.clearAllData()
        
        self.dismiss(animated: false, completion: nil)
        self.dismiss(animated: false, completion: nil)

    }
    
    
    func updateSearchResults(for searchController: UISearchController) {
        
        let whitespaceCharacterSet = CharacterSet.whitespaces
        let searchString = searchController.searchBar.text!.trimmingCharacters(in: whitespaceCharacterSet).capitalized
        
        // Hand over the filtered results to our search results table.
        let resultsController = searchController.searchResultsController as! ResultsTableController
        resultsController.filteredData = tableData.filter({
            
            
            return search(string: searchString, inText: TextAndId($0.text, id: $0.id!))
            
        })
        resultsController.tableView.reloadData()
    }

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    
    // MARK: UIStateRestoration
    
    override func encodeRestorableState(with coder: NSCoder) {
        super.encodeRestorableState(with: coder)
        
        // Encode the view state so it can be restored later.
        
        // Encode the title.
        coder.encode(navigationItem.title!, forKey:RestorationKeys.viewControllerTitle.rawValue)
        
        // Encode the search controller's active state.
        coder.encode(searchController.isActive, forKey:RestorationKeys.searchControllerIsActive.rawValue)
        
        // Encode the first responser status.
        coder.encode(searchController.searchBar.isFirstResponder, forKey:RestorationKeys.searchBarIsFirstResponder.rawValue)
        
        // Encode the search bar text.
        coder.encode(searchController.searchBar.text, forKey:RestorationKeys.searchBarText.rawValue)
    }
    
    override func decodeRestorableState(with coder: NSCoder) {
        super.decodeRestorableState(with: coder)
        
        // Restore the title.
        guard let decodedTitle = coder.decodeObject(forKey: RestorationKeys.viewControllerTitle.rawValue) as? String else {
            fatalError("A title did not exist. In your app, handle this gracefully.")
        }
        title = decodedTitle
        
        // Restore the active state:
        // We can't make the searchController active here since it's not part of the view
        // hierarchy yet, instead we do it in viewWillAppear.
        //
        restoredState.wasActive = coder.decodeBool(forKey: RestorationKeys.searchControllerIsActive.rawValue)
        
        // Restore the first responder status:
        // Like above, we can't make the searchController first responder here since it's not part of the view
        // hierarchy yet, instead we do it in viewWillAppear.
        //
        restoredState.wasFirstResponder = coder.decodeBool(forKey: RestorationKeys.searchBarIsFirstResponder.rawValue)
        
        // Restore the text in the search field.
        searchController.searchBar.text = coder.decodeObject(forKey: RestorationKeys.searchBarText.rawValue) as? String
    }

 

}



class ResultsTableController: UITableViewController {
    // MARK: Properties
    
    
    static let nibName = "Search Table Cell"
    static let tableViewCellIdentifier = "Search Table Cell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let nib = UINib(nibName: ResultsTableController.nibName, bundle: nil)
        
        // Required if our subclasses are to use `dequeueReusableCellWithIdentifier(_:forIndexPath:)`.
        tableView.register(nib, forCellReuseIdentifier: ResultsTableController.tableViewCellIdentifier)
    }
    
    
    var filteredData = [TextAndId]()
    
    // MARK: UITableViewDataSource
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredData.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: SearchTableViewController.tableViewCellIdentifier)!
        
        // Configure the cell...
        
        if let thisCell = cell as? TableViewCellWithID {
            // Configure the cell...
            thisCell.textLabel?.text = filteredData[indexPath.row].text
            thisCell.id = filteredData[indexPath.row].id
        }
        return cell

    }
}

