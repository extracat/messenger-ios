//
//  ModelDefinitions.swift
//  TimeTracker
//
//  Created by Anton on 01/12/2016.
//  Copyright © 2016 HSE. All rights reserved.
//

import Foundation
import UIKit

//////////////////////////////////////////////////////////////////////
//////////////////////          Users           //////////////////////
//////////////////////////////////////////////////////////////////////


class User {
    static let imageSize: Int = 258
    
    var loadedData: Bool = false
    var loadedImage: Bool = false
    
    var id: Int?
    var surname: String?
    var name: String?
    var patronymic: String?
    var email: String?
    var phone: String?
    var groups: [JsonGroup]?
    var rights: [EnumUserRights]?
    
    var imageUrl: String?
    var image: UIImage? = nil
    
    var statistics = [StatisticsForMonth]()
    var workTime = [JsonUserWorkTime]()
    
    func setByJsonUserData(jsonUserData: JsonUserData?) {
        if jsonUserData != nil {
            id = jsonUserData!.id
            surname = jsonUserData!.surname
            name = jsonUserData!.name
            patronymic = jsonUserData!.patronymic
            imageUrl = jsonUserData!.imageUrl
            email = jsonUserData!.email
            phone = jsonUserData!.phone
            groups = jsonUserData!.groups
            rights = jsonUserData!.rights

        }
    }
}

class UsersList {
    var loaded: Bool = false
    var list: [JsonUserData]?
    var filterRight: EnumUserRights?
}

class StatisticsForMonth {
    var stat: JsonUserStatistics?
    var month: Date
    
    init(stat: JsonUserStatistics?, month: Date) {
        self.stat = stat
        self.month = month
    }
}

struct JsonUserData {
    var id: Int?
    var surname: String?
    var name: String?
    var patronymic: String?
    var imageUrl: String?
    var phone: String?
    var email: String?
    var groups: [JsonGroup]?
    var rights: [EnumUserRights]?
    
    init (id: Int? = nil,
          surname: String? = nil,
          name: String? = nil,
          patronymic: String? = nil,
          imageUrl: String? = nil,
          phone: String? = nil,
          email: String? = nil,
          groups: [JsonGroup]? = nil,
          rights: [EnumUserRights]? = nil) {
        
         self.id = id
         self.surname = surname
         self.name = name
         self.patronymic = patronymic
         self.imageUrl = imageUrl
         self.phone = phone
         self.email = email
         self.groups = groups
         self.rights = rights
    }
}


class GroupsList {
    var loaded: Bool = false
    var list: [JsonGroup]?
    var filter: GroupsListFiter? = nil
}




struct GroupsListFiter {

    var directionId: Int?
    var learningType: EnumLearningType?
    var learningForm: EnumLearningForm?
    var course: Int?
    var academicYear: Int?
    var currentYearOnly: Bool?

    static func == (left: GroupsListFiter, right: GroupsListFiter) -> Bool {

        let a: Bool = (left.directionId == right.directionId)
        let b: Bool = (left.learningType == right.learningType)
        let c: Bool = (left.learningForm == right.learningForm)
        let d: Bool = (left.course == right.course)
        let e: Bool = (left.academicYear == right.academicYear)
        let f: Bool = (left.currentYearOnly == right.currentYearOnly)
        
        return a && b && c && d && e && f
    }
    
    static func != (left: GroupsListFiter, right: GroupsListFiter) -> Bool {
        return !(left == right)
    }
}

extension GroupsListFiter: Equatable {}



struct JsonGroup {
    var id: Int?
    var name: String?
    var academicYear: Int?
    var course: Int?
    var learningType: EnumLearningType?
    var learningTypeName: String?
    var learningForm: EnumLearningForm?
    var learningFormName: String?
    
    var curatorId: Int?
    var curator: JsonUserData?
    
    var disciplineId: Int?
    var discipline: JsonDiscipline?
    
    var directionId: Int?
    var direction: JsonDirection?
    
    init (  id: Int? = nil,
            name: String? = nil,
            academicYear: Int? = nil,
            course: Int? = nil,
            learningType: EnumLearningType? = nil,
            learningTypeName: String? = nil,
            learningForm: EnumLearningForm? = nil,
            learningFormName: String? = nil,
            curatorId: Int? = nil,
            curator: JsonUserData? = nil,
            disciplineId: Int? = nil,
            discipline: JsonDiscipline? = nil,
            directionId: Int? = nil,
            direction: JsonDirection? = nil){
        
        self.id = id
        self.name = name
        self.academicYear = academicYear
        self.course = course
        self.learningType = learningType
        self.learningTypeName = learningTypeName
        self.learningForm = learningForm
        self.learningFormName = learningFormName
        self.curatorId = curatorId
        self.curator = curator
        self.disciplineId = disciplineId
        self.discipline = discipline
        self.directionId = directionId
        self.direction = direction
    }
}

struct JsonDiscipline {
    var id: Int?
    var name: String?
    var type: Int?
    var typeName: String?
    var color: String?
}

struct JsonDirection {
    var id: Int?
    var name: String?
    var code: String?
}


struct JsonUserStatistics {
    var efficiency: Float?
    //var workLoadK: Float?
    //var projectsLoadK: Float?
    var projectsWorkLoadK: Float?
    var projectsPlanLoadK: Float?
    var schedulesLoadK: Float?
    var noWorkProjectsLoadK: Float?
    var absentK: Float?
    var schedulesWithLatenessCount: Int?
}

struct JsonUserWorkTime {
    var dayOfWeek: JsonWeekDay?
    var startTime: String?
    var endTime: String?
}


//////////////////////////////////////////////////////////////////////
//////////////////////         Projects         //////////////////////
//////////////////////////////////////////////////////////////////////


class ProjectsList {
    var loaded: Bool = false
    var list: [JsonProjectData]?
    var filter: ProjectsListFiter? = nil
}

struct ProjectsListFiter {
    var userId: Int? = nil
    var status: EnumProjectStatus? = nil
    var inInterval: DatesInterval? = nil
    var startedInInterval: DatesInterval? = nil
    var endedInInterval: DatesInterval? = nil
    var workTimeInInterval: DatesInterval? = nil
    var hasEfficiency: Bool? = nil
    
    static func == (left: ProjectsListFiter, right: ProjectsListFiter) -> Bool {
        let a: Bool = (left.userId == right.userId)
        let b: Bool = (left.status == right.status)
        let c: Bool = (left.inInterval == right.inInterval)
        let d: Bool = (left.startedInInterval == right.startedInInterval)
        let e: Bool = (left.endedInInterval == right.endedInInterval)
        let f: Bool = (left.workTimeInInterval == right.workTimeInInterval)
        let g: Bool = (left.hasEfficiency == right.hasEfficiency)
        
        return a && b && c && d && e && f && g
    }
    
    static func != (left: ProjectsListFiter, right: ProjectsListFiter) -> Bool {
        return !(left == right)
    }
}

extension ProjectsListFiter: Equatable {}


struct JsonProjectData {
    var id: Int?
    var name: String?
    var status: EnumProjectStatus?
    var workTimeInHours: Float?
    var costInHours: Float?
    var deadline: Date?
    var efficiency: Float?
    var coordinatorId: Int?
    var coordinator: JsonUserData?
    var users: [JsonUserData]?
}

class Project {
    var loaded: Bool = false
    
    var id: Int?
    var name: String?
    var status: EnumProjectStatus?
    var workTimeInHours: Float?
    var costInHours: Float?
    var deadline: Date?
    var efficiency: Float?
    var coordinatorId: Int?
    var coordinator: JsonUserData?
    var users: [JsonUserData]?
    
    func setByJsonProjectData(jsonProjectData: JsonProjectData?) {
        if jsonProjectData != nil {
            id = jsonProjectData!.id
            name = jsonProjectData!.name
            status = jsonProjectData!.status
            workTimeInHours = jsonProjectData!.workTimeInHours
            costInHours = jsonProjectData!.costInHours
            deadline = jsonProjectData!.deadline
            efficiency = jsonProjectData!.efficiency
            coordinatorId = jsonProjectData!.coordinatorId
            coordinator = jsonProjectData!.coordinator
            users = jsonProjectData!.users
        }
    }
}

class UsersProjectsWorktimeData {
    var userId: Int?
    var projectId: Int?
    var timeInterval: DatesInterval?
    var workTimeInHours: Float?
    
    func setByJsonProjectData(_ jsonProjectData: JsonProjectData?) {
        if jsonProjectData != nil {
            projectId = jsonProjectData!.id
            workTimeInHours = jsonProjectData!.workTimeInHours
        }
    }
    
    init() {
        userId = nil
        projectId = nil
        timeInterval = nil
        workTimeInHours = nil
    }
    
    init(userId: Int?, project: JsonProjectData?, timeInterval: DatesInterval?) {
        self.userId = userId
        self.timeInterval = timeInterval
        self.setByJsonProjectData(project)
    }

}


//////////////////////////////////////////////////////////////////////
//////////////////////          Sheets          //////////////////////
//////////////////////////////////////////////////////////////////////


struct JsonAttendanceSheetItem {
    var studentId: Int? = nil
    var isChecked: Bool? = nil
    var student: JsonUserData? = nil
}

struct JsonExaminationSheetItem {
    var moduleCourseId: Int? = nil
    var studentId: Int? = nil
    var mark: Int? = nil
    var student: JsonUserData? = nil
}

struct JsonProsmotrSheetItem {
    var userProjectId: Int? = nil
    var mark: Int? = nil
    var userProject: JsonUserProject? = nil
}

struct JsonUserProject {
    var id: Int? = nil
    var title: String? = nil
    var moduleCourseId: Int? = nil
    var authors = [JsonUserData]()
}

class AttendanceSheet: Sheet {
    var data = [JsonAttendanceSheetItem]()
    
    func toggleAll(checkMark: Bool)  {
        for (i, _) in data.enumerated() {
            data[i].isChecked = checkMark
        }
    }
    
    func toggleStudent(id: Int, checkMark: Bool)  {
        for (i, _) in data.enumerated() {
            if data[i].studentId == id {data[i].isChecked = checkMark}
        }
    }
}

class ExaminationSheet: Sheet {
    var data = [JsonExaminationSheetItem]()
}
class ProsmotrSheet: Sheet {
    var data = [JsonProsmotrSheetItem]()
}

class Sheet {
    var scheduleId: Int?
    var date: Date?
    var type: SheetType?
    
    var loadingTime: Date?
    var loaded: Bool = false
    
    func isActual() -> Bool {
        return true
    }
    


}

//////////////////////////////////////////////////////////////////////
////////////////////// Special array extentions //////////////////////
//////////////////////////////////////////////////////////////////////

extension Array where Element: User {
    
    func indexById(_ id: Int) -> Int? {
        let i = self.index(where: { (item) -> Bool in
            return item.id == id
        })
        return i
    }
    
    func getById(id: Int) -> User? {
        let i = self.indexById(id)
        if i != nil {
            return self[i!]
        }
        else {
            return nil
        }
    }
    
    mutating func set(user: User) -> Void {
        if user.id == nil {
            self.append(user as! Element)
        }
        else {
            let i = self.indexById(user.id!)
            if i == nil {
                self.append(user as! Element)
            }
            else {
                self[i!] = user as! Element
            }
        }
    }
    
}

extension Array where Element: UsersList {
    func indexByFilter(filterRight: EnumUserRights?) -> Int? {
        let i = self.index(where: { (item) -> Bool in
            return item.filterRight == filterRight
        })
        return i
    }
    
    func getByFilter(filterRight: EnumUserRights?) -> UsersList? {
        let i = self.indexByFilter(filterRight: filterRight)
        if i != nil {
            return self[i!]
        }
        else {
            return nil
        }
    }
    
    mutating func set(usersList: UsersList) -> Void {
        
        let i = self.indexByFilter(filterRight: usersList.filterRight)
        if i == nil {
            self.append(usersList as! Element)
        }
        else {
            self[i!] = usersList as! Element
        }
        
    }
    
}


extension Array where Element: GroupsList {
    
    func indexByFilter(filter: GroupsListFiter?) -> Int? {
        let i = self.index(where: { (item) -> Bool in
            return item.filter == filter
        })
        return i
    }
    
    func getByFilter(filter: GroupsListFiter?) -> GroupsList? {
        let i = self.indexByFilter(filter: filter)
        if i != nil {
            return self[i!]
        }
        else {
            return nil
        }
    }
    
    mutating func set(list: GroupsList) -> Void {
        
        let i = self.indexByFilter(filter: list.filter)
        if i == nil {
            self.append(list as! Element)
        }
        else {
            self[i!] = list as! Element
        }
        
    }
    
        
}



extension Array where Element: Project {
    
    func indexById(_ id: Int) -> Int? {
        let i = self.index(where: { (item) -> Bool in
            return item.id == id
        })
        return i
    }
    
    func getById(id: Int) -> Project? {
        let i = self.indexById(id)
        if i != nil {
            return self[i!]
        }
        else {
            return nil
        }
    }
    
    mutating func set(project: Project) -> Void {
        if project.id == nil {
            self.append(project as! Element)
        }
        else {
            let i = self.indexById(project.id!)
            if i == nil {
                self.append(project as! Element)
            }
            else {
                self[i!] = project as! Element
            }
        }
    }
    
}

extension Array where Element: ProjectsList {
    
    func indexByFilter(filter: ProjectsListFiter?) -> Int? {
        let i = self.index(where: { (item) -> Bool in
            return item.filter == filter
        })
        return i
    }
    
    func getByFilter(filter: ProjectsListFiter?) -> ProjectsList? {
        let i = self.indexByFilter(filter: filter)
        if i != nil {
            return self[i!]
        }
        else {
            return nil
        }
    }
    
    mutating func set(projectsList: ProjectsList) -> Void {
        
        let i = self.indexByFilter(filter: projectsList.filter)
        if i == nil {
            self.append(projectsList as! Element)
        }
        else {
            self[i!] = projectsList as! Element
        }
        
    }
    
    mutating func remove(userId: Int?) -> Void {
        
        var i = self.index(where: { (item) -> Bool in
            return item.filter?.userId == userId
        })

        while i != nil {
            i = self.index(where: { (item) -> Bool in
                return item.filter?.userId == userId
            })
            
            if i != nil {
                self.remove(at: i!)
            }
        }


    }
    
}



extension Array where Element: UsersProjectsWorktimeData {
    
    func filterArray(userId: Int, timeInterval: DatesInterval) -> [UsersProjectsWorktimeData] {
        
        return self.filter { $0.userId == userId && $0.timeInterval == timeInterval }

    }
    

    func indexByFilter(userId: Int, projectId: Int, timeInterval: DatesInterval) -> Int? {
        let i = self.index(where: { (item) -> Bool in
            return item.userId == userId && item.timeInterval == timeInterval && item.projectId == projectId
        })
        return i
    }

    
    func getByFilter(userId: Int, projectId: Int, timeInterval: DatesInterval) -> UsersProjectsWorktimeData? {
        let i = self.indexByFilter(userId: userId, projectId: projectId, timeInterval: timeInterval)
        if i != nil {
            return self[i!]
        }
        else {
            return nil
        }
    }
    
}


extension Array where Element: Sheet {
    func indexByFilter(type: SheetType?, date: Date?, scheduleId: Int?) -> Int? {
        let i = self.index(where: { (item) -> Bool in
            return (item.type == type) && (item.date == date) && (item.scheduleId == scheduleId)
        })
        return i
    }
    
    func getByFilter(type: SheetType?, date: Date?, scheduleId: Int?) -> Sheet? {
        let i = self.indexByFilter(type: type, date: date, scheduleId: scheduleId)
        if i != nil {
            return self[i!]
        }
        else {
            return nil
        }
    }
    
    mutating func set(sheet: Sheet) -> Void {
        let i = self.indexByFilter(type: sheet.type, date: sheet.date, scheduleId: sheet.scheduleId)
        if i == nil {
            self.append(sheet as! Element)
        }
        else {
            self[i!] = sheet as! Element
        }
    }
    
}

extension Array where Element: StatisticsForMonth {
    func indexByFilter(date: Date) -> Int? {
        let i = self.index(where: { (item) -> Bool in
            return item.month == date
        })
        return i
    }
    
    func getByFilter(date: Date) -> StatisticsForMonth? {
        let i = self.indexByFilter(date: date)
        if i != nil {
            return self[i!]
        }
        else {
            return nil
        }
    }
    
    mutating func set(stat: StatisticsForMonth) -> Void {
        let i = self.indexByFilter(date: stat.month)
        if i == nil {
            self.append(stat as! Element)
        }
        else {
            self[i!] = stat as! Element
        }
    }
    
}


protocol UserWorkTime {
    var dayOfWeek: JsonWeekDay? { get }
    var startTime: String? { get }
    var endTime: String? { get }
}

extension JsonUserWorkTime: UserWorkTime {}

extension Array where Element: UserWorkTime {
    func indexByFilter(weekday: JsonWeekDay) -> Int? {
        let i = self.index(where: { (item) -> Bool in
            return item.dayOfWeek == weekday
        })
        return i
    }
    
    func getByFilter(weekday: JsonWeekDay) -> UserWorkTime? {
        let i = self.indexByFilter(weekday: weekday)
        if i != nil {
            return self[i!]
        }
        else {
            return nil
        }
    }
    
    func getWorkTime(_ weekday: JsonWeekDay) -> String {
        if self.count == 0 {
            return ""
        }
        else{
            let item = self.getByFilter(weekday: weekday)
            if item != nil {
                return "\(convertToString(item!.startTime)) — \(convertToString(item!.endTime))"
            }
            else {
                return "Выходной"
            }
        }
    }
    
}



extension Array where Element: TimeTableEvent {
    
    func indexById(_ id: Int) -> Int? {
        let i = self.index(where: { (item) -> Bool in
            return item.id == id
        })
        return i
    }
    
    func getById(id: Int) -> TimeTableEvent? {
        let i = self.indexById(id)
        if i != nil {
            return self[i!]
        }
        else {
            return nil
        }
    }
    
    mutating func set(event: TimeTableEvent) -> Void {
        if event.id == nil {
            self.append(event as! Element)
        }
        else {
            let i = self.indexById(event.id!)
            if i == nil {
                self.append(event as! Element)
            }
            else {
                self[i!] = event as! Element
            }
        }
    }
    
}

//////////////////////////////////////////////////////////////////////
//////////////////////    Common Definitions    //////////////////////
//////////////////////////////////////////////////////////////////////


enum LoggedUserRole {
    case unregistered
    case studentOnly
    case teachingAndProjects
}

public enum HTTPMethod: String {
    case OPTIONS = "OPTIONS"
    case GET     = "GET"
    case HEAD    = "HEAD"
    case POST    = "POST"
    case PUT     = "PUT"
    case PATCH   = "PATCH"
    case DELETE  = "DELETE"
    case TRACE   = "TRACE"
    case CONNECT = "CONNECT"
}

enum CallbackStatus {
    case pending        // Wait for loading new data
    case noData         // Tried to load data before, but where is no any data
    case alreadyLoaded  // Data was loaded before, returning the old data
    case error          // Impossible to load data, system error
}

enum JsonWeekDay: Int {
    case UnSupported = -1
    case Sunday     = 0
    case Monday     = 1
    case Tuesday    = 2
    case Wednesday  = 3
    case Thursday   = 4
    case Friday     = 5
    case Saturday   = 6
}

enum EnumLoginStatus: Int {
    case UnSupported = -1
    case connectionFailed           = 0
    case userIsNotExist             = 1
    case loginPasswordIsIncorrect   = 2
    case success                    = 3
}

enum EnumUserRights: Int {
    case UnSupported = -1
    case EditUsers = 1
    case EditRoles = 2
    case EditSubdivisions = 3
    case EditDisciplines = 4
    case EditAuditories = 5
    case EditTimeIntervals = 6
    case EditExaminers = 7
    case EditAndPrintAnyStudentsStatements = 8
    case EditOwnProjects = 9
    case EditProjectContacts = 10
    case EditDirections = 11
    case EditFaculties = 12
    case EditGroups = 13
    case EditModules = 14
    case EditAnyProjects = 15
    case EditSchedules = 16
    case HideUserProjects = 17
    case ViewProjectsCosts = 18
    case CreateAnyProjectTasks = 19
    case Projects = 20
    case Teaching = 21
    case Mailing = 22
    case Student = 23
    case EditIsSeasonInProjects = 24
    case LoadTerminalsData = 25
    case EditCompetencies = 27
    case EditPrograms = 28
    case EditProgramIndexes = 29
    case EditProgramGroups = 30
    case EditUserProjects = 31
    case EditExaminerMarks = 32
    case ViewUnmoderatedTSProjects = 33
    case EditTSProjects = 34
    case EditTSExaminers = 35
    case ExaminersMarksReview = 36
    case Examiner = 37
    case EditCompetenceTags = 38
    case NotificationsByProjectsAndTasks = 39
    case IsHiddenLatenessStatistic = 40
    case CanBeAuthorOfUserProject = 41
    case IsDesignSchoolTeamMember = 42
    case FeaturingUserProjectWorks = 43
    case EditDebtorDeadlines = 44
    case EditBigThemes = 45
}

enum EnumLearningType: Int {
    case UnSupported = -1
    case Bachelor = 1
    case Magistracy = 2
    case Specialty = 3
    case Additional = 4
    case Lyceum = 5
    case BeforeUniversity = 6
}


enum EnumLearningForm: Int {
    case UnSupported = -1
    case FullTime = 1
    case Evening = 2
    case NoFullTime = 3
    case Remote = 4
}

enum EnumProjectStatus: Int {
    case UnSupported = -1
    case inPlans     = 1
    case inProgress  = 2
    case completed   = 3
    case paused      = 4
  //case expired     = 5
    case canceled    = 6
}

enum SheetType {
    case attendance
    case examination
    case prosmotr
    
}

struct LoginResult {
    var status: EnumLoginStatus?
    var errorMsg: String?
    var token: String?
    var tokenIssued: Date?
    var tokenExpires: Date?
}

enum RequestStatus {
    case success
    case error(String)
}
