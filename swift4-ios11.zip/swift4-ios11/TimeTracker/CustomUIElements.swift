//
//  CustomUIElements.swift
//  TimeTracker
//
//  Created by Anton on 05/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import Foundation
import UIKit


//@IBDesignable
class NoWorkProjectsLoadHistogramBar: HistogramBar {
    override func getTextForValue() -> String {
        if (value == 0) {
            return "0"
        }
        else if (value < 0.1){
            return "\(String(round(1000*value)/10))%"
        }
        return "\(String(Int(round(100*value))))%"
    }
    
    override func getRealValue() -> Float {
        return value
    }
    
    override func getBarColor() -> UIColor {
        
        var color = UIColor.black
        
        color = UIColor(hexString: "#B4CDCD")!
        
        return color
    }
    
}


//@IBDesignable
class AbsentHistogramBar: HistogramBar {
    override func getTextForValue() -> String {
        if (value == 0) {
            return "0"
        }
        else if (value < 0.1){
            return "\(String(round(1000*value)/10))%"
        }
        return "\(String(Int(round(100*value))))%"
    }
    
    override func getRealValue() -> Float {
        return value
    }
    
    override func getBarColor() -> UIColor {
        
        var color = UIColor.black
        
        if value >  0.1                    {color = UIColor(hexString: "#F36345")!}    //RED
        if value >  0.03 && value <= 0.1   {color = UIColor(hexString: "#F5A623")!}    //YELLOW
        if value <= 0.03                   {color = UIColor(hexString: "#7ED321")!}    //GREEN
    
        return color
    }
    
}



//@IBDesignable
class EffHistogramBar: HistogramBar {
    override func getTextForValue() -> String {
        if (value == 0) {
            return "0"
        }
        else if (value < 0.01){
            return String(round(1000*value)/1000)
        }
        
        return String(round(100*value)/100)
    }
    
    override func getRealValue() -> Float {
        var realValue:Float = 0.0
        if value <= 0 {
            realValue = 0
        }
        if value > 0 && value <= 1 {
            realValue = value * value / 2
        }
        if value > 1 {
            realValue = log10(value) * 0.5 + 0.5
        }
        
        return realValue
    }
    
    override func getBarColor() -> UIColor {
        
        var color = UIColor.black
        
        if value < 0.7                   {color = UIColor(hexString: "#F36345")!}
        if value >= 0.7 && value <= 1.0  {color = UIColor(hexString: "#F5A623")!}
        if value > 1                     {color = UIColor(hexString: "#7ED321")!}
        
        return color
    }

}

//@IBDesignable
class LoadHistogramBar: HistogramBar {
    override func getTextForValue() -> String {
        if (value == 0) {
            return "0"
        }
        else if (value < 0.1){
            return "\(String(round(1000*value)/10))%"
        }
        return "\(String(Int(round(100*value))))%"
    }
    
    override func getRealValue() -> Float {
        return value
    }
    
    override func getBarColor() -> UIColor {
        
        var color = UIColor.black
        
        if value < 0.5                      {color = UIColor(hexString: "#F36345")!}
        if value >= 0.5 && value <= 0.85    {color = UIColor(hexString: "#F5A623")!}
        if value > 0.85                     {color = UIColor(hexString: "#7ED321")!}
        
        return color
    }

}


class ProjectsWorkLoadHistogramBar: HistogramBar {
    
    var schedulesLoad: Float?
    
    override func getTextForValue() -> String {
        if (value == 0) {
            return "0"
        }
        else if (value < 0.1){
            return "\(String(round(1000*value)/10))%"
        }
        return "\(String(Int(round(100*value))))%"
    }
    
    override func getRealValue() -> Float {
        return value
    }
    
    override func getBarColor() -> UIColor {
        
        var valueForColor: Float
        if schedulesLoad != nil {valueForColor = schedulesLoad! + value}
        else {valueForColor = value}
        
        var color = UIColor.black
        
        if valueForColor < 0.5                              {color = UIColor(hexString: "#F36345")!}
        if valueForColor >= 0.5 && valueForColor <= 0.85    {color = UIColor(hexString: "#F5A623")!}
        if valueForColor > 0.85                             {color = UIColor(hexString: "#7ED321")!}
        
        return color
    }
    
}


class ProjectsPlanLoadHistogramBar: HistogramBar {
    
    var schedulesLoad: Float?
    
    override func getTextForValue() -> String {
        if (value == 0) {
            return "0"
        }
        else if (value < 0.1){
            return "\(String(round(1000*value)/10))%"
        }
        return "\(String(Int(round(100*value))))%"
    }
    
    override func getRealValue() -> Float {
        return value
    }
    
    override func getBarColor() -> UIColor {
        
        var valueForColor: Float
        if schedulesLoad != nil {valueForColor = schedulesLoad! + value}
        else {valueForColor = value}
        
        var color = UIColor.black
        
        if valueForColor < 0.5                              {color = UIColor(hexString: "#F36345")!}
        if valueForColor >= 0.5 && valueForColor <= 0.85    {color = UIColor(hexString: "#F5A623")!}
        if valueForColor > 0.85                             {color = UIColor(hexString: "#7ED321")!}
        
        return color
    }
    
}


/*
 class ProjectsLoadHistogramBar: HistogramBar {

    var summaryLoad: Float?
    
    override func getTextForValue() -> String {
        if (value == 0) {
            return "0"
        }
        else if (value < 0.1){
            return "\(String(round(1000*value)/10))%"
        }
        return "\(String(Int(round(100*value))))%"
    }
    
    override func getRealValue() -> Float {
        return value
    }
    
    override func getBarColor() -> UIColor {
        
        var valueForColor: Float
        if summaryLoad != nil {valueForColor = summaryLoad!}
        else {valueForColor = value}
        
        var color = UIColor.black
        
        if valueForColor < 0.5                              {color = UIColor(hexString: "#F36345")!}
        if valueForColor >= 0.5 && valueForColor <= 0.85    {color = UIColor(hexString: "#F5A623")!}
        if valueForColor > 0.85                             {color = UIColor(hexString: "#7ED321")!}
        
        return color
    }
    
}
*/

//@IBDesignable
class SchedulesLoadHistogramBar: HistogramBar {
    override func getTextForValue() -> String {
        if (value == 0) {
            return "0"
        }
        else if (value < 0.1){
            return "\(String(round(1000*value)/10))%"
        }
        return "\(String(Int(round(100*value))))%"
    }
    
    override func getRealValue() -> Float {
        return value
    }
    
    override func getBarColor() -> UIColor {
        
        var color = UIColor.black
        
        //if value < 0.5     {color = UIColor(hexString: "#F36345")!}
        if value <= 0.1    {color = UIColor(hexString: "#F5A623")!}
        if value > 0.1     {color = UIColor(hexString: "#7ED321")!}
        
        return color
    }
    
}


//@IBDesignable
class HistogramBar: UIView {
   
    @IBInspectable
    var value: Float = 0.0 {
        didSet{
            updateUI()
        }
    }
    
    fileprivate var width: Float = 0.0
    fileprivate var height: Float = 0.0

    fileprivate var textLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 50, height: 20))
    fileprivate var innerBar = Bar()

    var textHidden: Bool = false {
        didSet{
            if textHidden {
                textLabel.isHidden = true
            }
            else {
                textLabel.isHidden = false
            }
        }
    }
    
    fileprivate func didChangeSize() {
        self.width = Float(self.frame.size.width)
        self.height = Float(self.frame.size.height)
        updateUI()
        
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        didChangeSize()
    }

    fileprivate func getFontSize() -> CGFloat {
        return CGFloat(self.height / 1.6 + 2)
    }
        
        
    override func didMoveToSuperview() {
        super.didMoveToSuperview()
        
        
        /// init
        self.addSubview(innerBar)
        self.addSubview(textLabel)
        
        textLabel.textColor = UIColor.black
 
        updateUI()
    }
 

    fileprivate func updateUI() {
        
        textLabel.font = textLabel.font.withSize(getFontSize())
        
        var realValue = getRealValue()
        
        if realValue < 0 {realValue = 0}
        if realValue > 1 {realValue = 1}
        
        innerBar.setHeight(self.height, animate: false)
        innerBar.setColor(getBarColor())
        innerBar.setWidth(self.width * realValue, animate: true)
        
        
        
        textLabel.text = getTextForValue()
        let textWidth: Float = Float(textLabel.text!.characters.count) * 12.0 + 8
        
        var textPosition = self.width * realValue + 5
        let maxTextPosition = self.width - textWidth
        
        
        if textPosition > maxTextPosition {
            textPosition = self.width - textWidth - 5
            textLabel.textAlignment = NSTextAlignment.right
            textLabel.frame = CGRect(x: CGFloat(textPosition), y: 0, width: CGFloat(textWidth), height: CGFloat(self.height))

        
        } else {
            textLabel.textAlignment = NSTextAlignment.left
            textLabel.frame = CGRect(x: CGFloat(textPosition), y: 0, width: CGFloat(textWidth), height: CGFloat(self.height))

        }


    }

    func getTextForValue() -> String {
        return String(Int(value))
    }
    
    func getRealValue() -> Float {
        return value / 100
    }
    
    func getBarColor() -> UIColor {
        
        var color = UIColor.black
        
        if value < 30                   {color = UIColor(hexString: "#F36345")!}
        if value >= 30 && value < 60    {color = UIColor(hexString: "#F5A623")!}
        if value >= 60                  {color = UIColor(hexString: "#7ED321")!}

        return color
    }
}

class Bar: UIView {

    fileprivate func changeRect(_ newFrame: CGRect, animate: Bool = false) {
        
        if animate {
            UIView.animate(withDuration: 0.2, animations: {
                self.frame = newFrame
            })
        } else {
            self.frame = newFrame
        }

    }
    
    
    func setWidth(_ newWidth: Float, animate: Bool = false) {
        let width = newWidth
        let newFrame = CGRect(x: self.frame.origin.x, y: self.frame.origin.y, width: CGFloat(width), height: self.frame.size.height)
        changeRect(newFrame, animate: animate)
    }
    
    func setHeight(_ newHeight: Float, animate: Bool = false) {
        let height = newHeight
        let newFrame = CGRect(x: self.frame.origin.x, y: self.frame.origin.y, width: self.frame.size.width, height: CGFloat(height))
        changeRect(newFrame, animate: animate)
    }
    
    func setColor(_ color: UIColor) {
        self.backgroundColor = color
    }
    
    override func willMove(toSuperview newSuperView: UIView?) {
        //self.superView = newSuperView
    }
    
    
    override func didMoveToSuperview() {
        /*
        if superView != nil {
            let superFrame = superView!.frame
            self.superWidth = Float(superFrame.size.width)
        }
        */
    }
    
    override init (frame : CGRect) {
        super.init(frame : frame)
    }
    

    convenience init () {
        self.init(frame: CGRect.zero)
    }
 
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
}


// Use it when you need to transfer some ID in segue

class TableViewCellWithID: UITableViewCell {
    
    var id: Int?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}




////////////////////////////////////////////////////////////



class WeekdayBottomBar: UIView {
  
    fileprivate var superWidth: Float = 0
    fileprivate var superView: UIView?
    
    fileprivate var weekday: Int = 0
    fileprivate var position: Float = 0
    fileprivate var width: Float = 0
    
    fileprivate func changeRect(_ newFrame: CGRect, animate: Bool = false) {
        
        if animate {
            UIView.animate(withDuration: 0.2, animations: {
                self.frame = newFrame
            })
        } else {
            self.frame = newFrame
        }
        

    }
    
    func setWeekday(_ newWeekday: Int, animate: Bool = false) {
        weekday = newWeekday
        if (1 <= weekday && weekday <= 7) {
            setPosition(Float(weekday - 1) * width, animate: animate)
        }

    }
    
    func setPosition(_ newPosition: Float, animate: Bool = false) {
        position = newPosition
        let newFrame = CGRect(x: CGFloat(position), y: self.frame.origin.y, width: self.frame.size.width, height: self.frame.size.height)
        changeRect(newFrame, animate: animate)
    }
    
    func setWidth(_ newWidth: Float, animate: Bool = false) {
        width = newWidth
        let newFrame = CGRect(x: self.frame.origin.x, y: self.frame.origin.y, width: CGFloat(width), height: self.frame.size.height)
        changeRect(newFrame, animate: animate)
    }
    
    func setToday(_ today: Bool) {
        if today {
            self.backgroundColor = UIColor.ttDuskBlueColor()
        }
        else {
            self.backgroundColor = UIColor.black
        }
        
    }
    
    override func willMove(toSuperview newSuperView: UIView?) {
        
        self.superView = newSuperView

    }
    
    override func didMoveToSuperview() {
        
        if superView != nil {

            let superFrame = superView!.frame
            self.superWidth = Float(superFrame.size.width)
            setWidth(Float(superFrame.size.width) / 7)

        }
    }
    
    override init (frame : CGRect) {
        
        super.init(frame : frame)
        
        addBehavior()
    }
    
    convenience init () {
        self.init(frame:CGRect.zero)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("This class does not support NSCoding")
    }
    
    fileprivate func addBehavior () {
        
        let width = CGFloat(self.width)
        let height = CGFloat(4)
        let x = CGFloat(self.position)
        let y = CGFloat(109)
        
        self.frame = CGRect(x: x, y: y, width: width, height: height)
        self.backgroundColor = UIColor.black
    }
    


}

class CheckBox: UIButton {
    
    // Images
    let checkedImage = UIImage(named: "checkboxChecked")! as UIImage
    let uncheckedImage = UIImage(named: "checkboxUnchecked")! as UIImage
    
    var id: Int? = nil   // for some reasons
    
    static func nothing(_: Int?, _: Bool) -> Void {}
    
    var actionHandler: (Int?, Bool) -> Void = CheckBox.nothing
    
    // Bool property
    var isChecked: Bool = false {
        didSet{
            if isChecked == true {
                self.setImage(checkedImage, for: UIControlState())
            } else {
                self.setImage(uncheckedImage, for: UIControlState())
            }
            actionHandler(self.id, self.isChecked)
        }
    }
    
    override func awakeFromNib() {
        self.addTarget(self, action: #selector(CheckBox.buttonClicked(_:)), for: UIControlEvents.touchUpInside)
        self.isChecked = false
    }
    
    @objc func buttonClicked(_ sender: UIButton) {
        if sender == self {
            isChecked = !isChecked
        }
    }
    
    func changeState() {
        isChecked = !isChecked
    }
    

}


extension UIColor {
    class func ttDuskBlueColor() -> UIColor {
        return UIColor(red: 40.0 / 255.0, green: 94.0 / 255.0, blue: 151.0 / 255.0, alpha: 1.0)
    }
    class func ttGreyishColor() -> UIColor {
        return UIColor(white: 178.0 / 255.0, alpha: 1.0)
    }
}


extension UIColor {
    public convenience init?(hexString: String) {
        let r, g, b, a: CGFloat
        
        if hexString.hasPrefix("#") {
            let start = hexString.characters.index(hexString.startIndex, offsetBy: 1)
            let hexColor = hexString.substring(from: start)
            
            if hexColor.characters.count == 8 {
                let scanner = Scanner(string: hexColor)
                var hexNumber: UInt64 = 0
                
                if scanner.scanHexInt64(&hexNumber) {
                    r = CGFloat((hexNumber & 0xff000000) >> 24) / 255
                    g = CGFloat((hexNumber & 0x00ff0000) >> 16) / 255
                    b = CGFloat((hexNumber & 0x0000ff00) >> 8) / 255
                    a = CGFloat(hexNumber & 0x000000ff) / 255
                    
                    
                    self.init(red: r, green: g, blue: b, alpha: a)
                    return
                }
            }
            
            if hexColor.characters.count == 6 {
                let scanner = Scanner(string: hexColor)
                var hexNumber: UInt64 = 0
                
                if scanner.scanHexInt64(&hexNumber) {
                    r = CGFloat((hexNumber & 0xff0000) >> 16) / 255
                    g = CGFloat((hexNumber & 0x00ff00) >> 8) / 255
                    b = CGFloat(hexNumber & 0x0000ff) / 255
                    a = CGFloat(255)
                    
                    self.init(red: r, green: g, blue: b, alpha: a)
                    return
                }
            }

        }
        
        return nil
    }
}


import UIKit.UIGestureRecognizerSubclass


// This recognizer recognize touch down gesture, and modify navigatedFromWeekPageController flag
class TouchDownGestureRecognizer: UITapGestureRecognizer
{
    var parent: CalendarTableViewController? = nil
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent)
    {
        if self.state == .possible
        {
            //self.state = .Recognized
            
            if parent != nil {
                parent?.navigatedFromWeekPageController = false
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent)
    {
        self.state = .failed
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent)
    {
        self.state = .failed
    }
}


class CopyableLabel: UILabel {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        sharedInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        sharedInit()
    }
    
    func sharedInit() {
        isUserInteractionEnabled = true
        addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(showMenu)))
    }
    
    @objc func showMenu(sender: AnyObject?) {
        becomeFirstResponder()
        let menu = UIMenuController.shared
        if !menu.isMenuVisible {
            menu.setTargetRect(bounds, in: self)
            menu.setMenuVisible(true, animated: true)
        }
    }
    
    override func copy(_ sender: Any?) {
        let board = UIPasteboard.general
        board.string = text
        let menu = UIMenuController.shared
        menu.setMenuVisible(false, animated: true)
    }
    
    override var canBecomeFirstResponder: Bool { return true }
    
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        if action == #selector(UIResponderStandardEditActions.copy) {
            return true
        }
        return false
    }
    
}






