//
//  CalendarWorktimeTableViewCell.swift
//  TimeTracker
//
//  Created by Anton on 13/02/2017.
//  Copyright © 2017 HSE. All rights reserved.
//

import UIKit

class CalendarWorkTimeTableViewCell: UITableViewCell {

    @IBOutlet weak var workTimeLabel: UILabel!
    @IBOutlet weak var line1pxConstraint: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        line1pxConstraint.constant = 1/UIScreen.main.scale
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

