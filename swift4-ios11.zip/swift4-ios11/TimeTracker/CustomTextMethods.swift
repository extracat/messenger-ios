//
//  CustomTextMethods.swift
//  TimeTracker
//
//  Created by Anton on 21/02/2017.
//  Copyright © 2017 HSE. All rights reserved.
//

import Foundation
import UIKit


func convertToString (_ str: String?, whenNil: String = "") -> String {
    if str != nil {
        return str!
    }
    else {return whenNil}
}

func convertToString (_ date: Date?, whenNil: String = "") -> String {
    if date != nil {
        return "\(contvertDateToString(date!)) (\(contvertTimeToString(date!)))"
    }
    else {return whenNil}
}

func convertToString (_ num: Int?, whenNil: String = "") -> String {
    if num != nil {
        return String(describing: num!)
    }
    else {return whenNil}
}

func convertToString (_ num: Float?, whenNil: String = "", fractionDigits: Int = 1) -> String {
    if num != nil {
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = fractionDigits
        
        return formatter.string(for: num) ?? whenNil
    }
    else {return whenNil}
}

func convertToString (_ num: Double?, whenNil: String = "", fractionDigits: Int = 1) -> String {
    if num != nil {
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = fractionDigits
        
        return formatter.string(for: num) ?? whenNil
    }
    else {return whenNil}
}


func search(string: String?, inText: String?) -> Bool {
    
    if inText == nil {return false}
    
    let whitespaceCharacterSet = CharacterSet.whitespaces
    
    let searchString = string?.trimmingCharacters(in: whitespaceCharacterSet).uppercased() ?? ""
    let bigString = inText!.uppercased()

    let searchStringTranslit = searchString.translitToRussian()
    let easterEgg = tryEasterEgg(bigString)

    
    return  bigString.contains(searchString) || bigString.contains(searchStringTranslit) || easterEgg.contains(searchString)
    
}


func search(string: String?, inText: TextAndId?) -> Bool {
    
    if inText == nil {return false}

    if (Int(string ?? "") == inText!.id) {return true}

    return search(string: string, inText: inText!.text)
    
}


func tryEasterEgg(_ string: String) -> String {

    var result = string
    
    let list   = [[  "БОСС"     ,   "BOSS"     ,   "МЕЩЕРЯКОВ"    ],
                  [  "СМАРТ"    ,   "CMART"    ,   "ПАЩЕНКО"      ],
                  [  "ДЕНЬ"     ,   "DAY"      ,   "ХАРИТОНОВ"    ],
                  [  "ШМУЛИК"   ,   "SZMULIK"  ,   "ЛАРЦЕВ"       ],
                  [  "КВИРЧ"    ,   "KVIRCH"   ,   "КРИВОРУЧКО"   ],
                  [  "МАРСАНА"  ,   "MARSANA"  ,   "СОЛДАТОВА"    ],
                  [  "КРИС"     ,   "KRIS"     ,   "КРУТИЛИНА"    ],
                  [  "АНЕЧКА"   ,   "ANECHKA"  ,   "КАРАСЕВА"     ],
                  [  "ТОНИ"     ,   "TONY"     ,   "БАСИСТОВ"     ]]
  
    
    
    
    for item in list {
        result = result.replacingOccurrences(of: item[2], with: "\(item[0]) \(item[1])")
    }
    
    return result

}



extension String {
    
    func translitToRussian() -> String {
        
        var result = self
        
        let list = [ ["SHCH","Щ"],
                     ["SCH","Щ" ],
                     ["YO", "Ё" ],
                     ["ZH", "Ж" ],
                     ["KH", "Х" ],
                     ["CH", "Ч" ],
                     ["SH", "Ш" ],
                     ["TS", "Ц" ],
                     ["YU", "Ю" ],
                     ["YA", "Я" ],
                     ["A" , "А" ],
                     ["B" , "Б" ],
                     ["V" , "В" ],
                     ["G" , "Г" ],
                     ["D" , "Д" ],
                     ["E" , "Е" ],
                     ["Z" , "З" ],
                     ["I" , "И" ],
                     ["Y" , "Й" ],
                     ["J" , "Й" ],
                     ["K" , "К" ],
                     ["L" , "Л" ],
                     ["M" , "М" ],
                     ["N" , "Н" ],
                     ["O" , "О" ],
                     ["P" , "П" ],
                     ["R" , "Р" ],
                     ["S" , "С" ],
                     ["T" , "Т" ],
                     ["U" , "У" ],
                     ["F" , "Ф" ],
                     ["H" , "Х" ],
                     ["C" , "Ц" ],
                     ["Ъ" , "Ъ" ],
                     ["Y" , "Ы" ],
                     ["'" , "Ь" ],
                     ["E" , "Э" ] ]
        
        for item in list {
            result = result.replacingOccurrences(of: item[0], with: item[1])
        }
        
        return result
    }
}


func contvertDateToString(_ date: Date?, format: String = "dd MMMM yyyy") -> String {
    if date != nil {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        
        dateFormatter.locale = Locale(identifier: "ru-RU")
        return dateFormatter.string(from: date!)
    }
    else {return ""}
}

func contvertTimeToString(_ date: Date?, format: String = "HH:mm") -> String {
    if date != nil {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        
        dateFormatter.locale = Locale(identifier: "ru-RU")
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT")
        return dateFormatter.string(from: date!)
    }
    else {return ""}
}

func getWeekdayNameFromNum (_ weekday: Int) -> String
{
    var weekdayName: String
    
    switch weekday {
    case 1:
        weekdayName = "Понедельник"
    case 2:
        weekdayName = "Вторник"
    case 3:
        weekdayName = "Среда"
    case 4:
        weekdayName = "Четверг"
    case 5:
        weekdayName = "Пятница"
    case 6:
        weekdayName = "Суббота"
    case 7:
        weekdayName = "Воскресенье"
    default:
        weekdayName = ""
    }
    return weekdayName
}

func getMonthNameFromNum (_ month: Int, grammaticalCase: GrammaticalCase = .nominative) -> String
{
    var monthName: String
    
    switch grammaticalCase {
    case .prepositional:
        
        switch month {
        case 1:
            monthName = "январе"
        case 2:
            monthName = "феврале"
        case 3:
            monthName = "марте"
        case 4:
            monthName = "апреле"
        case 5:
            monthName = "мае"
        case 6:
            monthName = "июне"
        case 7:
            monthName = "июле"
        case 8:
            monthName = "августе"
        case 9:
            monthName = "сентябре"
        case 10:
            monthName = "октябре"
        case 11:
            monthName = "ноябре"
        case 12:
            monthName = "декабре"
        default:
            monthName = ""
        }
        
        
        
    default:
        
        switch month {
        case 1:
            monthName = "январь"
        case 2:
            monthName = "февраль"
        case 3:
            monthName = "март"
        case 4:
            monthName = "апрель"
        case 5:
            monthName = "май"
        case 6:
            monthName = "июнь"
        case 7:
            monthName = "июль"
        case 8:
            monthName = "август"
        case 9:
            monthName = "сентябрь"
        case 10:
            monthName = "октябрь"
        case 11:
            monthName = "ноябрь"
        case 12:
            monthName = "декабрь"
        default:
            monthName = ""
        }
        
    }
    
    return monthName
    
}

func getMonthName(_ date: Date, grammaticalCase: GrammaticalCase) -> String {
    return getMonthNameFromNum(getMonth(date), grammaticalCase: grammaticalCase)
}


enum GrammaticalCase {
    case nominative
    case genitive
    case dative
    case accusative
    case instrumental
    case prepositional
}


extension String {
    func stringByCleanUpPhoneNumber() -> String? {
        var string = self
        string = string.replacingOccurrences(of: " ", with: "")
        string = string.replacingOccurrences(of: "-", with: "")
        string = string.replacingOccurrences(of: "(", with: "")
        string = string.replacingOccurrences(of: ")", with: "")
        
        return string
    }
}



struct TextAndId {
    var text: String?
    var id: Int?
    
    init (_ text: String?) {
        self.text = text
    }
    init (id: Int?) {
        self.id = id
    }
    init (_ text: String?, id: Int?) {
        self.text = text
        self.id = id
    }
    
    static func ==(left: TextAndId, right: Int) -> Bool {
        return left.id == right
    }
    
    static func ==(left: Int, right: TextAndId) -> Bool {
        return left == right.id
    }
    
    static func ==(left: TextAndId, right: String) -> Bool {
        return left.text == right
    }
    
    static func ==(left: String, right: TextAndId) -> Bool {
        return left == right.text
    }
}

func makeEventGroupString(_ lessonGroups: [JsonGroup]?) -> NSAttributedString {
    
    // Adding icon to the group list
    let attachment = NSTextAttachment()
    attachment.image = UIImage(named: "groupSmallIcon")
    let imageString = NSAttributedString(attachment: attachment)
    
    // Creating group list
    var groupString = ""
    let groupListString = NSMutableAttributedString(string: "")
    
    if lessonGroups == nil { return groupListString }
    
    var n = lessonGroups!.count
    for group in lessonGroups! {
        n -= 1
        let course = group.course ?? 0
        var coursetext = ""
        if (course > 0) {coursetext = String(course) + " курс, "}
        let name = group.name
        var couratorString = ""
        if let courator = group.curator?.surname {couratorString = " (\(courator))"}
        groupString = "\(coursetext)\(name ?? "")\(couratorString)"
        
        let groupItemString = NSMutableAttributedString(string: " " + groupString.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) + (n > 0 ? "\n" : ""))
        groupListString.append(imageString)
        groupListString.append(groupItemString)
    }
    
    let paragraphStyle = NSMutableParagraphStyle()
    paragraphStyle.firstLineHeadIndent = -20.0
    paragraphStyle.headIndent = 20.0
    paragraphStyle.paragraphSpacing = 5.0
    
    groupListString.addAttribute(NSAttributedStringKey.paragraphStyle, value: paragraphStyle, range: NSRange(location: 0,length: groupListString.length))
    
    return groupListString
    
}

func makeEventTutorString(_ tutor: User?) -> NSAttributedString {
    
    // Adding icon to the string
    let attachment = NSTextAttachment()
    attachment.image = UIImage(named: "personSmallIcon")
    let imageString = NSAttributedString(attachment: attachment)
    
    // Creating group list
    
    let tutorString = NSMutableAttributedString(string: "")
    
    let tutorName = "\(tutor?.surname ?? "") \(tutor?.name ?? "") \(tutor?.patronymic ?? "")".trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
    
    if tutorName != "" {
        let tutorItemString = NSMutableAttributedString(string: " " + tutorName)
        tutorString.append(imageString)
        tutorString.append(tutorItemString)
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.firstLineHeadIndent = -16
        paragraphStyle.headIndent = 16
        paragraphStyle.paragraphSpacing = 5.0
        
        tutorString.addAttribute(NSAttributedStringKey.paragraphStyle, value: paragraphStyle, range: NSRange(location: 0,length: tutorString.length))
        
    }
    
    return  tutorString
    
}


