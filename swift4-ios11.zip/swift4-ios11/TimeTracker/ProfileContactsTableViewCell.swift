//
//  ProfileContactsTableViewCell.swift
//  TimeTracker
//
//  Created by Anton on 10/01/2017.
//  Copyright © 2017 HSE. All rights reserved.
//

import UIKit

class ProfileContactsTableViewCell: UITableViewCell {

    @IBOutlet weak var contactLabel: CopyableLabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
