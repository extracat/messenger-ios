//
//  OldModel.swift
//  TimeTracker
//
//  Created by Anton on 01/12/2016.
//  Copyright © 2016 HSE. All rights reserved.
//

import Foundation
import UIKit


/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//////                                                                         //////
//////                            O L D   M O D E L                            //////
//////                                                                         //////
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////


protocol CallbackProtocol {
    func apiRequestDone(_ requestType: OldModelRequestType)
    func apiRequestError(_ requestType: OldModelRequestType, errorMsg: String)
}

protocol CallbackViewControllerProtocol {
    func updateUI()
    func alert(title: String, message: String, action: String)
}



//////////////////////////////////////////////////
//                                              //
//      TIME TABLE (SCHEDULES) DATA MODEL       //
//                                              //
//////////////////////////////////////////////////



//////// Singleton ////////

class LoadedData: TimeTable, CallbackProtocol  {
    
    static let timeTable = LoadedData() // Shared item
    
    var api: ModelApi! ///// This object communicates with sever
    
    var updateThisViewControllers = [CallbackViewControllerProtocol]()
    var alertViewController: CallbackViewControllerProtocol? = nil
    
    var loadedWeeks = [Int]()
    
    
    ////// This method is called then server data recieved
    func apiRequestDone(_ requestType: OldModelRequestType){
        
        switch requestType {
            
            
        case .schedules:
            
            
            for vc in updateThisViewControllers {
                vc.updateUI()
            }
            
            
        default:
            break
        }
        
        
        
    }
    
    ////// This method is called then ERROR recieved
    func apiRequestError(_ requestType: OldModelRequestType, errorMsg: String = ""){
        
        switch requestType {
            
        default:
            break
        }
    }
    
    func clearAllData() {
        
        loadedWeeks.removeAll()
        weeks.removeAll()
        
    }
    
    
    func loadTimeTableDataForWeek(_ weeknum: Int) {
        
        switch LoadedData.timeTable.viewType! {
        case .Person :
            
            if TimeTracker.data.loggedIn {
                
                if loadedWeeks.contains(weeknum) == false {
                    LoadedData.timeTable.clearWeek(weeknum)
                    api.loadTimeTableDataForWeek(TimeTracker.data.token!, weeknum: weeknum, userId: LoadedData.timeTable.viewPersonId)
                    loadedWeeks.append(weeknum)
                }
                
            }
            
            
        case .Group :
            
            
            if loadedWeeks.contains(weeknum) == false {
                LoadedData.timeTable.clearWeek(weeknum)
                api.loadTimeTableDataForWeek(TimeTracker.data.token!, weeknum: weeknum, groupId: LoadedData.timeTable.viewGroupId)
                loadedWeeks.append(weeknum)
            }
                
            
        }
        
        
    }
    
    
    fileprivate override init() {
        super.init()
        api = ModelApi(parent: self)
    }
    
}


enum ViewType {
    case Person
    case Group
}

//////// Base class ////////

class TimeTable {
    
    var viewType: ViewType!
    var viewPersonId: Int?
    var viewPersonName: String? = nil
    var viewGroupId: Int?
    var viewGroupName: String? = nil

    
    var weeks = [TimeTableWeek]()
    
    func getWeekPageIndex(_ state: CalendarViewState) -> Int {
        return state.weeknum
    }
    
    func convertWeekPageIndexToWeekNum(_ weekPageIndex: Int) -> Int {
        return weekPageIndex
    }
    
    func getDayPageIndex(_ state: CalendarViewState) -> Int {
        
        var weekday = state.weekday
        let weekPageIndex = getWeekPageIndex(state)
        
        if weekday < 1 {weekday = 1}
        if weekday > 7 {weekday = 7}
        
        return (weekPageIndex * 7) + (weekday - 1)
        
    }
    
    
    
    func convertDayPageIndexToState(_ dayPageIndex: Int) -> CalendarViewState {
        
        var days = 0
        var weeks = 0
        
        if dayPageIndex >= 0 {
            weeks = dayPageIndex / 7
            days = (dayPageIndex % 7) + 1
        }
        
        if dayPageIndex < 0 {
            weeks = (dayPageIndex - 6) / 7
            days = 7 - (abs(dayPageIndex + 1) % 7)
        }
        
        let state = CalendarViewState(weeknum: weeks, weekday: days)
        return state
        
    }
    
    
    
    func setWeek(_ newweek: TimeTableWeek) -> Bool {
        
        let weeknum = newweek.weekNum
        if weeknum == nil {return false}
        
        if !weekExists(weeknum!) {
            weeks.append(newweek)
            return true
        } else {
            
            var n:Int?
            for week in weeks {
                n = week.weekNum
                if (n != nil) {
                    if (n == weeknum) {
                        week.days = newweek.days
                        return true
                    }
                }
                
            }
        }
        return false
        
    }
    
    func setDay(_ newDay: TimeTableDay, weeknum: Int) -> Bool {
        
        let weekday = newDay.weekDay
        if weekday == nil {return false}
        
        if !weekExists(weeknum) {
            let newweek = TimeTableWeek()
            newweek.days.append(newDay)
            newweek.weekNum = weeknum
            _ = setWeek(newweek)
            return true
        }
        
        var n:Int?
        for week in weeks {
            
            n = week.weekNum
            if n != nil {
                if (n == weeknum) {
                    
                    if !dayExists(CalendarViewState(weeknum: weeknum, weekday: weekday!)) {
                        week.days.append(newDay)
                        return true
                    } else {
                        var m:Int?
                        for day in week.days {
                            m = day.weekDay
                            if m != nil {
                                if (m == weekday) {
                                    day.events = newDay.events
                                    day.date = newDay.date
                                    return true
                                }
                            }
                        }
                    }
                    
                    
                }
            }
            
            
        }
        return false
        
    }
    
    
    func weekExists(_ weeknum: Int) -> Bool {
        
        var n:Int?
        for week in weeks {
            
            n = week.weekNum
            if (n != nil) {
                if (n == weeknum) {return true}
            }
        }
        
        return false
        
    }
    
    func getWeek(_ weeknum: Int) -> TimeTableWeek? {
        
        var n:Int?
        for week in weeks {
            
            n = week.weekNum
            if (n != nil) {
                if (n == weeknum) {return week}
            }
        }
        
        return nil
    }
    
    func dayExists(_ state: CalendarViewState) -> Bool {
        
        if let week = getWeek(state.weeknum) {
            
            var n:Int?
            for day in week.days {
                
                n = day.weekDay
                if (n != nil) {
                    if (n == state.weekday) {return true}
                }
            }
        }
        
        return false
    }
    
    func getDay(_ state: CalendarViewState) -> TimeTableDay? {
        
        if let week = getWeek(state.weeknum) {
            
            var n:Int?
            for day in week.days {
                
                n = day.weekDay
                if (n != nil) {
                    if (n == state.weekday) {return day}
                }
            }
        }
        
        return nil
    }
    
    
    
    func clearDay(_ state: CalendarViewState) {
        
        if let week = getWeek(state.weeknum) {
            
            var n:Int?
            for day in week.days {
                
                n = day.weekDay
                if (n != nil) {
                    if (n == state.weekday) {day.events.removeAll()}
                }
            }
        }
    }
    
    
    func clearWeek(_ weeknum: Int) {
        
        if let week = getWeek(weeknum) {
            week.days.removeAll()
        }
    }
    
    
    
    
    
    func getEvent(_ weekNum: Int, dayNum: Int, eventNum: Int) -> TimeTableEvent? {
        return nil
    }
    
}

class TimeTableWeek {
    //var dataIsLoaded: Bool = false
    var days = [TimeTableDay]()
    var weekNum:Int? = nil
}

class TimeTableDay {
    var events = [TimeTableEvent]()
    var date: Date? = nil
    var weekDay:Int? = nil
}


class TimeTableEvent {
    
    var id: Int? = nil
    var moduleCourseId: Int? = nil
    var eventIndex: String? = nil
    var lessonNumber: Int? = nil
    
    var isViewWithTotalMarks: Bool = false
    var pairKey: String? = nil
    
    var date: Date? = nil
    var startingTime: Date? = nil
    var endingTime: Date? = nil
    
    var disciplineId:Int? = nil
    var typeId:Int? = nil
    var typeName: String? = nil
    var typeColor: String? = nil

    var title: String? = nil
    var lessonGroups = [JsonGroup]()
    
    var lessonComment: String? = nil
    var roomNumber: String? = nil
    
    
    var weekDay: Int? = nil
    var duration: String? = nil
    
    var lessonTutor: User? = nil
    
    var categoty: EventCategory? = nil
    
    var isExam: Bool = false
    var isExamView: Bool = false
    var isBreak: Bool = false
    var userCanReadSheet: Bool = false
    var userCanEditSheet: Bool = false
    var timeIntervalName: String? = nil
    var numberInDay: Int? = nil
    
}


// Common definitions


enum EventCategory {
    case lesson
    case exam
    case prosmotr
    case freetime
}



