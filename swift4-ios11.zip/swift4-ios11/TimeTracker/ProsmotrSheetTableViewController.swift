//
//  ProsmotrSheetTableViewController.swift
//  TimeTracker
//
//  Created by Anton on 26/08/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

struct ProsmotrCell {
    var projectTitle: String
    var authors: NSAttributedString?
    var mark: Int?
    var projectId: Int
    var moduleCourseId: Int
}

class ProsmotrSheetPresenter {
    
    weak private var myView : ProsmotrSheetTableViewController?
    
    func attachView(view:ProsmotrSheetTableViewController){
        myView = view
    }
    
    func detachView() {
        myView = nil
    }
    
    var date: Date?
    var scheduleId: Int?
    
    var sheet: ProsmotrSheet?
    var sheetCount: Int {return sheet?.data.count ?? 0}
    
    
    var event: TimeTableEvent? {
        didSet {
            date = event?.date
            scheduleId = event?.id
        }
    }
    var title: String?
    
    func updateTableData() {
        if sheet != nil && event != nil{
            
            myView?.userCanEditSheet = event!.userCanEditSheet
            
            //// Header
            
            // Clear all labels
            
            myView?.tableData.eventTitle = nil
            myView?.tableData.eventLessonGroup = nil
            myView?.tableData.eventLessonComment = nil
            myView?.tableData.eventDateAndTime = nil
            myView?.tableData.eventColor = nil
            
            // Updating labels
            myView?.tableData.eventTitle = event?.title
            myView?.tableData.eventLessonComment = event?.lessonComment
            myView?.tableData.eventColor = event?.typeColor

            myView?.tableData.eventLessonGroup = makeEventGroupString(event?.lessonGroups)
            
            
            myView?.tableData.eventDateAndTime = ""
            if let date = event!.date {myView?.tableData.eventDateAndTime! += contvertDateToString(date, format: "dd MMMM")}
            if let startingTime = event!.startingTime {myView?.tableData.eventDateAndTime! += ", " + contvertTimeToString(startingTime)}
            
            
            /// List
            myView?.tableData.list.removeAll()
            for item in sheet!.data {
                if item.userProjectId != nil && item.userProject != nil {

                    let projectId = item.userProjectId!
                    let project = item.userProject!
                    
                    let moduleCourseId = project.moduleCourseId!
                    let projectTitle = "\(project.title ?? "")"
                    let mark = item.mark

                    // Adding icon to the group list
                    let attachment = NSTextAttachment()
                    attachment.image = UIImage(named: "personSmallIcon")
                    let imageString = NSAttributedString(attachment: attachment)
                    
                    
                    // Creating authors list
                    //var authorsString = ""
                    let authorsListString = NSMutableAttributedString(string: "")
                    
                    var n = project.authors.count
                    for author in project.authors {
                        n -= 1
                        let nameString = "\(author.surname ?? "") \(author.name ?? "")"
                        
                        let authorItemString = NSMutableAttributedString(string: " " + nameString.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) + (n > 0 ? "\n" : ""))
                        authorsListString.append(imageString)
                        authorsListString.append(authorItemString)
                    }
                    
                    let paragraphStyle = NSMutableParagraphStyle()
                    paragraphStyle.firstLineHeadIndent = -20.0
                    paragraphStyle.headIndent = 20.0
                    paragraphStyle.paragraphSpacing = 5.0
                    
                    authorsListString.addAttribute(NSAttributedStringKey.paragraphStyle, value: paragraphStyle, range: NSRange(location: 0,length: authorsListString.length))
                 
                 
                    let cell = ProsmotrCell(projectTitle: projectTitle, authors: authorsListString, mark: mark, projectId: projectId, moduleCourseId: moduleCourseId)
                    
                    myView?.tableData.list.append(cell)
                }
            }
            myView?.tableView.reloadData()
        }
    }
    
    
    func refreshTableData() {
        loadTableData()
    }
    
    func loadTableData() {
        
        if (date == nil || scheduleId == nil) {
            Debug.mode.output("Attendance Sheet: parameters not set", type: .error)
            return
        }
        
        let callBackStatus = TimeTracker.data.getSheet(type: .prosmotr, date: date!, scheduleId: scheduleId!, completionHandler: {(sheet, requestStatus) in
            
            //// Analysing Callback
            switch requestStatus {
                
            case .success:
                //// If request was successful
                
                self.sheet = sheet as! ProsmotrSheet?
                self.updateTableData()
                
            case .error(let errorMsg):
                //// If there was an error
                
                self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
                
            }
        })
        
        Debug.mode.output("CallBackStatus: \(callBackStatus)", type: .none)
    }
    
    
    func saveMark(moduleCourseId: Int, projectId: Int, mark: Int) {

        let callBackStatus = TimeTracker.data.saveProsmotrMark(moduleCourseId: moduleCourseId, projectId: projectId, mark: mark, completionHandler: {(requestStatus) in
            
            //// Analysing Callback
            switch requestStatus {
                
            case .success:
                //// If request was successful
                
                self.loadTableData()
                
            case .error(let errorMsg):
                //// If there was an error
                
                self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
                
            }
        })
        Debug.mode.output("CallBackStatus: \(callBackStatus)", type: .none)
        
    }
    
    
    
}



class ProsmotrSheetTableViewController: UITableViewController {

    var presenter = ProsmotrSheetPresenter()
    
    struct TableData {
        var eventTitle: String?
        var eventLessonGroup: NSAttributedString?
        var eventLessonComment: String?
        var eventDateAndTime: String?
        var eventColor: String?
        
        var list = [ProsmotrCell]()
    }
    
    var tableData = TableData()
    var tableTitle: String? = ""
    var userCanEditSheet: Bool = false

    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter.attachView(view: self)
        
        // Cell's height
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 44
        
        presenter.loadTableData()
    }
    
    func alert (title: String, message: String, action: String){
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: action, style: UIAlertActionStyle.default, handler: { action in
            switch action.style{
            case .default:
                break
                
            case .cancel:
                break
                
            case .destructive:
                break
            }
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        return tableData.list.count + 1  // one cell for header
    }
    
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return tableTitle
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        /////////// First cell will be the header ////////////
        if (indexPath.row == 0) {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Examination Sheet Header", for: indexPath)
            
            if let thisCell = cell as? ExaminationSheetTableViewHeaderCell {
                // SENDING DATA TO CELL
                
                thisCell.eventTitle?.text = tableData.eventTitle
                thisCell.eventLessonGroup?.attributedText = tableData.eventLessonGroup
                thisCell.eventLessonComment?.text = tableData.eventLessonComment
                thisCell.eventDateAndTime?.text = tableData.eventDateAndTime
                if (tableData.eventColor != nil) {
                    thisCell.eventColorBar?.backgroundColor = UIColor(hexString: tableData.eventColor!)
                }
            }
            
            // Removing bottom line in 1st cell
            cell.separatorInset = UIEdgeInsetsMake(0, 0, 0, cell.bounds.size.width - 8);
            
            return cell
        }

        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Prosmotr Sheet Cell", for: indexPath)
        
        // Configure the cell...
        
        let thisCellItem = tableData.list[indexPath.row - 1] // first cell for header
        
        if let thisCell = cell as? ProsmotrSheetTableViewCell {
            
            // SENDING MODEL DATA TO CELL
            thisCell.projectId = thisCellItem.projectId
            thisCell.moduleCourseId = thisCellItem.moduleCourseId
            thisCell.labelTitle?.text = thisCellItem.projectTitle
            

            if thisCellItem.mark != nil {
                thisCell.labelMark?.text = String(thisCellItem.mark!)
            }
            else {
                thisCell.labelMark?.text = "—"
            }
            
            if (userCanEditSheet) {
                if (thisCellItem.mark == nil) {
                    thisCell.labelMark?.text = "Оценить"
                    thisCell.labelMark?.textColor = UIColor.lightGray
                }
                else {
                    thisCell.labelMark?.textColor = UIColor.ttDuskBlueColor()
                }
            }
            
            thisCell.labelAuthors?.attributedText = thisCellItem.authors
            
        }
        
        return cell
        
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        
        if segue.identifier == "Show Modal View" {
            if let modalViewController = (segue.destination as? ExamModalViewController)
            {
                let cell = sender as? ProsmotrSheetTableViewCell
                
                modalViewController.sheetType = .prosmotr
                modalViewController.tabBar = self.tabBarController?.tabBar
                modalViewController.mark = (cell?.labelMark?.text)!
                modalViewController.projectTitle = (cell?.labelTitle.text)!
                modalViewController.projectId = cell?.projectId
                modalViewController.moduleCourseId = cell?.moduleCourseId
                modalViewController.vcParent = self
            }
        }
        
        
        
    }
    
    
    override func shouldPerformSegue(withIdentifier identifier: String?, sender: Any?) -> Bool {
        
        if let ident = identifier {
            if ident == "Show Modal View" {
                if (!userCanEditSheet) {
                    return false
                }
            }
        }
        
        return true
    }
 
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        //self.navigationController?.navigationBar.backItem?.title = "Назад"
        
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        
    }
    
    
}
