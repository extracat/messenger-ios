//
//  TimeTrackerModel.swift
//  TimeTracker
//
//  Created by Anton on 07/06/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import Foundation
import UIKit


//////// Singleton ////////

class TimeTracker: TimeTrackerData {
    static let data = TimeTracker() // Shared item
    private override init() {}      // Disable initialisation
}


class TimeTrackerData {
    ///// BEGIN class TimeTrackerData /////
    
    var api = ServerApi()
    var loginResult = LoginResult()
    var loggedUser = User()
    var token: String? {return loginResult.token}
    var loggedUserId: Int? {return loggedUser.id}
    var login: String? = nil
    var password: String? = nil
    var loggedIn: Bool {
        if loginResult.token != nil && loginResult.status != nil {
            if loginResult.status == .success {return true}
        }
        return false
    }
    
    
    
    ////////////////////////////////////////////////////////////////////////
    ////////////
    ////////////     Необходимо оптимизировать этот параметр !!!!!
    ////////////
    ////////////////////////////////////////////////////////////////////////
    var loggedUserRole: LoggedUserRole {
        var role = LoggedUserRole.unregistered
        if self.loggedUser.rights != nil {
            for right in self.loggedUser.rights! {
                switch right {
                case .Student:
                    role = .studentOnly
                    
                case .Projects:
                    role = .teachingAndProjects
                    return role
                    
                case .Teaching:
                    role = .teachingAndProjects
                    return role
                
                default:
                    break

                }
            }
        }
        return role
    }
    
    
    ///////////////////    Model Data  ////////////////////
    
    var usersLists = [UsersList]()
    var users = [User]()
    
    var groupsLists = [GroupsList]()
    
    var projectsLists = [ProjectsList]()
    var projects = [Project]()
    
    var usersProjectsWorktimeData = [UsersProjectsWorktimeData]()
    
    var sheets = Array<Sheet>()
 
    var events = [TimeTableEvent]()
    
    ///////////////////////////////////////////////////////

    

    
    ///// Model Interface /////
    
    func login(login: String, password: String, completionHandler: @escaping (User?, RequestStatus) -> Void) -> CallbackStatus{
        api.login(login: login, password: password, completionHandler: {(loginResult) in
            self.loginResult = loginResult

            if loginResult.status == .success {
                
                self.api.loadLoginUserData(token: loginResult.token!, completionHandler: {(jsonUserData, requestStatus) in
                    
                    switch requestStatus {
                    case .success:
                        self.loggedUser.setByJsonUserData(jsonUserData: jsonUserData)
                        self.loggedUser.loadedData = true
                        DispatchQueue.main.async {completionHandler(self.loggedUser, .success)}
                    case .error(let errorMsg):
                        DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                    }
                    
                })

                
            }
            else {
                DispatchQueue.main.async {completionHandler(nil, .error("Не был произведен логин"))}
                Debug.mode.output("Attempt to get data before login", type: .error)
            }

        })
        return CallbackStatus.pending
    }
    
    
    func logout() {

        // Deleting Model Data
        
        loginResult = LoginResult()
        loggedUser = User()
        login  = nil
        password = nil
        usersLists = [UsersList]()
        users = [User]()
        groupsLists = [GroupsList]()
        projectsLists = [ProjectsList]()
        projects = [Project]()
        usersProjectsWorktimeData = [UsersProjectsWorktimeData]()
        sheets = Array<Sheet>()
        
        // Deleting Old Model Data
        
        LoadedData.timeTable.viewPersonId = nil
        LoadedData.timeTable.viewPersonName = nil
        LoadedData.timeTable.viewGroupId = nil
        LoadedData.timeTable.viewGroupName = nil
        LoadedData.timeTable.weeks = [TimeTableWeek]()
        LoadedData.timeTable.loadedWeeks = [Int]()
        
        clearLogin()
        
    }
    
    
    
    func getLoggedUserData(needToRefresh: Bool = false, completionHandler: @escaping (User?, RequestStatus) -> Void) -> CallbackStatus {
        
        /////// LOGIN CHECK ///////
        if !loggedIn {
            DispatchQueue.main.async {completionHandler(nil, .error("Не был произведен логин"))}
            Debug.mode.output("Attempt to get data before login", type: .error)
            return CallbackStatus.error
        }//////////////////////////
        
        if loggedUser.loadedData && !needToRefresh {
            
            DispatchQueue.main.async {completionHandler(self.loggedUser, .success)}
            return CallbackStatus.alreadyLoaded
            
        } else {
            
            api.loadLoginUserData(token: token!, completionHandler: {(jsonUserData, requestStatus) in
                
                switch requestStatus {
                case .success:
                    self.loggedUser.setByJsonUserData(jsonUserData: jsonUserData)
                    self.loggedUser.loadedData = true
                    DispatchQueue.main.async {completionHandler(self.loggedUser, .success)}
                case .error(let errorMsg):
                    DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                }
                
            })
            
            return CallbackStatus.pending
        }
    }
    
    func getUserData(userId: Int, needToRefresh: Bool = false, completionHandler: @escaping (User?, RequestStatus) -> Void) -> CallbackStatus {
        
        var user = users.getById(id: userId)
        if user == nil {
            user = User()
        }
        
        if user!.loadedData && !needToRefresh {
            DispatchQueue.main.async {completionHandler(user, .success)}
            return CallbackStatus.alreadyLoaded
            
        } else {
            
            api.loadUserData(token: token, userId: userId, completionHandler: {(jsonUserData, requestStatus) in
                
                switch requestStatus {
                case .success:
                    user = self.users.getById(id: userId)
                    if user == nil {
                        user = User()
                    }
                    user!.setByJsonUserData(jsonUserData: jsonUserData)
                    user!.loadedData = true
                    self.users.set(user: user!)
                    DispatchQueue.main.async {completionHandler(user, .success)}
                case .error(let errorMsg):
                    DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                }
                
            })
            
            return CallbackStatus.pending
        }
    }
    
    func getUserStatistics(userId: Int, date: Date = getDateForProfileStatistics(), needToRefresh: Bool = false, completionHandler: @escaping (User?, RequestStatus) -> Void) -> CallbackStatus {
        
        /////// LOGIN CHECK ///////
        if !loggedIn {
            DispatchQueue.main.async {completionHandler(nil, .error("Не был произведен логин"))}
            Debug.mode.output("Attempt to get data before login", type: .error)
            return CallbackStatus.error
        }//////////////////////////
        
        let month = date.firstDateOfMonth()   
        
        var user = users.getById(id: userId)
        if user == nil {
            user = User()
        }
        
        if user!.statistics.getByFilter(date: month) != nil && !needToRefresh {
            DispatchQueue.main.async {completionHandler(user, .success)}
            return CallbackStatus.alreadyLoaded
            
        } else {
            
            api.loadUserStatistics (token: token!, userId: userId, date: month, completionHandler: {(jsonUserStatistics, requestStatus) in
                
                switch requestStatus {
                case .success:
                    user = self.users.getById(id: userId)
                    if user == nil {
                        user = User()
                    }
                    
                    user!.statistics.set(stat: StatisticsForMonth(stat: jsonUserStatistics, month: month))
                    self.users.set(user: user!)
                    DispatchQueue.main.async {completionHandler(user, .success)}
                
 
                case .error(let errorMsg):
                    DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                }
                
            })
            
            return CallbackStatus.pending
        }
    }
    
    func getUserWorkTimes(userId: Int, needToRefresh: Bool = false, completionHandler: @escaping (User?, RequestStatus) -> Void) -> CallbackStatus {
        
        /////// LOGIN CHECK ///////
        if !loggedIn {
            DispatchQueue.main.async {completionHandler(nil, .error("Не был произведен логин"))}
            Debug.mode.output("Attempt to get data before login", type: .error)
            return CallbackStatus.error
        }//////////////////////////
        
        var user = users.getById(id: userId)
        if user == nil {
            user = User()
        }
        
        if user!.workTime.count > 0 && !needToRefresh {
            DispatchQueue.main.async {completionHandler(user, .success)}
            return CallbackStatus.alreadyLoaded
            
        } else {
            
            api.loadUserWorkTimes (token: token!, userId: userId, completionHandler: {(JsonUserWorkTime, requestStatus) in
                
                switch requestStatus {
                case .success:
                    user = self.users.getById(id: userId)
                    if user == nil {
                        user = User()
                    }
                    
                    if JsonUserWorkTime != nil {user!.workTime = JsonUserWorkTime!}
                    self.users.set(user: user!)
                    DispatchQueue.main.async {completionHandler(user, .success)}
                    
                    
                case .error(let errorMsg):
                    DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                }
                
            })
            
            return CallbackStatus.pending
        }
    }
    
    
    
    func getUserImage(userId: Int, needToRefresh: Bool = false, completionHandler: @escaping (User?, RequestStatus) -> Void) -> CallbackStatus {
        
        var user = users.getById(id: userId)
        if user == nil {
            user = User()
        }
        
        if user!.loadedImage && !needToRefresh {
            DispatchQueue.main.async {completionHandler(user, .success)}
            return CallbackStatus.alreadyLoaded
            
        } else {
            
            if (user!.loadedData) {
                
                //// Load image form server
                self.loadImage(user: user!, completionHandler: {(user) in
                    self.users.set(user: user)
                    DispatchQueue.main.async {completionHandler(user, .success)}
                })
                
            }
            else {
                /////// Load User Data
                api.loadUserData(token: token, userId: userId, completionHandler: {(jsonUserData, requestStatus) in
                    
                    switch requestStatus {
                    case .success:
                        user = self.users.getById(id: userId)
                        if user == nil {
                            user = User()
                        }
                        user!.setByJsonUserData(jsonUserData: jsonUserData)
                        user!.loadedData = true
                        self.users.set(user: user!)
                        
                        //// Load image form server
                        self.loadImage(user: user!, completionHandler: {(user) in
                            self.users.set(user: user)
                            DispatchQueue.main.async {completionHandler(user, .success)}
                        })
                        
                    case .error(let errorMsg):
                        DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                    }
                    
                })
                /////////
            }
            
            
            return CallbackStatus.pending
        }
        
    }
    
    
    func getLoggedUserImage(needToRefresh: Bool = false, completionHandler: @escaping (User?, RequestStatus) -> Void) -> CallbackStatus {
        
        /////// LOGIN CHECK ///////
        if !loggedIn {
            DispatchQueue.main.async {completionHandler(nil, .error("Не был произведен логин"))}
            Debug.mode.output("Attempt to get data before login", type: .error)
            return CallbackStatus.error
        }//////////////////////////
        
        
        if loggedUser.loadedImage && !needToRefresh {
            DispatchQueue.main.async {completionHandler(self.loggedUser, .success)}
            return CallbackStatus.alreadyLoaded
            
        } else {
            
            if (loggedUser.loadedData) {
                
                //// Load image form server
                self.loadImage(user: loggedUser, completionHandler: {(user) in
                    self.loggedUser = user
                    DispatchQueue.main.async {completionHandler(user, .success)}
                })
                
            }
            else {
                /////// Load User Data
                api.loadLoginUserData(token: token!, completionHandler: {(jsonUserData, requestStatus) in
                    
                    switch requestStatus {
                    case .success:
                    
                        self.loggedUser.setByJsonUserData(jsonUserData: jsonUserData)
                        self.loggedUser.loadedData = true
                        
                        //// Load image form server
                        self.loadImage(user: self.loggedUser, completionHandler: {(user) in
                            self.loggedUser = user
                            DispatchQueue.main.async {completionHandler(user, .success)}
                        })
                        
                    case .error(let errorMsg):
                        DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                    }
                    
                })
                /////////
            }
            
            
            return CallbackStatus.pending
        }
        
    }
    

    
    func loadImage(user: User, completionHandler: @escaping (User) -> Void) {
        
        if let url = URL(string: user.imageUrl ?? "") {
            DispatchQueue.global(qos: DispatchQoS.QoSClass.userInitiated).async {
                let contentsOfURL = try? Data(contentsOf: url)
                DispatchQueue.main.async {
                    ///////////////
                    Debug.mode.output("Image URL: \(url)")
                    if let imageData = contentsOfURL {
                        user.image = UIImage(data: imageData)
                        user.loadedImage = true
                    } else {
                        user.loadedImage = true
                        Debug.mode.output("loadImage(): ignored data returned from url", type: .error)
                    }
                    DispatchQueue.main.async {completionHandler(user)}
                    return
                    //////////////
                }
            }
        }
        DispatchQueue.main.async {completionHandler(user)}
    }
    
    
    func getProjectsList(filter: ProjectsListFiter? = nil,
                         needToRefresh: Bool = false,
                         completionHandler: @escaping ([JsonProjectData]?, ProjectsListFiter?, RequestStatus) -> Void) -> CallbackStatus {
        
        /////// LOGIN CHECK ///////
        if !loggedIn {
            DispatchQueue.main.async {completionHandler(nil, filter, .error("Не был произведен логин"))}
            Debug.mode.output("Attempt to get data before login", type: .error)
            return CallbackStatus.error
        }//////////////////////////
        
        let filteredList = projectsLists.getByFilter(filter: filter)
    
        
        if ((filteredList?.loaded) ?? false) && !needToRefresh {
            DispatchQueue.main.async {completionHandler(filteredList?.list, filter, .success)}
            return CallbackStatus.alreadyLoaded
            
        } else {

            if needToRefresh {
                projectsLists.remove(userId: filter?.userId)
            }
            
            api.loadProjectsList(token: token!,
                                 userId: filter?.userId,
                                 status: filter?.status,
                                 startDate: filter?.inInterval?.start,
                                 endDate: filter?.inInterval?.end,
                                 startedFromDate: filter?.startedInInterval?.start,
                                 startedToDate: filter?.startedInInterval?.end,
                                 endedFromDate: filter?.endedInInterval?.start,
                                 endedToDate: filter?.endedInInterval?.end,

                                 workTimeFromDate: filter?.workTimeInInterval?.start,
                                 workTimeToDate: filter?.workTimeInInterval?.end,
                                 hasEfficiency: filter?.hasEfficiency,
                                 
                                 completionHandler: {(jsonProjectList, requestStatus) in
                
                switch requestStatus {
                case .success:
                    let list = ProjectsList()
                    list.list = jsonProjectList
                    list.filter = filter
                    list.loaded = true
                    self.projectsLists.set(projectsList: list)
                    DispatchQueue.main.async {completionHandler(jsonProjectList, filter, .success)}
                    
                case .error(let errorMsg):
                    DispatchQueue.main.async {completionHandler(nil, filter, .error(errorMsg))}
                }
                
            })
            
            return CallbackStatus.pending
        }
    }
    
    
    func getUsersProjectsWorktimeData(projects: [JsonProjectData],
                                      userId: Int,
                                      timeInterval: DatesInterval? = nil,
                                      needToRefresh: Bool = false,
                                      completionHandler: @escaping ([UsersProjectsWorktimeData]?, RequestStatus) -> Void) -> CallbackStatus {
        
        /////// LOGIN CHECK ///////
        if !loggedIn {
            DispatchQueue.main.async {completionHandler(nil, .error("Не был произведен логин"))}
            Debug.mode.output("Attempt to get data before login", type: .error)
            return CallbackStatus.error
        }//////////////////////////
        


        api.loadProjectsWorktime(token: token!,
                                 projects: projects,
                                 userId: userId,
                                 startDate: timeInterval?.start,
                                 endDate: timeInterval?.end,
                                 completionHandler: {(jsonProjects, requestStatus) in
                                
                                switch requestStatus {
                                case .success:
                                    var array = [UsersProjectsWorktimeData]()
                                    if jsonProjects != nil {
                                        for project in jsonProjects! {
                                            let usersProjectsWorktimeData = UsersProjectsWorktimeData(userId: userId, project: project, timeInterval: timeInterval)
                                            array.append(usersProjectsWorktimeData)
                                        }
                                    }
                                    
                                    //self.usersProjectsWorktimeData.set(array)
                                    
                                    DispatchQueue.main.async {completionHandler(array, .success)}
                                    
                                case .error(let errorMsg):
                                    DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                                }
                                
        })
        
        return CallbackStatus.pending
        
    }

    
    func getProjectData(projectId: Int, needToRefresh: Bool = false, completionHandler: @escaping (Project?, RequestStatus) -> Void) -> CallbackStatus {
        
        /////// LOGIN CHECK ///////
        if !loggedIn {
            DispatchQueue.main.async {completionHandler(nil, .error("Не был произведен логин"))}
            Debug.mode.output("Attempt to get data before login", type: .error)
            return CallbackStatus.error
        }//////////////////////////
        
        var project = projects.getById(id: projectId)
        if project == nil {
            project = Project()
        }
        
        if project!.loaded && !needToRefresh {
            DispatchQueue.main.async {completionHandler(project, .success)}
            return CallbackStatus.alreadyLoaded
            
        } else {
            
            api.loadProjectData(token: token!, projectId: projectId, completionHandler: {(jsonProjectData, requestStatus) in
                
                switch requestStatus {
                case .success:
                    project = self.projects.getById(id: projectId)
                    if project == nil {
                        project = Project()
                    }
                    project!.setByJsonProjectData(jsonProjectData: jsonProjectData)
                    project!.loaded = true
                    self.projects.set(project: project!)
                    DispatchQueue.main.async {completionHandler(project, .success)}
                case .error(let errorMsg):
                    DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                }
                
            })
            
            return CallbackStatus.pending
        }
    }
    
    
    func getUsersList(needToRefresh: Bool = false, right: EnumUserRights = .Teaching, completionHandler: @escaping ([JsonUserData]?, RequestStatus) -> Void) -> CallbackStatus {
      
        if ((usersLists.getByFilter(filterRight: right)?.loaded) ?? false) && !needToRefresh {
            
            DispatchQueue.main.async {completionHandler(self.usersLists.getByFilter(filterRight: right)?.list, .success)}
            return CallbackStatus.alreadyLoaded
            
        } else {
            
            api.loadUsersList(token: token, right: right, completionHandler: {(jsonUsersList, requestStatus) in
                
                switch requestStatus {
                case .success:
                    let list = UsersList()
                    list.list = jsonUsersList
                    list.filterRight = right
                    list.loaded = true
                    self.usersLists.set(usersList: list)
                    DispatchQueue.main.async {completionHandler(jsonUsersList, .success)}
                case .error(let errorMsg):
                    DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                }
                
            })
            
            return CallbackStatus.pending
        }
    }
    
    
    
    
    func getGroupsList(filter: GroupsListFiter? = nil,
                       needToRefresh: Bool = false,
                       includeDirections: Bool? = false,
                       includeDisciplines: Bool? = false,
                       includeCurators: Bool? = true,
                       completionHandler: @escaping ([JsonGroup]?, RequestStatus) -> Void) -> CallbackStatus {
        
        
        let filteredList = groupsLists.getByFilter(filter: filter)
        
        
        if ((filteredList?.loaded) ?? false) && !needToRefresh {
            DispatchQueue.main.async {completionHandler(filteredList?.list, .success)}
            return CallbackStatus.alreadyLoaded
            
        } else {
            
            if needToRefresh {
                projectsLists.removeAll()
            }
        
            api.loadGroupsList(token: token,
                           directionId: filter?.directionId,
                           learningType: filter?.learningType,
                           learningForm: filter?.learningForm,
                           course: filter?.course,
                           academicYear: filter?.academicYear,
                           currentYearOnly: filter?.currentYearOnly,
                           includeDirections: includeDirections,
                           includeDisciplines: includeDisciplines,
                           includeCurators: includeCurators,
                           completionHandler: {(jsonGroupsList, requestStatus) in
                
                switch requestStatus {
                case .success:
                    
                    let list = GroupsList()
                    list.list = jsonGroupsList
                    list.filter = filter
                    list.loaded = true
                    self.groupsLists.set(list: list)

                    DispatchQueue.main.async {completionHandler(jsonGroupsList, .success)}
                case .error(let errorMsg):
                    DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                }
                
            })
            
            return CallbackStatus.pending
        }
    }
    
    
    
    

    func getEvents(startDate: Date,
                   endDate: Date,
                   userId: Int? = nil,
                   groupId: Int? = nil,
                   needToRefresh: Bool = false,
                   completionHandler: @escaping ([TimeTableEvent]?, RequestStatus) -> Void) -> CallbackStatus {
        
        api.loadSchedules(token: token!,
                          startDate: startDate,
                          endDate: endDate,
                          userId: userId,
                          groupId: groupId,
                          completionHandler: {(newEvents, requestStatus) in
            
            switch requestStatus {
            case .success:
                
                if newEvents != nil {
                    for newEvent in newEvents! {
                       
                        
                        let oldEvent = self.events.getById(id: newEvent.id!)
                        if oldEvent == nil {
                            self.events.append(newEvent)
                        }
                        else {
                            self.events.set(event: newEvent)
                        }
                        
                        
                    }
                }
                

                DispatchQueue.main.async {completionHandler(newEvents, .success)}
                
            case .error(let errorMsg):
                DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
            }
            
        })
        
        return CallbackStatus.pending
        
    }
    
    
    
    
    func getSheet(type: SheetType, date: Date, scheduleId: Int, needToRefresh: Bool = true, completionHandler: @escaping (Sheet?, RequestStatus) -> Void) -> CallbackStatus {
        
        /////// LOGIN CHECK ///////
        if !loggedIn {
            DispatchQueue.main.async {completionHandler(nil, .error("Не был произведен логин"))}
            Debug.mode.output("Attempt to get data before login", type: .error)
            return CallbackStatus.error
        }//////////////////////////
        
        switch type {
        case .attendance:
            let sheet = self.sheets.getByFilter(type: type, date: date, scheduleId: scheduleId) as? AttendanceSheet
            
            if (sheet?.loaded ?? false) && !needToRefresh {
                DispatchQueue.main.async {completionHandler(sheet, .success)}
                return CallbackStatus.alreadyLoaded
                
            } else {
                
                api.loadAttendanceSheet (token: token!, date: date, scheduleId: scheduleId, completionHandler: {(sheetData, requestStatus) in
                    
                    switch requestStatus {
                    case .success:
                        let sheet = AttendanceSheet()
                        if sheetData != nil {sheet.data = sheetData!}
                    
                        sheet.scheduleId = scheduleId
                        sheet.date = date
                        sheet.type = type
                    
                        sheet.loadingTime = Date()
                        sheet.loaded = true

                        self.sheets.set(sheet: sheet)
                        DispatchQueue.main.async {completionHandler(sheet, .success)}
                    case .error(let errorMsg):
                        DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                    }
                    
                })
                
                return CallbackStatus.pending
            }

            
        case .examination:
            let sheet = self.sheets.getByFilter(type: type, date: date, scheduleId: scheduleId) as? ExaminationSheet
            
            if (sheet?.loaded ?? false) && !needToRefresh {
                DispatchQueue.main.async {completionHandler(sheet, .success)}
                return CallbackStatus.alreadyLoaded
                
            } else {
                
                api.loadExaminationSheet (token: token!, date: date, scheduleId: scheduleId, completionHandler: {(sheetData, requestStatus) in
                    
                    switch requestStatus {
                    case .success:
                        let sheet = ExaminationSheet()
                        if sheetData != nil {sheet.data = sheetData!}
                        
                        sheet.scheduleId = scheduleId
                        sheet.date = date
                        sheet.type = type
                        
                        sheet.loadingTime = Date()
                        sheet.loaded = true
                        
                        self.sheets.set(sheet: sheet)
                        DispatchQueue.main.async {completionHandler(sheet, .success)}
                    case .error(let errorMsg):
                        DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                    }
                    
                })
                
                return CallbackStatus.pending
            }
            
        case .prosmotr:
            let sheet = self.sheets.getByFilter(type: type, date: date, scheduleId: scheduleId) as? ProsmotrSheet
            
            if (sheet?.loaded ?? false) && !needToRefresh {
                DispatchQueue.main.async {completionHandler(sheet, .success)}
                return CallbackStatus.alreadyLoaded
                
            } else {
                
                api.loadProsmotrSheet (token: token!, date: date, scheduleId: scheduleId, completionHandler: {(sheetData, requestStatus) in
                    
                    switch requestStatus {
                    case .success:
                        let sheet = ProsmotrSheet()
                        if sheetData != nil {sheet.data = sheetData!}
                        
                        sheet.scheduleId = scheduleId
                        sheet.date = date
                        sheet.type = type
                        
                        sheet.loadingTime = Date()
                        sheet.loaded = true
                        
                        self.sheets.set(sheet: sheet)
                        DispatchQueue.main.async {completionHandler(sheet, .success)}
                    case .error(let errorMsg):
                        DispatchQueue.main.async {completionHandler(nil, .error(errorMsg))}
                    }
                    
                })
                
                return CallbackStatus.pending
            }
            
        }   
    }
    

    
    func saveAttendanceChecks(date: Date, scheduleId: Int, students: [JsonAttendanceSheetItem], completionHandler: @escaping (RequestStatus) -> Void) -> CallbackStatus  {
        
        /////// LOGIN CHECK ///////
        if !loggedIn {
            DispatchQueue.main.async {completionHandler(.error("Не был произведен логин"))}
            Debug.mode.output("Attempt to get data before login", type: .error)
            return CallbackStatus.error
        }//////////////////////////
        
        
        api.saveAttendanceChecks(token: token!, date: date, scheduleId: scheduleId, students: students, completionHandler: completionHandler)
        return CallbackStatus.pending
    }
    
    
    func saveExamMark(moduleCourseId: Int, studentId: Int, mark: Int, completionHandler: @escaping (RequestStatus) -> Void) -> CallbackStatus  {
        
        /////// LOGIN CHECK ///////
        if !loggedIn {
            DispatchQueue.main.async {completionHandler(.error("Не был произведен логин"))}
            Debug.mode.output("Attempt to get data before login", type: .error)
            return CallbackStatus.error
        }//////////////////////////
        
        
        api.saveExamMark(token: token!, moduleCourseId: moduleCourseId, studentId: studentId, mark: mark, completionHandler: completionHandler)
        return CallbackStatus.pending
    }
    
    
    func saveProsmotrMark(moduleCourseId: Int, projectId: Int, mark: Int, completionHandler: @escaping (RequestStatus) -> Void) -> CallbackStatus  {
        
        /////// LOGIN CHECK ///////
        if !loggedIn {
            DispatchQueue.main.async {completionHandler(.error("Не был произведен логин"))}
            Debug.mode.output("Attempt to get data before login", type: .error)
            return CallbackStatus.error
        }//////////////////////////
        
        
        api.saveProsmotrMark(token: token!, moduleCourseId: moduleCourseId, projectId: projectId, mark: mark, completionHandler: completionHandler)
        return CallbackStatus.pending
    }
    
    
    
    
    
    
    
    ///////////// Login Funcs /////////////////
    
    
    func saveLogin() {
        let defaults = UserDefaults.standard
        defaults.setValue(self.login, forKey: "Login")
        defaults.setValue(self.password, forKey: "Password")
        defaults.synchronize()
    }
    
    func readLogin() {
        let defaults = UserDefaults.standard
        if let login = defaults.string(forKey: "Login") {
            self.login = login
        }
        if let password = defaults.string(forKey: "Password") {
            self.password = password
        }
    }
    
    func clearLogin(){
        let defaults = UserDefaults.standard
        defaults.setValue("", forKey: "Login")
        defaults.setValue("", forKey: "Password")
        defaults.synchronize()
    }
    

    
    
    ///// END class TimeTrackerData /////
}
