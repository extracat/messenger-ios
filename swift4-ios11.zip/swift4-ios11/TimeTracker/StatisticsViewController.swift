//
//  StatisticsViewController.swift
//  TimeTracker
//
//  Created by Anton on 22/12/2016.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class StatisticsPresenter {
    weak private var myView : StatisticsViewController?
    
    func attachView(view:StatisticsViewController){
        myView = view
    }
    
    func detachView() {
        myView = nil
    }
    
    var loggedUserRole: LoggedUserRole {
        return TimeTracker.data.loggedUserRole
    }
    
    var profilePresenter: ProfilePresenter? {
        didSet {
            userId = profilePresenter?.userId
        }
    }

    var userId: Int?
    var month = Date()
    
    var index: Int = 0 {
        didSet {
            month = month.addMonths(index).firstDateOfMonth()
        }
    }
    
    var user: User? {
        didSet{
            if user != nil {
                
                /// User Stat
                self.myView?.effValue = user!.statistics.getByFilter(date: month)?.stat?.efficiency
                self.myView?.projectsWorkLoadValue = user!.statistics.getByFilter(date: month)?.stat?.projectsWorkLoadK
                self.myView?.projectsPlanLoadValue = user!.statistics.getByFilter(date: month)?.stat?.projectsPlanLoadK
                self.myView?.schedulesLoadValue = user!.statistics.getByFilter(date: month)?.stat?.schedulesLoadK
                
                self.myView?.absentValue = user!.statistics.getByFilter(date: month)?.stat?.absentK
                self.myView?.noWorkProjectsValue = user!.statistics.getByFilter(date: month)?.stat?.noWorkProjectsLoadK
                self.myView?.latenessValue = user!.statistics.getByFilter(date: month)?.stat?.schedulesWithLatenessCount
                
                let year = getYear(month)
                var yearString = ""
                if year != getTodayYear() {yearString = " \(year)"}
                
                self.myView?.monthLabel?.text = "В \(getMonthName(month, grammaticalCase: .prepositional))\(yearString)"
                
                self.myView?.updateUI()
                
            }
        }
    }
    
    var statisticsCallbackStatus: CallbackStatus = CallbackStatus.pending

    
    func loadData(needToRefresh: Bool = false) {
        
        if userId != nil {
            statisticsCallbackStatus = TimeTracker.data.getUserStatistics(userId: userId!, date: month, needToRefresh: needToRefresh, completionHandler: updateUserData)
        }
    }
    
    func updateUserData(user: User?, requestStatus: RequestStatus) {
        
        //// Analysing Callback
        switch requestStatus {
            
        case .success:
            //// If request was successful
            
            self.user = user
            
        case .error( _):
            //// If there was an error
            
            break
            
        }
        
    }

    
}


class StatisticsViewController: UIViewController {

    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var schedulesLoadBar: SchedulesLoadHistogramBar!
    @IBOutlet weak var projectsWorkLoadBar: ProjectsWorkLoadHistogramBar!
    @IBOutlet weak var projectsPlanLoadBar: ProjectsPlanLoadHistogramBar!
    @IBOutlet weak var effBar: EffHistogramBar!
    
    @IBOutlet weak var latenessLabel: UILabel!
    @IBOutlet weak var noWorkProjectsLoadBar: NoWorkProjectsLoadHistogramBar!
    @IBOutlet weak var absentBar: AbsentHistogramBar!
    
    var presenter = StatisticsPresenter()

    
    
    var absentValue: Float? {
        didSet{
            updateAbsent()
        }
    }
    var noWorkProjectsValue: Float? {
        didSet{
            updateNoWorkProjects()
        }
    }
    var latenessValue: Int? {
        didSet{
            if latenessValue != nil {
                if latenessValue! > 0 {
                    latenessLabel.text = "Опозданий на занятия: \(convertToString(latenessValue))"
                }
                else {
                    latenessLabel.text = "Опозданий на занятия нет"
                }
            }
            else {
                latenessLabel.text = "Опозданий на занятия нет"
            }
        }
    }
    
    
    var effValue: Float? {
        didSet{
            updateEff()
        }
    }
    var projectsWorkLoadValue: Float?{
        didSet{
            updateProjectsWorkLoad()
        }
    }
    var projectsPlanLoadValue: Float?{
        didSet{
            updateProjectsPlanLoad()
        }
    }
    var schedulesLoadValue: Float?{
        didSet{
            
            updateSchedulesLoad()
            
            projectsWorkLoadBar.schedulesLoad = schedulesLoadValue
            projectsPlanLoadBar.schedulesLoad = schedulesLoadValue

            updateProjectsWorkLoad()
            updateProjectsPlanLoad()
        }
    }

    
    override func viewDidAppear(_ animated: Bool) {
        presenter.profilePresenter?.month = presenter.month
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        presenter.attachView(view: self)
        
        // Do any additional setup after loading the view.
        
        /// init
        updateUI()
        presenter.loadData()
        
        if presenter.statisticsCallbackStatus == .pending {
            self.monthLabel?.text = "Загружается..."
        }

    }
    
    func updateUI() {
        updateEff()
        updateProjectsWorkLoad()
        updateProjectsPlanLoad()
        updateSchedulesLoad()
        updateAbsent()
        updateNoWorkProjects()
    }

    fileprivate func updateEff() {
        if effValue != nil {
            effBar.textHidden = false
            effBar.value = effValue!
        }
        else {
            effBar.textHidden = true
        }
    }
    
    fileprivate func updateProjectsWorkLoad() {
        if projectsWorkLoadValue != nil {
            projectsWorkLoadBar.textHidden = false
            projectsWorkLoadBar.value = projectsWorkLoadValue!
        }
        else {
            projectsWorkLoadBar.textHidden = true
        }
    }
    
    
    fileprivate func updateProjectsPlanLoad() {
        if projectsPlanLoadValue != nil {
            projectsPlanLoadBar.textHidden = false
            projectsPlanLoadBar.value = projectsPlanLoadValue!
        }
        else {
            projectsPlanLoadBar.textHidden = true
        }
    }
    
    fileprivate func updateSchedulesLoad() {
        if schedulesLoadValue != nil {
            schedulesLoadBar.textHidden = false
            schedulesLoadBar.value = schedulesLoadValue!
        }
        else {
            schedulesLoadBar.textHidden = true
        }
    }
    
    
    fileprivate func updateAbsent() {
        if absentValue != nil {
            absentBar.textHidden = false
            absentBar.value = absentValue!
        }
        else {
            absentBar.textHidden = true
        }
    }
    
    fileprivate func updateNoWorkProjects() {
        if noWorkProjectsValue != nil {
            noWorkProjectsLoadBar.textHidden = false
            noWorkProjectsLoadBar.value = noWorkProjectsValue!
        }
        else {
            noWorkProjectsLoadBar.textHidden = true
        }
    }


}
