//
//  ProjectInfoTableViewController.swift
//  TimeTracker
//
//  Created by Anton on 21/12/2016.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit


class ProjectInfoPresenter {
    weak private var myView : ProjectInfoTableViewController?
    
    func attachView(view:ProjectInfoTableViewController){
        myView = view
    }
    
    func detachView() {
        myView = nil
    }
    
    var projectId: Int?
    
    var project: Project? {
        didSet{
            if project != nil {
                
                /// UserData for All logged users
                self.myView?.tableData.name = project!.name

                self.myView?.tableData.efficiency = project!.efficiency
                self.myView?.tableData.workTimeInHours = project!.workTimeInHours
                self.myView?.tableData.costInHours = project!.costInHours
                self.myView?.tableData.status = String(describing: project!.status?.rawValue)
                self.myView?.tableData.deadline = project!.deadline

                self.myView?.tableData.coordinator = TextAndId("\(project!.coordinator?.surname ?? "") \(project!.coordinator?.name ?? "")", id: project!.coordinator?.id )
                
                if project!.users != nil {
                    self.myView?.tableData.projectTeam.removeAll()
                    for user in project!.users! {
                        self.myView?.tableData.projectTeam.append(TextAndId("\(user.surname ?? "") \(user.name ?? "")", id: user.id ))
                    }
                }
                
                self.myView?.tableView.reloadData()
                
            }
        }
    }

    
    
    
    func refreshTableData() {
        loadTableData(needToRefresh: true)
    }
    
    func loadTableData(needToRefresh: Bool = false) {
        
        if projectId == nil {
            self.myView?.alert(title: "Ошибка", message: "Не задан проект", action: "ОК")
            return
        }
        
        
        _ = TimeTracker.data.getProjectData(projectId: projectId!, needToRefresh: needToRefresh, completionHandler: updateProjectsData)
        
    }
    
    
    func updateProjectsData(project: Project?, requestStatus: RequestStatus) {
        
        //// Analysing Callback
        switch requestStatus {
            
        case .success: 
            //// If request was successful
            self.project = project
            
        case .error(let errorMsg):
            //// If there was an error
            
            self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
            
        }
        
    }
    
}



class ProjectInfoTableViewController: UITableViewController {
    let presenter = ProjectInfoPresenter()
    
    struct TableData {
        var name: String?
        var efficiency: Float?
        var workTimeInHours: Float?
        var costInHours: Float?
        var status: String?
        var deadline: Date?
        var coordinator: TextAndId?
        
        var projectTeam = [TextAndId]()
    }
    var tableData = TableData()
    
    
    
    struct TableSection {  // Defines Sections in this table
        var id = ""
        var title = ""
        var heightForHeader = CGFloat(24.0)
        var heightForFooter = CGFloat(24.0)
        
    }
    fileprivate var tableSections = [TableSection]()
    
    
    func alert(title: String, message: String, action: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: action, style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter.attachView(view: self)
        
        // Defines Sections in this table
        
        tableSections.append(TableSection(id: "header", title: "",                heightForHeader: CGFloat.leastNormalMagnitude,   heightForFooter: CGFloat(24.0) ))
        tableSections.append(TableSection(id: "coord",  title: "Координатор",     heightForHeader: CGFloat(24.0), heightForFooter: CGFloat(24.0)  ))
        tableSections.append(TableSection(id: "team",   title: "Команда проекта", heightForHeader: CGFloat(24.0), heightForFooter: CGFloat(24.0)  ))
     
        
        /// Cell's height
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 44
        
        
        // Loading DATA
        presenter.loadTableData()
        
        
    }



    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return tableSections.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        let id = tableSections[section].id
        
        switch id {
            
        case "header":
            return 1
  
        case "coord":
            return 1

        case "team": 
            return tableData.projectTeam.count
            
            
        default:
            return 0
        }
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = UITableViewCell()
        
        let id = tableSections[indexPath.section].id
        
        switch id {
            
        case "header": // Name, photo, etc section
            
            cell = tableView.dequeueReusableCell(withIdentifier: "Project Header Cell", for: indexPath)
            if let thisCell = cell as? ProjectInfoHeaderTableViewCell {
 
                thisCell.projectNameLabel?.text = tableData.name
                thisCell.effValue = tableData.efficiency
                thisCell.projectWorkTimeLabel?.text = convertToString(tableData.workTimeInHours, whenNil: "Нет")
                thisCell.projectCostLabel?.text = convertToString(tableData.costInHours, whenNil: "Нет")
                thisCell.projectDeadlineLabel?.text = convertToString(tableData.deadline, whenNil: "Нет")
                //thisCell.projectCoordinatorLabel?.text = convertToString(tableData.coordinator?.text, whenNil: "Нет")

            }
            
        case "coord": // Coordinator
            
            cell = tableView.dequeueReusableCell(withIdentifier: "Project Team Cell", for: indexPath)

            if let thisCell = cell as? TableViewCellWithID {
                thisCell.textLabel?.text = convertToString(tableData.coordinator?.text, whenNil: "Нет")
                thisCell.id = tableData.coordinator?.id
            }
            
            
        case "team": // Project list section
            
            cell = tableView.dequeueReusableCell(withIdentifier: "Project Team Cell", for: indexPath)
            if tableData.projectTeam.count > 0 {
                if let thisCell = cell as? TableViewCellWithID {
                    thisCell.textLabel?.text = tableData.projectTeam[indexPath.row].text
                    thisCell.id = tableData.projectTeam[indexPath.row].id
                }
            }
            
            
            default:
            break
        }
        
        return cell

    }
 
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return tableSections[section].title
        
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return tableSections[section].heightForHeader
        
    }
    
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        return tableSections[section].heightForFooter
        
    }
    

    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "Show User Profile" {
            if let vc = (segue.destination as? ProfileTableViewController) {
                let id = (sender as? TableViewCellWithID)?.id
                if id != nil {
                    vc.presenter.userId = id
                }
                
            }
        }
        
    }


}
