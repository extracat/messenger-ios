//
//  ProjectInfoHeaderTableViewCell.swift
//  TimeTracker
//
//  Created by Anton on 10/01/2017.
//  Copyright © 2017 HSE. All rights reserved.
//

import UIKit

class ProjectInfoHeaderTableViewCell: UITableViewCell {

    @IBOutlet weak var projectNameLabel: UILabel!
    @IBOutlet weak var projectEffBar: EffHistogramBar!
    @IBOutlet weak var projectWorkTimeLabel: UILabel!
    @IBOutlet weak var projectCostLabel: UILabel!
    @IBOutlet weak var projectManagerLabel: UILabel!
    @IBOutlet weak var projectDeadlineLabel: UILabel!
    @IBOutlet weak var projectCoordinatorLabel: UILabel!

    
    var effValue: Float? {
        didSet{
            updateEff()
        }
    }

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        updateEff()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    fileprivate func updateEff() {
        if effValue != nil {
            projectEffBar.textHidden = false
            projectEffBar.value = effValue!
        }
        else {
            projectEffBar.textHidden = true
        }
    }
    
}

