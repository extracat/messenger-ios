//
//  ProjectsTableViewController.swift
//  TimeTracker
//
//  Created by Anton on 26/10/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class ProjectsPresenter {
    weak private var myView : ProjectsTableViewController?
    
    func attachView(view:ProjectsTableViewController){
        myView = view
    }
    
    func detachView() {
        myView = nil
    }
    
    var userId: Int?
    
    var projectsStatus: EnumProjectStatus?
    
    var projects = [JsonProjectData]() {
        didSet{
            
            /// Projects
            self.myView?.tableData.projects.removeAll()
            for project in projects {
                var projectStatusString = ""
                if project.status == .completed {projectStatusString = "✓ "}
                if project.status == .inProgress {projectStatusString = "▹ "}
                
                let projectNameString = "\(projectStatusString)\(project.name ?? "")"
                self.myView?.tableData.projects.append(TextAndId(projectNameString, id: project.id))
            }
            
            self.myView?.tableView.reloadData()
            
        }
    }
    
    
    
    
    func refreshTableData() {
        loadTableData(needToRefresh: true)
    }
    
    func loadTableData(needToRefresh: Bool = false) {
        
        if userId == nil {
            self.myView?.alert(title: "Ошибка", message: "Не задан пользователь", action: "ОК")
            return
        }
        
        
        var filter = ProjectsListFiter()
        filter.userId = userId!
        filter.status = projectsStatus
        _ = TimeTracker.data.getProjectsList(filter: filter, needToRefresh: needToRefresh, completionHandler: updateProjectsData)
        
    }
    
    
    func updateProjectsData(projectsList: [JsonProjectData]?, filter: ProjectsListFiter?, requestStatus: RequestStatus) {
        
        //// Analysing Callback
        switch requestStatus {
            
        case .success:
            //// If request was successful
            self.projects.removeAll()
            if projectsList != nil {
                self.projects = projectsList!
            }
            
        case .error(let errorMsg):
            //// If there was an error
            
            self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
            
        }
        
    }
    
}



class ProjectsTableViewController: UITableViewController {
    let presenter = ProjectsPresenter()
    
    struct TableData {
        var projects = [TextAndId]()
    }
    
    
    
    var tableData = TableData()
    
    
    
    struct TableSection {  // Defines Sections in this table
        var id = ""
        var title = ""
        var heightForHeader = CGFloat(24.0)
        var heightForFooter = CGFloat(24.0)
        
    }
    fileprivate var tableSections = [TableSection]()
    
    
    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
        
        presenter.refreshTableData()
        refreshControl.endRefreshing()
        
    }
    
    
    func alert(title: String, message: String, action: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: action, style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter.attachView(view: self)
        
        // Defines Sections in this table
        tableSections.append(TableSection(id: "projects",   title: "\(self.title ?? "") проекты",   heightForHeader: CGFloat(48.0), heightForFooter: CGFloat(24.0)  ))
        
        
        /// Cell's height
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 140
        
        // Loading DATA
        presenter.loadTableData()
        
        // Refresher
        self.refreshControl?.addTarget(self, action: #selector(ProjectsTableViewController.handleRefresh(_:)), for: UIControlEvents.valueChanged)
        
        
        
        
    }
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return tableSections.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        let id = tableSections[section].id
        
        switch id {
            
        case "projects": // Project list section
            return tableData.projects.count
            
            
        default:
            return 0
        }
        
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = UITableViewCell()
        
        let id = tableSections[indexPath.section].id
        
        switch id {
            
            
        case "projects": // Project list section
            
            cell = tableView.dequeueReusableCell(withIdentifier: "Projects List Cell", for: indexPath)
            if tableData.projects.count > 0 {
                if let thisCell = cell as? TableViewCellWithID {
                    thisCell.textLabel?.text = tableData.projects[indexPath.row].text
                    thisCell.id = tableData.projects[indexPath.row].id
                }
            }
            
        default:
            break
        }
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return tableSections[section].title
        
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return tableSections[section].heightForHeader
        
    }
    
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        return tableSections[section].heightForFooter
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.tableView.deselectRow(at: indexPath, animated: true)
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        if segue.identifier == "Show Project Info" {
            if let vc = (segue.destination as? ProjectInfoTableViewController) {
                let id = (sender as? TableViewCellWithID)?.id
                if id != nil {
                    vc.presenter.projectId = id
                    vc.title = self.title
                }
                
            }
        }
        
        
    }
    
}

