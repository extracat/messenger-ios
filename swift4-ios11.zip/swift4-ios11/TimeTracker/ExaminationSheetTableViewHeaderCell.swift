//
//  ExaminationSheetTableViewHeaderCell.swift
//  TimeTracker
//
//  Created by Anton on 07/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class ExaminationSheetTableViewHeaderCell: UITableViewCell {

    
    @IBOutlet weak var eventColorBar: UIView!
    @IBOutlet weak var eventTitle: UILabel!
    @IBOutlet weak var eventLessonGroup: UILabel!
    @IBOutlet weak var eventLessonComment: UILabel!
    @IBOutlet weak var eventDateAndTime: UILabel!
    @IBOutlet weak var markInfoLabel: UILabel!



    override func setSelected(_ selected: Bool, animated: Bool) {
        //super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code

    }
    
    
  
}
