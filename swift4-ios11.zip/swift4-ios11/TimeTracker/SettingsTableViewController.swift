//
//  SettingsTableViewController.swift
//  TimeTracker
//
//  Created by Anton on 22/06/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class SettingsPresenter {
    
    weak private var myView : SettingsTableViewController?
    
    func attachView(view:SettingsTableViewController){
        myView = view
    }
    
    func detachView() {
        myView = nil
    }
    
    var user: User?
    
    func updateTableData() {
    
        myView?.profileEmail?.text = user?.email
        myView?.tableView.reloadData()
    }
    
    func loadTableData(needToRefresh: Bool = false) {
        
        _ = TimeTracker.data.getLoggedUserData(completionHandler: { (user, requestStatus) in
            
            //// Analysing Callback
            switch requestStatus {
                
            case .success:
                //// If request was successful
                
                self.user = user
                self.updateTableData()
                
            case .error(let errorMsg):
                //// If there was an error
                
                self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
                
            }
        })
        

    }
    

    
}


class SettingsTableViewController: UITableViewController {
    
    var presenter = SettingsPresenter()
    
    @IBOutlet weak var profileEmail: UILabel!
    @IBAction func logoutButtonTapped(_ sender: Any) {
        
        TimeTracker.data.logout()
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "Login View")
        self.present(nextViewController, animated:false, completion:nil)

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter.attachView(view: self)
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        
        self.numberOfSections(in: self.tableView)
        
        presenter.loadTableData()
    }
    

    
    
    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        if section == self.numberOfSections(in: self.tableView) - 1 {
            let buildNum = Bundle.main.infoDictionary?["CFBundleVersion"] as? String
            let versionNum = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String
            return "Версия приложения: \(versionNum ?? "") (\(buildNum ?? ""))\nВерсия API: \(ServerApi.version)"
        }
        return nil
    }
    

    override func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        if indexPath.section == 1 && indexPath.row == 1 {
            UIApplication.shared.openURL(URL(string: "https://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?id=1137134361&onlyLatestVersion=true&pageNumber=0&sortOrdering=1&type=Purple+Software")!)
            return nil
        }
        
        if indexPath.section == self.numberOfSections(in: self.tableView) - 1 && indexPath.row == 0 {
            return nil
        }
        
        return indexPath
    }

    
    
    
    
    func alert (title: String, message: String, action: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: action, style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "Show Logged User Profile" {
            if let vc = (segue.destination as? ProfileTableViewController) {
                vc.presenter.userId = presenter.user?.id
            }
        }
        
    }
    

}
