//
//  testAndDebug.swift
//  TimeTracker
//
//  Created by Anton on 07/09/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import Foundation


class Debug { // Singleton
    
    static let mode = Debug() // Shared item
    
    private var enabled = false
    private var slowInternet = false
    
    private var slowValue: UInt32 = 3 // Internet slowdown in seconds
    
    // If you need slow connection
    func internetSlowConnection() {
        if enabled && slowInternet && slowValue > 0 { sleep(slowValue) }
    }
    
    
    func output (_ str: Any, type: DebugMessageType = .info) {
    
        if enabled {
            
            var msgType = ""
            switch type {
            case .info:
                msgType = "INFO: "
            case .warning:
                msgType = "WARNING: "
            case .error:
                msgType = "ERROR: "
            case .none:
                msgType = ""
            }
        
            print ("\(msgType)\(String(describing: str))")
            
        }
    }
    
    

    
    fileprivate init() {
    }
    
}

enum DebugMessageType {
    case error
    case warning
    case info
    case none
}



