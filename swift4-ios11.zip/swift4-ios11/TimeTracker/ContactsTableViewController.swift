//
//  ContactsTableViewController.swift
//  TimeTracker
//
//  Created by Anton on 12/10/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class ContactsPresenter {
    
    weak private var myView : ContactsTableViewController?
    
    func attachView(view:ContactsTableViewController){
        myView = view
    }
    
    func detachView() {
        myView = nil
    }
    
    
    var usersList: [JsonUserData]? {
        didSet {
            self.myView?.tableData.removeAll()
            if usersList != nil {
                for user in usersList! {
                    let tableCellText = "\(user.surname ?? "") \(user.name ?? "")"
                    let textForCell = TextAndId(tableCellText, id: user.id)
                    self.myView?.tableData.append(textForCell)
                }
            }
            self.myView?.tableView.reloadData()
        }
    }
    
    
    func refreshTableData() {
        loadTableData(needToRefresh: true)
    }
    
    func loadTableData(needToRefresh: Bool = false) {
        
        let callBackStatus = TimeTracker.data.getUsersList(needToRefresh: needToRefresh, right: .Projects, completionHandler: {(usersList, requestStatus) in
            
            //// Analysing Callback
            switch requestStatus {
                
            case .success:
                //// If request was successful
                
                self.usersList = usersList
                
            case .error(let errorMsg):
                //// If there was an error
                
                self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
                
            }
        })
        
        Debug.mode.output("CallBackStatus: \(callBackStatus)", type: .none)
        
        if TimeTracker.data.loggedIn {
            _ = TimeTracker.data.getLoggedUserData(needToRefresh: needToRefresh, completionHandler: updateUserData)
            _ = TimeTracker.data.getLoggedUserImage(needToRefresh: needToRefresh, completionHandler: updateUserData)
        }

        
    }
    
    func updateUserData(user: User?, requestStatus: RequestStatus) {
        
        //// Analysing Callback
        switch requestStatus {
            
        case .success:
            //// If request was successful
            
            self.myView?.myContactCellData.surname = user!.surname ?? ""
            self.myView?.myContactCellData.fullName = "\(user!.name ?? "") \(user!.patronymic ?? "")"
            self.myView?.myContactCellData.image = user!.image
            self.myView?.myContactCellData.email = user!.email ?? ""
            self.myView?.myContactCellData.phone = user!.phone ?? ""
            
        case .error(let errorMsg):
            //// If there was an error
            
            self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
            
        }
        
    }

    
}


class ContactsTableViewController: UITableViewController, UISearchBarDelegate, UISearchControllerDelegate, UISearchResultsUpdating  {
    
    let presenter = ContactsPresenter()
    
    
    struct MyContactCellData {
        var surname: String?
        var fullName: String?
        var email: String?
        var phone: String?
        var image: UIImage?
    }
    
    var myContactCellData = MyContactCellData()
    var tableData = [TextAndId]()
    var filteredTableData = [TextAndId]()
    var resultSearchController = UISearchController()
    
    func alert(title: String, message: String, action: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: action, style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
        
        presenter.refreshTableData()
        
        refreshControl.endRefreshing()
        
    }
    
    
    
    ////// Table Protocol
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        presenter.attachView(view: self)
        
        self.resultSearchController = ({
            let controller = UISearchController(searchResultsController: nil)
            controller.searchResultsUpdater = self
            controller.dimsBackgroundDuringPresentation = false
            controller.searchBar.sizeToFit()
            
            self.tableView.tableHeaderView = controller.searchBar
            
            return controller
        })()
        
        /// Cell's height
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 140

        
        // Loading DATA
        presenter.loadTableData()
        
        // Refresher
        self.refreshControl?.addTarget(self, action: #selector(ContactsTableViewController.handleRefresh(_:)), for: UIControlEvents.valueChanged)
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.resultSearchController.isActive) {
            return self.filteredTableData.count
        }
        else {
            
            var firstCell = 0
            if TimeTracker.data.loggedIn {firstCell = 1} // First cell will be "my contact"
            
            return self.tableData.count + firstCell
            
        }
        
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        

        /////////// First cell will be "my contact" ////////////
        if (indexPath.row == 0 && !self.resultSearchController.isActive && TimeTracker.data.loggedIn) {
            
            // Name, photo, etc section
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "My Contact Cell", for: indexPath)
            if let thisCell = cell as? MyContactTableViewCell {
                
                
                thisCell.labelLastName?.text = myContactCellData.surname
                thisCell.labelName?.text = myContactCellData.fullName
                thisCell.userImage = myContactCellData.image
                thisCell.id = TimeTracker.data.loggedUserId
                
            }
            return cell
        }
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Contact List Cell", for: indexPath) as! TableViewCellWithID
        
        if (self.resultSearchController.isActive) {
            cell.textLabel?.text = filteredTableData[indexPath.row].text
            cell.id = filteredTableData[indexPath.row].id
            return cell
        }
        else {
            
            var firstCell = 0
            if TimeTracker.data.loggedIn {firstCell = 1} // First cell will be "my contact"
            
            cell.textLabel?.text = tableData[indexPath.row - firstCell].text
            cell.id = tableData[indexPath.row - firstCell].id
            return cell
        }
        
        

        
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "Show User Profile" {
            if let vc = (segue.destination as? ProfileTableViewController) {
                let id = (sender as? TableViewCellWithID)?.id
                if id != nil {
                    vc.presenter.userId = id
                    self.resultSearchController.isActive = false
                }
                
            }
        }
        
        if segue.identifier == "Show My Profile" {
            if let vc = (segue.destination as? ProfileTableViewController) {
                let id = (sender as? MyContactTableViewCell)?.id
                if id != nil {
                    vc.presenter.userId = id
                    self.resultSearchController.isActive = false
                }
                
            }
        }
        
    }
    
    
    
    // Search Protocols
    
    
    
    // These methods are called when automatic presentation or dismissal occurs. They will not be called if you present or dismiss the search controller yourself.
    
    func willPresentSearchController(_ searchController: UISearchController)
    {
        
    }
    
    func didPresentSearchController(_ searchController: UISearchController)
    {
        
    }
    func willDismissSearchController(_ searchController: UISearchController)
    {
        
    }
    func didDismissSearchController(_ searchController: UISearchController)
    {
        
    }
    // Called after the search controller's search bar has agreed to begin editing or when 'active' is set to YES. If you choose not to present the controller yourself or do not implement this method, a default presentation is performed on your behalf.
    
    func presentSearchController(_ searchController: UISearchController)
    {
        
    }
    
    
    func updateSearchResults(for searchController: UISearchController)
    {
        
        filteredTableData.removeAll(keepingCapacity: false)
        
        for user in tableData {
            if search(string: searchController.searchBar.text, inText: user) {
                filteredTableData.append(user)
            }
        }
        self.tableView.reloadData()
        
    }
    
    
    
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool // return NO to not become first responder
    {
        return true
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) // called when text starts editing
    {
        
    }
    
    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool // return NO to not resign first responder
    {
        return true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) // called when text ends editing
    {
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) // called when text changes (including clear)
    {
        
    }
    
    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool // called before text changes
    {
        return true
    }
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) // called when keyboard search button pressed
    {
        
    }
    
    func searchBarBookmarkButtonClicked(_ searchBar: UISearchBar) // called when bookmark button pressed
    {
        
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) // called when cancel button pressed
    {
        
    }
    
    func searchBarResultsListButtonClicked(_ searchBar: UISearchBar) // called when search results button pressed
    {
        
    }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int)
    {
        
    }
    
   
    
}
