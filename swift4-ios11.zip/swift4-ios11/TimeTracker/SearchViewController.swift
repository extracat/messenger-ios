//
//  SearchGroupsViewController.swift
//  TimeTracker
//
//  Created by Anton on 20/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController {

    var searchTableViewController: SearchTableViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        
        self.searchTableViewController = self.storyboard?.instantiateViewController(withIdentifier: "Search Table View Controller") as! SearchTableViewController
        
        self.searchTableViewController.view.frame = CGRect(x: 0, y: 50, width: self.view.frame.size.width, height: self.view.frame.size.height - 50)
        self.addChildViewController(self.searchTableViewController)
        self.view.addSubview(self.searchTableViewController.view)
        self.searchTableViewController.didMove(toParentViewController: self)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
}
