//
//  ModelApi.swift
//  TimeTracker
//
//  Created by Anton on 11/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import Foundation
import UIKit



class ModelApi: NSObject {
    
    let parent: CallbackProtocol
    init(parent: CallbackProtocol) {
        self.parent = parent
    }
    
    var requestStatus: OldModelRequestStatus = .none
    var requestType: OldModelRequestType = .none
    
    fileprivate func requestStatus(_ requestStatus: OldModelRequestStatus, requestType: OldModelRequestType = .none, message: String = "") {
        
        self.requestStatus = requestStatus
        self.requestType = requestType
        
        switch requestStatus {
        case .none:
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            
        case .pending:
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
            
        case .error:
            DispatchQueue.main.async {
                self.parent.apiRequestError(requestType, errorMsg: message)
            }
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            
        case .done:
            DispatchQueue.main.async {
                self.parent.apiRequestDone(requestType)
            }
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
        }
    }
    
 
      
    // MARK: async task  
    // All Data come with this method
    
    func task(api: String,
              method: HTTPMethod,
              headers: [String: Any]?,
              arguments: [String: Any]?,
              callback: @escaping (_ response: HTTPURLResponse?, _ json: Any?, _ error: Error?) -> ()) {
        let config = URLSessionConfiguration.default
        
        var path = "http://api.design.hse.ru/v1.1/" + api
        
        if headers != nil {
            config.httpAdditionalHeaders = headers
        }
        
        if (method == .GET || method == .POST) && arguments != nil {
            path += "?"
            
            var first = true
            for key in arguments!.keys {
                if !first {path += "&"}
                path += "\(key)=\(arguments![key]!)"
                first = false
            }
        }
        
        let url = URL(string: path.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!)!
        Debug.mode.output(url)
        let request = NSMutableURLRequest(url: url)
        request.httpMethod = method == .POST ? "POST" : method.rawValue
        request.setValue("application/json", forHTTPHeaderField:"Accept")
        let session = URLSession(configuration: config)
        let task = session.dataTask(with: request as URLRequest, completionHandler: { (data: Data?, response: URLResponse?, error: Error?) in
            var json: Any? = nil
            do {
                if data != nil {
                    json = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.init(rawValue: 0))
                }
            } catch {
                Debug.mode.output("error json: \(error)", type: .error)
            }
            
            Debug.mode.internetSlowConnection() // If you need slow connection
            
            callback(response as? HTTPURLResponse, json, error)
        }) 
        task.resume()
    }
    
    
    
    
    //////////////////////////////////////
    //                                  //
    //           SCHEDULES API          //
    //                                  //
    //////////////////////////////////////
    
   
    /*
    
    // MARK: Load timetable data
    func loadTimeTableData (_ token: String?,
                              startDate: Date,
                              endDate: Date,
                              avatarWidth: Int = User.imageSize,
                              avatarHeight: Int = User.imageSize,
                              userId: Int? = nil,
                              groupId: Int? = nil) {
        
        self.requestStatus(.pending, requestType: .schedules)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yyyy"
  
        let startDateString = dateFormatter.string(from: startDate)
        let endDateString = dateFormatter.string(from: endDate)

        
        var arguments = ["startDate": startDateString,
                         "endDate": endDateString,
                         "avatarWidth": String(avatarWidth),
                         "avatarHeight": String(avatarHeight)]
        
        if userId != nil {arguments["userId"] = String(userId!)}
        if groupId != nil {arguments["groupId"] = String(groupId!)}
        
        task(api: "/schedules", method: .GET, headers: ["token": token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil {
                self.requestStatus(.error, requestType: .schedules, message: "API error")
                
            } else {
                
                var eventArray = [TimeTableEvent]()
                
                let array = json as? [[String:Any]]
                if (array == nil) {
                    self.requestStatus(.error, requestType: .schedules, message: "Response is empty")
                    return
                }
                
                for item in array! {

                    let eventItem = parseJsonTimeTable(item)
                    
                    if let pairKey = eventItem.pairKey {
                        if  pairKey != "" &&
                            pairKey == eventArray.last?.pairKey &&
                            eventItem.disciplineId == eventArray.last?.disciplineId {
                            
                            eventArray.last?.endingTime = eventItem.endingTime
                        }
                        else {eventArray.append(eventItem)}
                    }
                    else {eventArray.append(eventItem)}
               
                }
                
              
                
                /////////// Set Datastructure /////////
                
                //let startState = getCalendarStateFromDate(startDate)
                //let endState = getCalendarStateFromDate(endDate)
               
                
                var day = TimeTableDay()
                var previosState = CalendarViewState(weeknum: 999999, weekday: 999999)
                var firstLoop = true
                
                for event in eventArray {
                    if (event.date != nil) {
                        let eventState = getCalendarStateFromDate(event.date!)
                        LoadedData.timeTable.clearDay(eventState)
                        
                        if ((previosState == eventState) || firstLoop) {

                            day.events.append(event)
                            day.weekDay = eventState.weekday
                            day.date = event.date
                            
                        }
                        else {
                            
                            _ = LoadedData.timeTable.setDay(day, weeknum: previosState.weeknum)
                            day = TimeTableDay()
                            
                        }
                        firstLoop = false
                        previosState = eventState
                    }
                }
                // Adding the last day
                _ = LoadedData.timeTable.setDay(day, weeknum: previosState.weeknum)

                ///////////////////////////////
                
                self.requestStatus(.done, requestType: .schedules)
            }
        }
        
        
    }

    
    */
    
    
    
    
    // MARK: Load timetable data for exact week
    func loadTimeTableDataForWeek (_ token: String?,
                                     weeknum: Int,
                                     avatarWidth: Int = User.imageSize,
                                     avatarHeight: Int = User.imageSize,
                                     userId: Int? = nil,
                                     groupId: Int? = nil) {
        
        self.requestStatus(.pending, requestType: .schedules)
        
        
        let startDate = getDateFromCalendarState(CalendarViewState(weeknum: weeknum, weekday: 1), year: getTodayYear())
        let endDate = getDateFromCalendarState(CalendarViewState(weeknum: weeknum + 1, weekday: 1), year: getTodayYear())
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yyyy"
        
        let startDateString = dateFormatter.string(from: startDate)
        let endDateString = dateFormatter.string(from: endDate)
        
        
        var arguments = ["startDate": startDateString,
                         "endDate": endDateString,
                         "avatarWidth": String(avatarWidth),
                         "avatarHeight": String(avatarHeight)]
        
        if userId != nil {arguments["userId"] = String(userId!)}
        if groupId != nil {arguments["groupId"] = String(groupId!)}
        
        task(api: "/schedules", method: .GET, headers: ["token": token as Any], arguments: arguments) { (response, json, error) in
            
            if error != nil {
                self.requestStatus(.error, requestType: .schedules, message: "API error")
                
            } else {
                
                var eventArray = [TimeTableEvent]()
                
                let array = json as? [[String:Any]]
                if (array == nil) {
                    self.requestStatus(.error, requestType: .schedules, message: "Response is empty")
                    return
                }
                
                for item in array! {
                    
                    let eventItem = parseJsonTimeTable(item)
                    
                    
                    if let pairKey = eventItem.pairKey {
                        if  pairKey != "" &&
                            pairKey == eventArray.last?.pairKey &&
                            eventItem.disciplineId == eventArray.last?.disciplineId {
                            
                            eventArray.last?.endingTime = eventItem.endingTime
                            
                        }
                        else {eventArray.append(eventItem)}
                    }
                    else {eventArray.append(eventItem)}
 
                    
                }
                
                
                
                /////////// Set Datastructure /////////
                
                //let startState = getCalendarStateFromDate(startDate)
                //let endState = getCalendarStateFromDate(endDate)
            
                
                for i in 1...7 {
                    let day = TimeTableDay()
                    day.weekDay = i
                    
                    if eventArray.count > 0 {
                        for j in 0...(eventArray.count - 1) {
                            if (eventArray[j].date != nil) {
                                let eventState = getCalendarStateFromDate(eventArray[j].date!)
                                if i == eventState.weekday {
                                    
                                    day.events.append(eventArray[j])
                                    day.date = eventArray[j].date
                                }
                            }
                            
                        }
                    }
                    _ = LoadedData.timeTable.setDay(day, weeknum: weeknum)
                }
                
                
                ///////////////////////////////
                
                self.requestStatus(.done, requestType: .schedules)
            }
        }
        
        
    }
    
}

func parseJsonTimeTable(_ json: [String:Any]?) -> TimeTableEvent {
    
    let data = TimeTableEvent()
    
    if json != nil {
        
        data.id = json!["scheduleId"] as? Int
        data.moduleCourseId = json!["moduleCourseId"] as? Int
        
        if let date = json!["date"] as? Double {data.date = Date(timeIntervalSince1970: date/1000)}
        
        if let startTime = json!["startTime"] as? Double {data.startingTime = Date(timeIntervalSince1970: startTime/1000)}
        if let endTime = json!["endTime"] as? Double {data.endingTime = Date(timeIntervalSince1970: endTime/1000)}
        
        
        data.categoty = EventCategory.lesson
        if let isExam = json!["isExam"] as? Bool {
            if isExam {
                data.isExam = true
                data.categoty = EventCategory.exam
            }
        }
        
        if let isExamView = json!["isView"] as? Bool {
            if data.isExam && isExamView {
                data.isExamView = true
                data.categoty = EventCategory.prosmotr
            }
        }
        
        let groups = json!["groups"] as? [[String:Any]]
        for group in groups! {
            let group_id = group["id"] as? Int
            let group_name = group["name"] as? String
            let group_course = group["course"] as? Int
            
            let curator = group["curator"] as? NSDictionary
            var eventGroupCurator: JsonUserData? = nil
            if curator != nil {
                let curator_id = curator!["id"] as? Int
                let curator_surname = curator!["surname"] as? String
                let curator_name = curator!["name"] as? String
                let curator_patronymic = curator!["patronymic"] as? String
                
                eventGroupCurator = JsonUserData(id: curator_id, surname: curator_surname, name: curator_name, patronymic: curator_patronymic)
            }
            let eventGroup = JsonGroup(id: group_id, name: group_name, course: group_course, curator: eventGroupCurator)
            data.lessonGroups.append(eventGroup)
        }
        
        let teacher = json!["teacher"] as? NSDictionary
        let lessonTutor = User()
        lessonTutor.id = teacher?["id"] as? Int
        lessonTutor.surname = teacher?["surname"] as? String
        lessonTutor.name = teacher?["name"] as? String
        lessonTutor.patronymic = teacher?["patronymic"] as? String
        data.lessonTutor = lessonTutor
        
        
        let discipline = json!["discipline"] as? NSDictionary
        data.disciplineId = discipline?["id"] as? Int
        data.typeId = discipline?["type"] as? Int
        data.title = discipline?["name"] as? String
        data.typeName = discipline?["typeName"] as? String
        data.typeColor = discipline?["color"] as? String
        
        data.roomNumber = json!["auditoryName"] as? String
        data.lessonComment = json!["comment"] as? String
        data.timeIntervalName = json!["timeIntervalName"] as? String
        data.numberInDay = json!["numberInDay"] as? Int
        
        data.lessonNumber = json!["numberInDay"] as? Int
        data.userCanReadSheet = json!["isCanReadStatement"] as! Bool
        data.userCanEditSheet = json!["isCanEditStatement"] as! Bool
        data.isViewWithTotalMarks = json!["isViewWithTotalMarks"] as! Bool
        data.pairKey = json!["pairKey"] as? String
        
    }
    
    return data
}


enum OldModelRequestType {
    case none
    case authLogin
    case authUserData
    case userData
    case userStatistics
    case usersList
    case schedules
    case sheet
    case savingData
    case projectsList
    case projectInfo
}

enum OldModelRequestStatus {
    case none
    case pending
    case error
    case done
}



