//
//  AttendanceSheetTableViewController.swift
//  TimeTracker
//
//  Created by Anton on 24/06/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit


struct AttendanceCell {
    var name: String
    var checkMark: Bool
    var id: Int
}

class AttendanceSheetPresenter {
    
    weak private var myView : AttendanceSheetTableViewController?
    
    func attachView(view:AttendanceSheetTableViewController){
        myView = view
    }
    
    func detachView() {
        myView = nil
    }
    
    var date: Date?
    var scheduleId: Int?
    
    var sheet: AttendanceSheet?
    var sheetCount: Int {return sheet?.data.count ?? 0}
    var savedCheckCount: Int = 0
    
    var event: TimeTableEvent? {
        didSet {
            date = event?.date
            scheduleId = event?.id
        }
    }
    var title: String?

    func updateTableData() {
        if sheet != nil && event != nil{
            
            myView?.userCanEditSheet = event!.userCanEditSheet
            
            if (!event!.userCanEditSheet) {
                myView?.navigationItem.rightBarButtonItems?.removeAll()
            }
            
            
            //// Header
            
            // Clear all labels
            
            myView?.tableData.eventTitle = nil
            myView?.tableData.eventLessonGroup = nil
            myView?.tableData.eventLessonComment = nil
            myView?.tableData.eventDateAndTime = nil
            myView?.tableData.eventColor = nil

            // Updating labels
            myView?.tableData.eventTitle = event?.title
            myView?.tableData.eventLessonComment = event?.lessonComment
            myView?.tableData.eventColor = event?.typeColor

            myView?.tableData.eventLessonGroup = makeEventGroupString(event?.lessonGroups)

            myView?.tableData.eventDateAndTime = ""
            if let date = event!.date {myView?.tableData.eventDateAndTime! += contvertDateToString(date, format: "dd MMMM")}
            if let startingTime = event!.startingTime {myView?.tableData.eventDateAndTime! += ", " + contvertTimeToString(startingTime)}

            /// Update Students List
            updateTableDataList()
            
            myView?.tableView.reloadData()
            
        }
    }
    
    func updateTableDataList() {
        if sheet != nil {
            
            /// Update Students List
            myView?.tableData.list.removeAll()
            for item in sheet!.data {
                if item.studentId != nil && item.student != nil {
                    let id = item.studentId!
                    let name = "\(item.student!.surname ?? "") \(item.student!.name ?? "")"
                    let checkMark = item.isChecked ?? false
                    let cell = AttendanceCell(name: name, checkMark: checkMark, id: id)
                    myView?.tableData.list.append(cell)
                }
            }

        }
    }

    
    
    func refreshTableData() {
        loadTableData()
    }
    
    func loadTableData() {
        
        if (date == nil || scheduleId == nil) {
            Debug.mode.output("Attendance Sheet: parameters not set", type: .error)
            return
        }
        
        let callBackStatus = TimeTracker.data.getSheet(type: .attendance, date: date!, scheduleId: scheduleId!, completionHandler: {(sheet, requestStatus) in
            
            //// Analysing Callback
            switch requestStatus {
                
            case .success:
                //// If request was successful
                
                self.sheet = sheet as! AttendanceSheet?
                self.updateTableData()
                
            case .error(let errorMsg):
                //// If there was an error
                
                self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
                
            }
        })
        
        Debug.mode.output("CallBackStatus: \(callBackStatus)", type: .none)
    }
    
    
    func saveSheet() {
        
        if (date == nil || scheduleId == nil || sheet == nil) {
            Debug.mode.output("Attendance Sheet: parameters not set", type: .error)
            return
        }
        
        ////////   Saving hole sheet  //////////
        let callBackStatus = TimeTracker.data.saveAttendanceChecks(date: date!, scheduleId: scheduleId!, students: sheet!.data, completionHandler: {(requestStatus) in
            
            //// Analysing Callback
            switch requestStatus {
                
            case .success:
                //// If request was successful

                self.loadTableData()
                
            case .error(let errorMsg):
                //// If there was an error
                
                self.myView?.alert(title: "Ошибка", message: errorMsg, action: "ОК")
                
            }
        })
        Debug.mode.output("CallBackStatus: \(callBackStatus)", type: .none)
        
    }

    
    func toggleAll(checkMark: Bool)  {
        self.sheet?.toggleAll(checkMark: checkMark)
        updateTableDataList()
    }
    
    func toggleStudent(id: Int, checkMark: Bool)  {
        self.sheet?.toggleStudent(id: id, checkMark: checkMark)
        updateTableDataList()
    }

    
}



class AttendanceSheetTableViewController: UITableViewController {
    
    var presenter = AttendanceSheetPresenter()
    
    struct TableData {
        var eventTitle: String?
        var eventLessonGroup: NSAttributedString?
        var eventLessonComment: String?
        var eventDateAndTime: String?
        var eventColor: String?
        
        var list = [AttendanceCell]()
    }
    
    var tableData = TableData()
    var userCanEditSheet: Bool = false
    
    var tableTitle: String? = ""
    var editMode: Bool = false
    
    var toggleAllCheckboxesMode: Bool = false
    var allCheckboxesState: Bool = false
    
    
    
    @IBAction func tappedCell(_ recognizer: UITapGestureRecognizer) {
        
        if (editMode) {
            if (recognizer.state == .ended) {
                let tapLocation = recognizer.location(in: self.tableView)
                if let tappedIndexPath = self.tableView.indexPathForRow(at: tapLocation) {
                    if let tappedCell = (self.tableView.cellForRow(at: tappedIndexPath) as? AttendanceSheetTableViewCell) {
                        
                        // Tap happened. Do stuff!
                        toggleAllCheckboxesMode = false
                        
                        tappedCell.cellCheckBoxButton.changeState()
                        
                    }
                }
            }
        }
    }
    
    
    func checkMarksActionHandler (_ studentId: Int?, isChecked: Bool) {
        if studentId != nil {
            presenter.toggleStudent(id: studentId!, checkMark: isChecked)
        }
    }
    
    
    func toggleAllCheckboxes() {
        if (editMode) {
            toggleAllCheckboxesMode = true
            allCheckboxesState = !allCheckboxesState
            presenter.toggleAll(checkMark: allCheckboxesState)
            self.tableView.reloadData()
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter.attachView(view: self)
        
        // Cell's height
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 44
        
        
        presenter.loadTableData()
    }
    

    
    func alert (title: String, message: String, action: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: action, style: UIAlertActionStyle.default, handler: { action in
            switch action.style{
            case .default:
                
                self.presenter.loadTableData()
                
                break
                
            case .cancel:
                break
                
            case .destructive:
                break
            }
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    @IBAction func pressedEditButton(_ sender: UIBarButtonItem) {
        
        if (editMode) {
            ///// SAVE BUTTON PRESSED /////
            editMode = false
            editButton.title = "Изменить"
            
            presenter.saveSheet()
            presenter.updateTableData()
            
            toggleAllCheckboxesMode = false
            allCheckboxesState = false
            
        } else {
            
            editMode = true
            editButton.title = "Сохранить"
            
            presenter.updateTableData()
            
        }
        

    }
    
    @IBOutlet weak var editButton: UIBarButtonItem!
    
    


    
    


    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return tableData.list.count + 1 // first cell for header
    }

    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return tableTitle
    }
    
    
   
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        /////////// First cell will be the header ////////////
        if (indexPath.row == 0) {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Attendance Sheet Header", for: indexPath)
            
            if let thisCell = cell as? AttendanceSheetTableViewHeaderCell {
                // SENDING DATA TO CELL
                
                thisCell.eventTitle?.text = tableData.eventTitle
                thisCell.eventLessonGroup?.attributedText = tableData.eventLessonGroup
                thisCell.eventLessonComment?.text = tableData.eventLessonComment
                thisCell.eventDateAndTime?.text = tableData.eventDateAndTime
                if (tableData.eventColor != nil) {
                    thisCell.eventColorBar?.backgroundColor = UIColor(hexString: tableData.eventColor!)
                }
                
                
                thisCell.editMode = editMode
                thisCell.attendanceSheetTableViewController = self
            }
            
            // Removing bottom line in 1st cell
            cell.separatorInset = UIEdgeInsetsMake(0, 0, 0, cell.bounds.size.width - 8);
            
            return cell
        }

        ////////// NAME CELLs ///////////
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Attendance Sheet Cell", for: indexPath)

        // Configure the cell...

        let thisCellItem = tableData.list[indexPath.row - 1] // first cell for header
        
        if let thisCell = cell as? AttendanceSheetTableViewCell {
        
                thisCell.cellNameLabel?.text = thisCellItem.name
                thisCell.cellCheckBoxButton.id = thisCellItem.id
                thisCell.cellCheckBoxButton.actionHandler = checkMarksActionHandler
            
            if (editMode) {
                
                    thisCell.accessoryType = .none
                    thisCell.cellCheckBoxButton.isHidden = false

                
                    if (toggleAllCheckboxesMode) {
                        thisCell.cellCheckBoxButton.isChecked = allCheckboxesState
                    }
                    else {
                        if thisCellItem.checkMark == true {thisCell.cellCheckBoxButton.isChecked = true}
                        else {thisCell.cellCheckBoxButton.isChecked = false}
                    }
                    
                    
                } else {
                
                    thisCell.cellCheckBoxButton.isHidden = true
                    if thisCellItem.checkMark {thisCell.accessoryType = .checkmark}
                    else {thisCell.accessoryType = .none}
                }
        
        
        }

        return cell
        
    }
   
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        self.navigationController?.navigationBar.backItem?.title = "Назад"
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
    }


}
