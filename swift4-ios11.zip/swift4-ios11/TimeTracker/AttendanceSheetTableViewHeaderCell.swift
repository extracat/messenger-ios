//
//  AttendanceSheetTableViewHeaderCell.swift
//  TimeTracker
//
//  Created by Anton on 07/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class AttendanceSheetTableViewHeaderCell: UITableViewCell {

    @IBOutlet weak var eventColorBar: UIView!
    @IBOutlet weak var eventTitle: UILabel!
    @IBOutlet weak var eventLessonGroup: UILabel!
    @IBOutlet weak var eventLessonComment: UILabel!
    @IBOutlet weak var eventDateAndTime: UILabel!
    @IBOutlet weak var toggleAllCheckboxesButton: UIButton!
    @IBAction func toggleAllCheckboxes(_ sender: UIButton) {
        attendanceSheetTableViewController?.toggleAllCheckboxes()
    }
    
    // Link to our parent
    var attendanceSheetTableViewController: AttendanceSheetTableViewController?
    
    
    var editMode: Bool = false {
        didSet {
            toggleAllCheckboxesButton.isHidden = !editMode
        }
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        //super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        toggleAllCheckboxesButton.isHidden = !editMode

        
    }

    

}
