//
//  ServerApi.swift
//  TimeTracker
//
//  Created by Anton on 01/12/2016.
//  Copyright © 2016 HSE. All rights reserved.
//


import Foundation
import UIKit

class ServerApi {
    ///// BEGIN class ServerApi /////
    
    
    //////////////////////////////////////
    //                                  //
    //   Server API version:            //
         static let version = "1.1"     //
    //                                  //
    //////////////////////////////////////
    
    let serverPath = "http://api.design.hse.ru/v\(version)/"
    
    // All the data come from this method
    func task(api: String,
              method: HTTPMethod,
              headers: [String: Any]?,
              arguments: [String: Any]?,
              body: Data? = nil,
              callback: @escaping (_ response: HTTPURLResponse?, _ json: Any?, _ error: Error?) -> Void) {
        
        let config = URLSessionConfiguration.default
        var path = serverPath + api
        
        if headers != nil {
            config.httpAdditionalHeaders = headers
        }
        
        if (method == .GET || method == .POST) && arguments != nil {
            path += "?"
            
            var first = true
            for key in arguments!.keys {
                if !first {path += "&"}
                path += "\(key)=\(arguments![key]!)"
                first = false
            }
           
        }
        
        let url = URL(string: path.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!)!
        Debug.mode.output("Request URL: \(url)")
        
        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        request.setValue("application/json", forHTTPHeaderField:"Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        if body != nil {request.httpBody = body!}
        
        let session = URLSession(configuration: config)
        
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = true // Status Bar Loader ON
        
        let task = session.dataTask(with: request as URLRequest, completionHandler: { (data: Data?, response: URLResponse?, error: Error?) in
            var json: Any? = nil
            do {
                if data != nil {
                    json = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.init(rawValue: 0))
                }
            } catch {Debug.mode.output("Error JSON Serialization: \(error)", type: .none)}
            
            Debug.mode.internetSlowConnection() // If you need slow connection
            
            callback(response as? HTTPURLResponse, json, error)
            
            UIApplication.shared.isNetworkActivityIndicatorVisible = false // Status Bar Loader OFF
            
        })
        task.resume()
    }
    
    
    // Authorization
    func login(login: String, password: String, completionHandler: @escaping (LoginResult) -> Void) {
        
        task(api: "auth/token", method: .GET, headers: nil,  arguments: ["login" :login as Any, "password": password as Any]) { (response, json, error) in
            
            var loginResult = LoginResult()
            
            if error != nil || json == nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                loginResult.status = .connectionFailed
                loginResult.errorMsg = errText
                
            } else {
                
                let json = json as? [String:Any]
                loginResult.status = EnumLoginStatus(rawValue: json!["resultCode"] as! Int)!
                
                if (loginResult.status == .success) {
                    
                    loginResult.token = json!["access_token"] as? String
                    let tokenIssued = json!["issued"] as? Double
                    let tokenExpires = json!["expires"] as? Double
                    loginResult.tokenIssued = Date(timeIntervalSince1970: tokenIssued!/1000)
                    loginResult.tokenExpires = Date(timeIntervalSince1970: tokenExpires!/1000)
                    
                    
                } else {
                    loginResult.errorMsg = json!["errorMessage"] as? String
                    Debug.mode.output(loginResult.errorMsg ?? "Unknown Error", type: .error)
                }
            }
            DispatchQueue.main.async {completionHandler(loginResult)}
        }
    }
    
    //////////////////////////////////////
    //                                  //
    //            USERS API             //
    //                                  //
    //////////////////////////////////////
    
    // MARK: Data of logged user
    func loadLoginUserData (token: String,
                            includeGroups: Bool = true,
                            includeRights: Bool = true,
                            avatarWidth: Int = User.imageSize,
                            avatarHeight: Int = User.imageSize,
                            completionHandler: @escaping (JsonUserData?, RequestStatus) -> Void) {
        
        let arguments = ["includeGroups": includeGroups.description,
                         "includeRights": includeRights.description,
                         "avatarWidth": String(avatarWidth),
                         "avatarHeight": String(avatarHeight)]
        
        task(api: "auth/me", method: .GET, headers: ["token" :token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil || json == nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {
                
                let json = json as? [String:Any]
                let jsonUserData = parseJsonUserData(json)
               
                DispatchQueue.main.async {completionHandler(jsonUserData, .success)}
            }
        }
    }
    
    
    // MARK: Data of any user
    func loadUserData (token: String?,
                       userId: Int,
                       includeGroups: Bool = false,
                       includeRights: Bool = false,
                       avatarWidth: Int = User.imageSize,
                       avatarHeight: Int = User.imageSize,
                       completionHandler: @escaping (JsonUserData?, RequestStatus) -> Void) {
        
        let arguments = ["includeGroups": includeGroups.description,
                         "includeRights": includeRights.description,
                         "avatarWidth": String(avatarWidth),
                         "avatarHeight": String(avatarHeight)]
        
        task(api: "users/\(String(userId))", method: .GET, headers: ["token" :token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil || json == nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {
                
                let json = json as? [String:Any]
                let jsonUserData = parseJsonUserData(json)

                DispatchQueue.main.async {completionHandler(jsonUserData, .success)}
            }
        }
    }
    
    
    // MARK: USER'S efficiency and timeload
    func loadUserStatistics (token: String, userId: Int, date: Date, completionHandler: @escaping (JsonUserStatistics?, RequestStatus) -> Void) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yyyy"
        let dateString = dateFormatter.string(from: date)
        let arguments = ["date": dateString]
        
        task(api: "users/\(String(userId))/statistics/bymonth", method: .GET, headers: ["token" :token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil || json == nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {
                
                
                let json = json as? [String:Any]
                var jsonUserStatistics = JsonUserStatistics()
                
                jsonUserStatistics.efficiency = json!["efficiency"] as? Float
                //jsonUserStatistics.projectsLoadK = json!["projectsLoadK"] as? Float
                //jsonUserStatistics.workLoadK  = json!["workLoadK"] as? Float
                jsonUserStatistics.projectsWorkLoadK = json!["projectsWorkLoadK"] as? Float
                jsonUserStatistics.projectsPlanLoadK = json!["projectsPlanLoadK"] as? Float
                jsonUserStatistics.schedulesLoadK  = json!["schedulesLoadK"] as? Float
                jsonUserStatistics.noWorkProjectsLoadK = json!["noWorkProjectsLoadK"] as? Float
                jsonUserStatistics.absentK = json!["absentK"] as? Float
                jsonUserStatistics.schedulesWithLatenessCount = json!["schedulesWithLatenessCount"] as? Int
                
                DispatchQueue.main.async {completionHandler(jsonUserStatistics, .success)}
            }
        }
        
        
    }
    
    
    // MARK: USER'S work times
    func loadUserWorkTimes (token: String, userId: Int, completionHandler: @escaping ([JsonUserWorkTime]?, RequestStatus) -> Void) {
    
        task(api: "users/\(String(userId))/workTimes", method: .GET, headers: ["token" :token as Any], arguments: nil) { (response, json, error) in
            
            if error != nil || json == nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {
                
                var workTimeArray = [JsonUserWorkTime]()
                
                let array = json as? [[String:Any]]
                if (array != nil) {
                    for item in array! {
                        
                        let dayOfWeekInt = item["dayOfWeek"] as? Int
                        let dayOfWeek = JsonWeekDay(rawValue: dayOfWeekInt!)
                        let startTime = item["startTime"] as? String
                        let endTime = item["endTime"] as? String

                        workTimeArray.append(JsonUserWorkTime(dayOfWeek: dayOfWeek, startTime: startTime ?? "", endTime: endTime ?? ""))
                    }
                }
                DispatchQueue.main.async {completionHandler(workTimeArray, .success)}
            }
        }
    }
    
    
    // MARK: Load timetracker users list
    func loadUsersList (token: String?,
                        right: EnumUserRights = .Teaching,
                        avatarWidth: Int = User.imageSize,
                        avatarHeight: Int = User.imageSize,
                        search: String? = nil,
                        page: Int? = nil,
                        count: Int? = nil,
                        completionHandler: @escaping ([JsonUserData]?, RequestStatus) -> Void) {
        
        var arguments = ["right": String(right.rawValue),
                         "avatarWidth": String(avatarWidth),
                         "avatarHeight": String(avatarHeight)]
        
        if search != nil {arguments["search"] = search!}
        if page != nil   {arguments["page"]   = String(page!)}
        if count != nil  {arguments["count"]  = String(count!)}
        
        task(api: "users", method: .GET, headers: ["token": token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil || json == nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {
                
                let json = json! as? [String:Any]
                if let array = json!["users"] as? [[String:Any]] {

                    var jsonUsersArray = [JsonUserData]()
                    
                    for item in array {
                        let jsonUserData = parseJsonUserData(item)
                        jsonUsersArray.append(jsonUserData)
                    }
                    
                    DispatchQueue.main.async {completionHandler(jsonUsersArray, .success)}
                    
                }
                else {
                    DispatchQueue.main.async {completionHandler(nil, .error("Array is nil"))}
                    Debug.mode.output("Array is nil", type: .error)
                    return
                }
                

                
            }
        }
    }
    
    
    //////////////////////////////////////
    //                                  //
    //           GROUPS  API            //
    //                                  //
    //////////////////////////////////////
    
    // MARK: Load timetracker students groups list
    func loadGroupsList (token: String? = nil,
                        directionId: Int? = nil,
                        learningType: EnumLearningType? = nil,
                        learningForm: EnumLearningForm? = nil,
                        course: Int? = nil,
                        academicYear: Int? = nil,
                        currentYearOnly	: Bool? = nil,
                        includeDirections: Bool? = nil,
                        includeDisciplines: Bool? = nil,
                        includeCurators: Bool? = nil,
                        avatarWidth: Int = User.imageSize,
                        avatarHeight: Int = User.imageSize,
                        completionHandler: @escaping ([JsonGroup]?, RequestStatus) -> Void) {
        
        var arguments = ["avatarWidth": String(avatarWidth),
                         "avatarHeight": String(avatarHeight)]
        
        if directionId != nil           {arguments["directionId"]           = String(directionId!)}
        if learningType != nil          {arguments["learningType"]          = String(learningType!.rawValue)}
        if learningForm != nil          {arguments["learningForm"]          = String(learningForm!.rawValue)}
        if course != nil                {arguments["course"]                = String(course!)}
        if academicYear != nil          {arguments["academicYear"]          = String(academicYear!)}
        if currentYearOnly != nil       {arguments["currentYearOnly"]       = String(currentYearOnly!.description)}
        if includeDirections != nil     {arguments["includeDirections"]     = String(includeDirections!.description)}
        if includeDisciplines != nil    {arguments["includeDisciplines"]    = String(includeDisciplines!.description)}
        if includeCurators != nil       {arguments["includeCurators"]       = String(includeCurators!.description)}


        task(api: "groups", method: .GET, headers: ["token": token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil || json == nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {
                if let array = json as? [[String:Any]] {
                    
                    var jsonGroupsArray = [JsonGroup]()
                    
                    for item in array {
                        let jsonGroupData = parseJsonGroupData(item)
                        
                        
                        jsonGroupsArray.append(jsonGroupData)
                    }
                    
                    DispatchQueue.main.async {completionHandler(jsonGroupsArray, .success)}
                    
                }
                else {
                    DispatchQueue.main.async {completionHandler(nil, .error("Array is nil"))}
                    Debug.mode.output("Array is nil", type: .error)
                    return
                }
                
                
                
            }
        }
    }
    
    
    
    //////////////////////////////////////
    //                                  //
    //           PROJECTS API           //
    //                                  //
    //////////////////////////////////////
    
    
    
    // MARK: Load projects list
    func loadProjectsList (token: String,
                           userId: Int? = nil,
                           status: EnumProjectStatus? = nil,
                           startDate: Date? = nil,
                           endDate: Date? = nil,
                           startedFromDate: Date? = nil,
                           startedToDate: Date? = nil,
                           endedFromDate: Date? = nil,
                           endedToDate: Date? = nil,
                           workTimeFromDate: Date? = nil,
                           workTimeToDate: Date? = nil,
                           search: String? = nil,
                           hasEfficiency: Bool? = nil,
                           page: Int? = nil,
                           count: Int? = nil,
                           completionHandler: @escaping ([JsonProjectData]?, RequestStatus) -> Void) {
        
        
        var arguments = [String: String]()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yyyy"
        
        if startDate != nil         {arguments["startDate"]         = dateFormatter.string(from: startDate!)}
        if endDate != nil           {arguments["endDate"]           = dateFormatter.string(from: endDate!)}
        if startedFromDate != nil   {arguments["startedFromDate"]   = dateFormatter.string(from: startedFromDate!)}
        if startedToDate != nil     {arguments["startedToDate"]     = dateFormatter.string(from: startedToDate!)}
        if endedFromDate != nil     {arguments["endedFromDate"]     = dateFormatter.string(from: endedFromDate!)}
        if endedToDate != nil       {arguments["endedToDate"]       = dateFormatter.string(from: endedToDate!)}
        if workTimeFromDate != nil  {arguments["workTimeFromDate"]  = dateFormatter.string(from: workTimeFromDate!)}
        if workTimeToDate != nil    {arguments["workTimeToDate"]    = dateFormatter.string(from: workTimeToDate!)}
        
        if userId != nil        {arguments["userId"] = String(userId!)}
        if status != nil        {arguments["status"] = String(status!.rawValue)}
        if search != nil        {arguments["search"] = search!}
        if hasEfficiency != nil {arguments["hasEfficiency"] = hasEfficiency!.description}
        if page != nil          {arguments["page"]   = String(page!)}
        if count != nil         {arguments["count"]  = String(count!)}
        
        task(api: "projects", method: .GET, headers: ["token": token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil || json == nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {
                
                let json = json! as? [String:Any]
                if let array = json!["projects"] as? [[String:Any]] {
                    
                    var projectsArray = [JsonProjectData]()
                    
                    for item in array {
                        
                        let project = parseJsonProjectData(item)
                        projectsArray.append(project)
                        
                    }
                    
                    DispatchQueue.main.async {completionHandler(projectsArray, .success)}
                    
                }
                else {
                    DispatchQueue.main.async {completionHandler(nil, .error("Array is nil"))}
                    Debug.mode.output("Array is nil", type: .error)
                    return
                }
            }
        }
    }
    
    
    // MARK: Data of any user
    func loadProjectData (token: String,
                          projectId: Int,
                          includeWorkTime: Bool = true,
                          includeCoordinator: Bool = true,
                          includeTaskUsers: Bool = true,
                          avatarWidth: Int = User.imageSize,
                          avatarHeight: Int = User.imageSize,
                          completionHandler: @escaping (JsonProjectData?, RequestStatus) -> Void) {
        
        
        let arguments = ["includeWorkTime": includeWorkTime.description,
                         "includeCoordinator": includeCoordinator.description,
                         "includeTaskUsers": includeTaskUsers.description,
                         "avatarWidth": String(avatarWidth),
                         "avatarHeight": String(avatarHeight)]
        
        task(api: "projects/\(String(projectId))", method: .GET, headers: ["token" :token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil || json == nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {

                let json = json as? [String:Any]
                let jsonProjectData = parseJsonProjectData(json)
                
                DispatchQueue.main.async {completionHandler(jsonProjectData, .success)}
            }
        }
    }

    
    // MARK: Load projects list
    func loadProjectsWorktime (token: String,
                               projects: [JsonProjectData]? = nil,
                               userId: Int? = nil,
                               startDate: Date? = nil,
                               endDate: Date? = nil,
                               completionHandler: @escaping ([JsonProjectData]?, RequestStatus) -> Void) {
        
        
        var arguments = [String: String]()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yyyy"
        
        if startDate != nil   {arguments["startDate"] = dateFormatter.string(from: startDate!)}
        if endDate != nil     {arguments["endDate"]   = dateFormatter.string(from: endDate!)}
        if userId != nil      {arguments["userId"]    = String(userId!)}
        
        var projectIdsString = ""
        if projects != nil {
            for project in projects! {
                if project.id != nil { projectIdsString += "\(project.id!)," }
            }
            if projectIdsString != "" {arguments["projectIds"] = projectIdsString }
        }
        
        
        task(api: "projects/worktime", method: .GET, headers: ["token": token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil || json == nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {
                
                if let array = json as? [[String:Any]] {
                    
                    var projectsArray = [JsonProjectData]()
                    
                    for item in array {

                        var project = JsonProjectData()

                        project.id = item["projectId"] as? Int
                        project.workTimeInHours = item["workTimeInHours"] as? Float

                        projectsArray.append(project)
                        
                    }
                    
                    DispatchQueue.main.async {completionHandler(projectsArray, .success)}
                    
                }
                else {
                    DispatchQueue.main.async {completionHandler(nil, .error("Array is nil"))}
                    Debug.mode.output("Array is nil", type: .error)
                    return
                }
            }
        }
    }

    
    
    //////////////////////////////////////
    //                                  //
    //           SCHEDULES API          //
    //                                  //
    //////////////////////////////////////
    
    // MARK: Load Schedules
    func loadSchedules (token: String? = nil,
                        startDate: Date,
                        endDate: Date,
                        userId: Int? = nil,
                        groupId: Int? = nil,
                        avatarWidth: Int = User.imageSize,
                        avatarHeight: Int = User.imageSize,
                        completionHandler: @escaping ([TimeTableEvent]?, RequestStatus) -> Void) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yyyy"
        
        let startDateString = dateFormatter.string(from: startDate)
        let endDateString = dateFormatter.string(from: endDate)
        
        
        var arguments = ["startDate": startDateString,
                         "endDate": endDateString,
                         "avatarWidth": String(avatarWidth),
                         "avatarHeight": String(avatarHeight)]
        
        if userId != nil {arguments["userId"] = String(userId!)}
        if groupId != nil {arguments["groupId"] = String(groupId!)}
        
        task(api: "schedules", method: .GET, headers: ["token": token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {
                
                var statusCode: Int?
                if response != nil {
                    statusCode = response!.statusCode
                    Debug.mode.output("Status code: \(String(statusCode!))", type: .info)
                    
                    if statusCode == 403 {
                        DispatchQueue.main.async {completionHandler(nil,.error("Недостаточно прав"))}
                        Debug.mode.output("Status code: \(String(describing: statusCode ?? 0))", type: .error)
                        return
                    }
                    
                    if statusCode == 404 {
                        DispatchQueue.main.async {completionHandler(nil,.error("Не найдено"))}
                        Debug.mode.output("Status code: \(String(describing: statusCode ?? 0))", type: .error)
                        return
                    }
                }
                
               
                
                var eventArray = [TimeTableEvent]()
                
                let array = json as? [[String:Any]]
                if (array == nil) {
                    DispatchQueue.main.async {completionHandler(nil,.error("Response is empty"))}
                    Debug.mode.output("Status code: \(String(describing: statusCode ?? 0))", type: .error)
                    return
                }
                
                for item in array! {
                    
                    let eventItem = parseJsonTimeTable(item)
                    
                    if let pairKey = eventItem.pairKey {
                        if  pairKey != "" &&
                            pairKey == eventArray.last?.pairKey &&
                            eventItem.disciplineId == eventArray.last?.disciplineId {
                            
                            eventArray.last?.endingTime = eventItem.endingTime
                        }
                        else {eventArray.append(eventItem)}
                    }
                    else {eventArray.append(eventItem)}
                    
                }
  
                
                DispatchQueue.main.async {completionHandler(eventArray, .success)}
            }
        }
    }

    
    
    
    
    //////////////////////////////////////
    //                                  //
    //            SHEETS API            //
    //                                  //
    //////////////////////////////////////
    
    
    
    // MARK: Load attendance sheet
    func loadAttendanceSheet (token: String,
                              date: Date,
                              scheduleId: Int,
                              includeStudents: Bool = true,
                              avatarWidth: Int = User.imageSize,
                              avatarHeight: Int = User.imageSize,
                              completionHandler: @escaping ([JsonAttendanceSheetItem]?, RequestStatus) -> Void) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yyyy"
        
        let dateString = dateFormatter.string(from: date)
        let scheduleId = String(scheduleId)
        
        
        let arguments = ["includeStudents": includeStudents.description,
                         "avatarWidth": String(avatarWidth),
                         "avatarHeight": String(avatarHeight)]
        
        task(api: "schedules/\(scheduleId)/\(dateString)/statement", method: .GET, headers: ["token": token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {
                
                var statusCode: Int?
                if response != nil {
                    statusCode = response!.statusCode
                    Debug.mode.output("Status code: \(String(statusCode!))", type: .info)
                    
                    if statusCode == 403 {
                        DispatchQueue.main.async {completionHandler(nil,.error("Недостаточно прав"))}
                        Debug.mode.output("Status code: \(String(describing: statusCode ?? 0))", type: .error)
                        return
                    }
                    
                    if statusCode == 404 {
                        DispatchQueue.main.async {completionHandler(nil,.error("Не найдено"))}
                        Debug.mode.output("Status code: \(String(describing: statusCode ?? 0))", type: .error)
                        return
                    }
                }
     
                var eventSheet = [JsonAttendanceSheetItem]()
                
                let students = json as? [[String:Any]]
                if (students == nil) {
                    DispatchQueue.main.async {completionHandler(nil, .error("Array is nil"))}
                    Debug.mode.output("Array is nil", type: .error)
                    return
                }
                
                for student in students! {
                    var sheetItem = JsonAttendanceSheetItem()
                    sheetItem.studentId = student["studentId"] as? Int
                    sheetItem.isChecked = student["isChecked"] as? Bool
                    sheetItem.student = parseJsonUserData(student["student"] as? [String:Any])
                    eventSheet.append(sheetItem)
                }
                DispatchQueue.main.async {completionHandler(eventSheet, .success)}
            }
        }
    }
    
    // MARK: Load Examination sheet
    func loadExaminationSheet (token: String,
                               date: Date,
                               scheduleId: Int,
                               includeStudents: Bool = true,
                               avatarWidth: Int = User.imageSize,
                               avatarHeight: Int = User.imageSize,
                               completionHandler: @escaping ([JsonExaminationSheetItem]?, RequestStatus) -> Void) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yyyy"
        
        let dateString = dateFormatter.string(from: date)
        let scheduleId = String(scheduleId)
        
        
        let arguments = ["includeStudents": includeStudents.description,
                         "avatarWidth": String(avatarWidth),
                         "avatarHeight": String(avatarHeight)]
        
        task(api: "schedules/\(scheduleId)/\(dateString)/examstatement", method: .GET, headers: ["token": token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {
                
                var statusCode: Int?
                if response != nil {
                    statusCode = response!.statusCode
                    Debug.mode.output("Status code: \(String(statusCode!))", type: .info)
                    
                    if statusCode == 403 {
                        DispatchQueue.main.async {completionHandler(nil,.error("Недостаточно прав"))}
                        Debug.mode.output("Status code: \(String(describing: statusCode ?? 0))", type: .error)
                        return
                    }
                    
                    if statusCode == 404 {
                        DispatchQueue.main.async {completionHandler(nil,.error("Не найдено"))}
                        Debug.mode.output("Status code: \(String(describing: statusCode ?? 0))", type: .error)
                        return
                    }
                }
                
                var eventSheet = [JsonExaminationSheetItem]()
                
                let students = json as? [[String:Any]]
                if (students == nil) {
                    DispatchQueue.main.async {completionHandler(nil, .error("Array is nil"))}
                    Debug.mode.output("Array is nil", type: .error)
                    return
                }
                
                for student in students! {
                    var sheetItem = JsonExaminationSheetItem()
                    
                    sheetItem.moduleCourseId = student["moduleCourseId"] as? Int
                    sheetItem.studentId = student["studentId"] as? Int
                    sheetItem.mark = student["mark"] as? Int
                    sheetItem.student = parseJsonUserData(student["student"] as? [String:Any])
                    eventSheet.append(sheetItem)
                }
                DispatchQueue.main.async {completionHandler(eventSheet, .success)}
            }
        }
    }
    
    
    // MARK: Load Examination sheet
    func loadProsmotrSheet (token: String,
                            date: Date,
                            scheduleId: Int,
                            includeUserProjects: Bool = true,
                            includeUserProjectAuthors: Bool = true,
                            avatarWidth: Int = User.imageSize,
                            avatarHeight: Int = User.imageSize,
                            completionHandler: @escaping ([JsonProsmotrSheetItem]?, RequestStatus) -> Void) {
   
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yyyy"
        
        let dateString = dateFormatter.string(from: date)
        let scheduleId = String(scheduleId)
        
        let arguments = ["includeUserProjects": includeUserProjects.description,
                         "includeUserProjectAuthors": includeUserProjectAuthors.description,
                         "avatarWidth": String(avatarWidth),
                         "avatarHeight": String(avatarHeight)]
        
        task(api: "schedules/\(scheduleId)/\(dateString)/examinerstatement", method: .GET, headers: ["token": token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            if error != nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(nil, .error(errText))}
                
            } else {

                var statusCode: Int?
                if response != nil {
                    statusCode = response!.statusCode
                    Debug.mode.output("Status code: \(String(statusCode!))", type: .info)

                    if statusCode == 403 {
                        DispatchQueue.main.async {completionHandler(nil,.error("Недостаточно прав"))}
                        Debug.mode.output("Status code: \(String(describing: statusCode ?? 0))", type: .error)
                        return
                    }
                    
                    if statusCode == 404 {
                        DispatchQueue.main.async {completionHandler(nil,.error("Не найдено"))}
                        Debug.mode.output("Status code: \(String(describing: statusCode ?? 0))", type: .error)
                        return
                    }
                }
                
                var eventSheet = [JsonProsmotrSheetItem]()
                
                let projects = json as? [[String:Any]]
                if (projects == nil) {
                    DispatchQueue.main.async {completionHandler(nil, .error("Array is nil"))}
                    Debug.mode.output("Array is nil", type: .error)
                    return
                }

                for project in projects! {
                    var sheetItem = JsonProsmotrSheetItem()
                    sheetItem.userProjectId = project["userProjectId"] as? Int
                    sheetItem.mark = project["mark"] as? Int
                    sheetItem.userProject = parseJsonUserProject(project["userProject"] as? [String:Any])
                    
                    eventSheet.append(sheetItem)
                }
                DispatchQueue.main.async {completionHandler(eventSheet, .success)}
            }
        }
    }
    

    // MARK: Saving Exam Mark
    func saveExamMark (token: String, moduleCourseId: Int, studentId: Int, mark: Int, completionHandler: @escaping (RequestStatus) -> Void) {
        
        var markString = String(mark)
        if mark == 0 { markString = "" }
        
        let arguments = ["mark": markString]
        
        task(api: "modulecourses/\(String(moduleCourseId))/totalmarks/\(String(studentId))", method: .POST, headers: ["token": token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            
            if error != nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(.error(errText))}
                
            } else {
                
                var statusCode: String?
                if response != nil {
                    statusCode = "Status code: \(String(response!.statusCode))"
                    Debug.mode.output(statusCode!, type: .info)
                }
                
                let item = json as? NSDictionary
                if (item == nil) {
                    DispatchQueue.main.async {completionHandler(.error( statusCode ?? "Unknown error"))}
                    Debug.mode.output("json item is nil", type: .error)
                    return
                }
                
                
                if let ExceptionMessage = item!["ExceptionMessage"] as? String {
                    DispatchQueue.main.async {completionHandler(.error(ExceptionMessage))}
                    Debug.mode.output(ExceptionMessage, type: .error)
                    return
                }
                
                if let MessageDetail = item!["MessageDetail"] as? String {
                    DispatchQueue.main.async {completionHandler(.error(MessageDetail))}
                    Debug.mode.output(MessageDetail, type: .error)
                    return
                }
                
                if let resultCode = item!["resultCode"] as? Int {
                    
                    if resultCode == 1 {
                        DispatchQueue.main.async {completionHandler(.success)}
                        return
                    }
                    else {
                        let errorMsg = (item!["message"] as? String) ?? "no error msg"
                        DispatchQueue.main.async {completionHandler(.error(errorMsg))}
                        Debug.mode.output(errorMsg, type: .error)
                        return
                    }
                    
                    
                }
                else {
                    DispatchQueue.main.async {completionHandler(.error("Unknown message received"))}
                    Debug.mode.output("Unknown message received", type: .error)
                    return
                }
                
            }
        }
        
        
    }
    
    
    // MARK: Saving Prosmotr Mark
    func saveProsmotrMark (token: String, moduleCourseId: Int, projectId: Int, mark: Int, completionHandler: @escaping (RequestStatus) -> Void) {
        
        var markString = String(mark)
        if mark == 0 { markString = "" }
        
        let arguments = ["mark": markString]
        
        task(api: "modulecourses/\(String(moduleCourseId))/examinermarks/\(String(projectId))", method: .POST, headers: ["token": token as Any], arguments: arguments as [String : Any]?) { (response, json, error) in
            
            
            if error != nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(.error(errText))}
                
            } else {
                
                var statusCode: String?
                if response != nil {
                    statusCode = "Status code: \(String(response!.statusCode))"
                    Debug.mode.output(statusCode!, type: .info)
                }
                
                let item = json as? NSDictionary
                if (item == nil) {
                    DispatchQueue.main.async {completionHandler(.error( statusCode ?? "Unknown error"))}
                    Debug.mode.output("json item is nil", type: .error)
                    return
                }
                
                
                if let ExceptionMessage = item!["ExceptionMessage"] as? String {
                    DispatchQueue.main.async {completionHandler(.error(ExceptionMessage))}
                    Debug.mode.output(ExceptionMessage, type: .error)
                    return
                }
                
                if let MessageDetail = item!["MessageDetail"] as? String {
                    DispatchQueue.main.async {completionHandler(.error(MessageDetail))}
                    Debug.mode.output(MessageDetail, type: .error)
                    return
                }
                
                if let resultCode = item!["resultCode"] as? Int {
                    
                    if resultCode == 1 {
                        DispatchQueue.main.async {completionHandler(.success)}
                        return
                    }
                    else {
                        let errorMsg = (item!["message"] as? String) ?? "no error msg"
                        DispatchQueue.main.async {completionHandler(.error(errorMsg))}
                        Debug.mode.output(errorMsg, type: .error)
                        return
                    }
                    
                    
                }
                else {
                    DispatchQueue.main.async {completionHandler(.error("Unknown message received"))}
                    Debug.mode.output("Unknown message received", type: .error)
                    return
                }
                
            }
        }
        
        
    }

    // MARK: Saving attendance sheet checks
    func saveAttendanceChecks (token: String, date: Date, scheduleId: Int, students: [JsonAttendanceSheetItem], completionHandler: @escaping (RequestStatus) -> Void) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yyyy"
        
        let dateString = dateFormatter.string(from: date)
        let scheduleId = String(scheduleId)
        
        var json = [[String : Any]]()
        for student in students {
            if (student.studentId != nil && student.isChecked != nil){
                let jsonItem = ["id": student.studentId!, "isChecked": student.isChecked!] as [String : Any]
                json.append(jsonItem)
            }
        }

        let body = try? JSONSerialization.data(withJSONObject: json, options: .prettyPrinted)
        
        task(api: "schedules/\(scheduleId)/\(dateString)/statement/checks", method: .POST, headers: ["token": token as Any], arguments: nil, body: body) { (response, json, error) in
            
            if error != nil {
                let errText = error?.localizedDescription ?? "Unknown Error"
                Debug.mode.output("API Error: \(errText)", type: .none)
                DispatchQueue.main.async {completionHandler(.error(errText))}
                
            } else {
                
                var statusCode: Int?
                if response != nil {
                    statusCode = response!.statusCode
                    Debug.mode.output("Status code: \(String(statusCode!))", type: .info)
                    if statusCode == 200 {
                        DispatchQueue.main.async {completionHandler(.success)}
                        return
                    }
                    if statusCode == 403 {
                        DispatchQueue.main.async {completionHandler(.error("Недостаточно прав"))}
                        Debug.mode.output("Status code: \(String(describing: statusCode ?? 0))", type: .error)
                        return
                    }
                }
                
                let item = json as? NSDictionary
                
                if (item == nil) {
                    DispatchQueue.main.async {completionHandler(.error("Status code: \(String(describing: statusCode ?? 0))"))}
                    Debug.mode.output("json item is nil", type: .error)
                    return
                }
                
                Debug.mode.output(item!, type: .info)
                
                if let ExceptionMessage = item!["ExceptionMessage"] as? String {
                    DispatchQueue.main.async {completionHandler(.error(ExceptionMessage))}
                    Debug.mode.output(ExceptionMessage, type: .error)
                    return
                }
                
                if let MessageDetail = item!["MessageDetail"] as? String {
                    DispatchQueue.main.async {completionHandler(.error(MessageDetail))}
                    Debug.mode.output(MessageDetail, type: .error)
                    return
                }
                

                else {
                    DispatchQueue.main.async {completionHandler(.error("Unknown message received"))}
                    Debug.mode.output("Unknown message received", type: .error)
                    return
                }
            }
        }
    }

    

    
    ///// END class ServerApi /////
}



/////// BEGIN Parsing global functions   ///////

func parseJsonUserData(_ json: [String:Any]?) -> JsonUserData {
    var data = JsonUserData()
    
    if json != nil {
        data.id = json!["id"] as? Int
        data.surname = json!["surname"] as? String
        data.name = json!["name"] as? String
        data.patronymic = json!["patronymic"] as? String
        data.imageUrl = json!["imageUrl"] as? String
        data.phone = json!["phone"] as? String
        data.email = json!["email"] as? String
        
        if let jsonRights = json!["rights"] as? [Int] {
            data.rights = [EnumUserRights]()
            for jsonRight in jsonRights {
                var right: EnumUserRights!
                right = EnumUserRights(rawValue: jsonRight)
                if right == nil {right = EnumUserRights.UnSupported }
                data.rights!.append(right!)
            }
        }
    }
    
    return data
}



func parseJsonGroupData(_ json: [String:Any]?) -> JsonGroup {
    var data = JsonGroup()
    
    if json != nil {

        data.id = json!["id"] as? Int
        data.name = json!["name"] as? String
        data.academicYear = json!["academicYear"] as? Int
        data.course = json!["course"] as? Int
        if let learningType = json!["learningType"] as? Int {
            data.learningType = EnumLearningType(rawValue: learningType)
        }
        data.learningTypeName = json!["learningTypeName"] as? String
        if let learningForm = json!["learningForm"] as? Int {
            data.learningForm = EnumLearningForm(rawValue: learningForm)
        }
        data.learningFormName = json!["learningFormName"] as? String
        
        data.curatorId = json!["curatorId"] as? Int
        let jsonCurator = json!["curator"] as? [String:Any]
        data.curator = parseJsonUserData(jsonCurator)
        
        data.disciplineId = json!["disciplineId"] as? Int
        var discipline = JsonDiscipline()
        if let jsonDiscipline = json!["discipline"] as? [String:Any] {
            discipline.id = jsonDiscipline["id"] as? Int
            discipline.name = jsonDiscipline["name"] as? String
            discipline.type = jsonDiscipline["type"] as? Int
            discipline.typeName = jsonDiscipline["typeName"] as? String
            discipline.color = jsonDiscipline["color"] as? String
        }
        data.discipline = discipline

        data.directionId = json!["directionId"] as? Int
        var direction = JsonDirection()
        if let jsonDirection = json!["direction"] as? [String:Any] {
            direction.id = jsonDirection["id"] as? Int
            direction.name = jsonDirection["name"] as? String
            direction.code = jsonDirection["code"] as? String
        }
        data.direction = direction
        
    }

    return data
}



func parseJsonProjectData(_ json: [String:Any]?) -> JsonProjectData {
    var data = JsonProjectData()
    
    if json != nil {
        
        data.id = json!["id"] as? Int
        data.name = json!["name"] as? String
        data.workTimeInHours = json!["workTimeInHours"] as? Float
        data.costInHours = json!["costInHours"] as? Float
        data.efficiency = json!["efficiency"] as? Float
        if let deadline = json!["deadline"] as? Double {
            data.deadline = Date(timeIntervalSince1970: deadline/1000)
        }
        
        data.coordinatorId = json!["coordinatorId"] as? Int
        let jsonCoordinator = json!["coordinator"] as? [String:Any]
        data.coordinator = parseJsonUserData(jsonCoordinator)
        
        let status = json!["status"] as? Int
        if status != nil {data.status = EnumProjectStatus(rawValue: status!)}
        
        if let array = json!["users"] as? [[String:Any]] {
            
            var jsonUsersArray = [JsonUserData]()
            
            for item in array {
                let jsonUserData = parseJsonUserData(item)
                jsonUsersArray.append(jsonUserData)
            }
            data.users = jsonUsersArray
        }
    

    }
    
    return data
}

func parseJsonUserProject(_ json: [String:Any]?) -> JsonUserProject {
    var data = JsonUserProject()
    
    if json != nil {
        
        data.id = json!["id"] as? Int
        data.title = json!["title"] as? String
        data.moduleCourseId = json!["moduleCourseId"] as? Int
        
        if let array = json!["authors"] as? [[String:Any]] {
            
            var jsonUsersArray = [JsonUserData]()
            
            for item in array {
                let jsonUserData = parseJsonUserData(item)
                jsonUsersArray.append(jsonUserData)
            }
            data.authors = jsonUsersArray
        }
    }
    
    return data
}



/////// END Parsing global functions   ///////

