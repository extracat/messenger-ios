//
//  ProfileHeaderTableViewCell.swift
//  TimeTracker
//
//  Created by Anton on 13/10/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class ProfileHeaderTableViewCell: UITableViewCell {
    
    @IBOutlet weak var labelLastName: UILabel!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var imageUserpic: UIImageView!
    
    var userImage: UIImage? {
        didSet {
            self.imageUserpic.image = userImage
        }
    }
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        
        //imageUserpic.layer.borderWidth = 1
        imageUserpic.layer.masksToBounds = false
        //imageUserpic.layer.borderColor = UIColor(hexString: "#f7f7f7")?.CGColor
        imageUserpic.layer.cornerRadius = imageUserpic.frame.height/2
        imageUserpic.layer.backgroundColor = UIColor(hexString: "#ffffff")?.cgColor
        imageUserpic.clipsToBounds = true
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    

}
