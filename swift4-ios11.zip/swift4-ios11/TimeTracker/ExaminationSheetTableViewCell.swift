//
//  ExaminationSheetTableViewCell.swift
//  TimeTracker
//
//  Created by Anton on 05/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class ExaminationSheetTableViewCell: UITableViewCell {

    
    var studentId: Int? = nil
    var moduleCourseId: Int? = nil
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
