//
//  WeekdaysViewController.swift
//  TimeTracker
//
//  Created by Anton on 06/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class WeekdaysViewController: UIViewController {

    var pageIndex: Int!
    var thisPageWeekNum: Int!
    
    //var week: TimeTableWeek?
    
    var calendarViewController:CalendarViewController?
    
    
    @IBOutlet weak var line1pxConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var weekday1DateLabel: UIButton!
    @IBOutlet weak var weekday2DateLabel: UIButton!
    @IBOutlet weak var weekday3DateLabel: UIButton!
    @IBOutlet weak var weekday4DateLabel: UIButton!
    @IBOutlet weak var weekday5DateLabel: UIButton!
    @IBOutlet weak var weekday6DateLabel: UIButton!
    @IBOutlet weak var weekday7DateLabel: UIButton!
    
    @IBOutlet weak var weekday1Label: UIButton!
    @IBOutlet weak var weekday2Label: UIButton!
    @IBOutlet weak var weekday3Label: UIButton!
    @IBOutlet weak var weekday4Label: UIButton!
    @IBOutlet weak var weekday5Label: UIButton!
    @IBOutlet weak var weekday6Label: UIButton!
    @IBOutlet weak var weekday7Label: UIButton!
    

    @IBOutlet weak var weekdayBottomBarContainer: UIView!

    
    @IBAction func dayButton(_ sender: UIButton) {
        let oldWeekday = calendarViewController?.calendarState.weekday
        let newWeekday = sender.tag
        
        if oldWeekday == newWeekday {return}
        
        calendarViewController?.navigateToCalendarState(CalendarViewState(weeknum: thisPageWeekNum, weekday: newWeekday))

    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        line1pxConstraint.constant = 1/UIScreen.main.scale
        
        thisPageWeekNum = LoadedData.timeTable.convertWeekPageIndexToWeekNum(pageIndex)

        setWeekdaysDates()
        
   


        

    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        
        // Setting the state of parent view controller
        

        let currentDay = calendarViewController?.calendarState.weekday
       
        calendarViewController?.navigateToDay(CalendarViewState(weeknum: thisPageWeekNum, weekday: currentDay!))
        
        calendarViewController?.calendarState.weeknum = thisPageWeekNum
        
        setTodayColor()

        
        // Trying to load DATA for 3 weeks
        LoadedData.timeTable.loadTimeTableDataForWeek(thisPageWeekNum - 1)
        LoadedData.timeTable.loadTimeTableDataForWeek(thisPageWeekNum)
        LoadedData.timeTable.loadTimeTableDataForWeek(thisPageWeekNum + 1)
  
    }
    
    


    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

       
    func setWeekdaysDates() {
       
        let year = getTodayYear()
        
        let day1 = getDay(getDateFromCalendarState(CalendarViewState(weeknum: thisPageWeekNum!, weekday: 1), year: year))
        let day2 = getDay(getDateFromCalendarState(CalendarViewState(weeknum: thisPageWeekNum!, weekday: 2), year: year))
        let day3 = getDay(getDateFromCalendarState(CalendarViewState(weeknum: thisPageWeekNum!, weekday: 3), year: year))
        let day4 = getDay(getDateFromCalendarState(CalendarViewState(weeknum: thisPageWeekNum!, weekday: 4), year: year))
        let day5 = getDay(getDateFromCalendarState(CalendarViewState(weeknum: thisPageWeekNum!, weekday: 5), year: year))
        let day6 = getDay(getDateFromCalendarState(CalendarViewState(weeknum: thisPageWeekNum!, weekday: 6), year: year))
        let day7 = getDay(getDateFromCalendarState(CalendarViewState(weeknum: thisPageWeekNum!, weekday: 7), year: year))

        
        weekday1DateLabel?.setTitle(String(day1), for: UIControlState())
        weekday2DateLabel?.setTitle(String(day2), for: UIControlState())
        weekday3DateLabel?.setTitle(String(day3), for: UIControlState())
        weekday4DateLabel?.setTitle(String(day4), for: UIControlState())
        weekday5DateLabel?.setTitle(String(day5), for: UIControlState())
        weekday6DateLabel?.setTitle(String(day6), for: UIControlState())
        weekday7DateLabel?.setTitle(String(day7), for: UIControlState())

    }
    
    func setTodayColor() {
        if (thisPageWeekNum! == getTodayWeeknum()) {
            switch getTodayWeekday() {
            case 1:
                weekday1DateLabel?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
                weekday1Label?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
            case 2:
                weekday2DateLabel?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
                weekday2Label?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
            case 3:
                weekday3DateLabel?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
                weekday3Label?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
            case 4:
                weekday4DateLabel?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
                weekday4Label?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
            case 5:
                weekday5DateLabel?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
                weekday5Label?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
            case 6:
                weekday6DateLabel?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
                weekday6Label?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
            case 7:
                weekday7DateLabel?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())
                weekday7Label?.setTitleColor(UIColor.ttDuskBlueColor(), for: UIControlState())

            default:
                return
            }
        }
    }

}
