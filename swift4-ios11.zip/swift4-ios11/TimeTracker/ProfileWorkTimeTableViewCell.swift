//
//  ProfileWorkTimeTableViewCell.swift
//  TimeTracker
//
//  Created by Anton on 09/02/2017.
//  Copyright © 2017 HSE. All rights reserved.
//

import UIKit

class ProfileWorkTimeTableViewCell: UITableViewCell {

    @IBOutlet weak var day1NameLabel: UILabel!
    @IBOutlet weak var day2NameLabel: UILabel!
    @IBOutlet weak var day3NameLabel: UILabel!
    @IBOutlet weak var day4NameLabel: UILabel!
    @IBOutlet weak var day5NameLabel: UILabel!
    @IBOutlet weak var day6NameLabel: UILabel!
    @IBOutlet weak var day7NameLabel: UILabel!

    
    @IBOutlet weak var day1TimeLabel: UILabel!
    @IBOutlet weak var day2TimeLabel: UILabel!
    @IBOutlet weak var day3TimeLabel: UILabel!
    @IBOutlet weak var day4TimeLabel: UILabel!
    @IBOutlet weak var day5TimeLabel: UILabel!
    @IBOutlet weak var day6TimeLabel: UILabel!
    @IBOutlet weak var day7TimeLabel: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
