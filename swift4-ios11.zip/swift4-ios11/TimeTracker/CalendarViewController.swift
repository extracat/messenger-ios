//
//  CalendarViewController.swift
//  TimeTracker
//
//  Created by Anton on 01/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class CalendarViewController: UIViewController, UIPageViewControllerDataSource, CallbackViewControllerProtocol {

    @IBOutlet weak var titleWeekDay: UILabel!
    @IBOutlet weak var titleDate: UILabel!
    @IBAction func selectPersonButton(_ sender: UIButton) {
    }
    @IBAction func toggleGridViewButton(_ sender: UIButton) {
    }
    @IBAction func pressedTodayButton(_ sender: UIButton) {
        navigateToCalendarState(getTodayCalendarState())
    }
    @IBOutlet weak var todayButton: UIButton!
    @IBOutlet weak var viewPersonActivatedBarButton: UIButton!
    @IBAction func viewPersonActivatedBarPressed(_ sender: Any) {
        if LoadedData.timeTable.viewType! != .Group {
            self.performSegue(withIdentifier: "Show Profile of Active User", sender: nil)
        }
    }
    @IBOutlet weak var viewPersonActivatedBar: UIView!

    @IBAction func closeViewPersonActivatedBar(_ sender: UIButton) {
        
        LoadedData.timeTable.viewType = .Person
        LoadedData.timeTable.viewPersonId = TimeTracker.data.loggedUserId
        LoadedData.timeTable.clearAllData()
        LoadedData.timeTable.loadTimeTableDataForWeek(calendarState.weeknum - 1)
        LoadedData.timeTable.loadTimeTableDataForWeek(calendarState.weeknum)
        LoadedData.timeTable.loadTimeTableDataForWeek(calendarState.weeknum + 1)
        removeViewPersonActivatedBar()
        updateUI()
    }

    // Weeks and days page view controllers
    var calendarPageViewController: UIPageViewController!
    var weekdaysPageViewController: UIPageViewController!
    
    let weekdayBottomBar = WeekdayBottomBar()

    // Metrics
    let weekdaysViewTopMargin = CGFloat(60) // Margin of calendar page view controller
    let weekdaysViewHeight = CGFloat(53.5)
    let calendarViewTopMargin = CGFloat(113.5) // Margin of calendar page view controller
    let tabBarViewBottomMargin = CGFloat(49)
 
    
    func alert (title: String, message: String, action: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: action, style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    // Current view state (week number and weekday)
    var calendarState = CalendarViewState(weeknum: 0, weekday: 0)
        { didSet {
            
                if (calendarState.isToday()) {
                        self.todayButton.isHidden = true
                    }
                else {
                        self.todayButton.isHidden = false
                    }
                
                setViewTitles(calendarState)
                weekdayBottomBar.setWeekday(calendarState.weekday, animate:  true)
                weekdayBottomBar.setToday(calendarState.isToday())
        }}


    var firstDisplayingWeek = 0     // First week to display in weeks page
    var lastDisplayingWeek = 0      // Last week to display in weeks page
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        LoadedData.timeTable.updateThisViewControllers.append(self)

        firstDisplayingWeek = -100   // First week to display in weeks page
        lastDisplayingWeek = 100    // Last week to display in weeks page
 
        viewPersonActivatedBar.isHidden = true
        

        calendarState = getTodayCalendarState() // Initial state
        //calendarState = CalendarViewState(weeknum: 16, weekday: 4)
            
        
        
        /////////// Setting up WeekDays Page View Controller ///////////
        
        let weekdaysPageInitialIndex = LoadedData.timeTable.getWeekPageIndex(calendarState)  //set this page to display
        self.weekdaysPageViewController = self.storyboard?.instantiateViewController(withIdentifier: "Weekdays Page View Controller") as! UIPageViewController
        self.weekdaysPageViewController.dataSource = self
        let initialContentViewController = self.pageWeekdaysAtIndex(weekdaysPageInitialIndex) as WeekdaysViewController
        let viewControllers = NSArray(object: initialContentViewController)
        self.weekdaysPageViewController.setViewControllers(viewControllers as? [UIViewController], direction: .forward, animated: true, completion: nil)
        self.weekdaysPageViewController.view.frame = CGRect(x: 0, y: weekdaysViewTopMargin, width: self.view.frame.size.width, height: weekdaysViewHeight)
        self.addChildViewController(self.weekdaysPageViewController)
        self.view.addSubview(self.weekdaysPageViewController.view)
        self.weekdaysPageViewController.didMove(toParentViewController: self)
        
        
        
       
        /////////// Setting up Calendar Page View Controller ///////////
        
        let calendarPageInitialIndex = LoadedData.timeTable.getDayPageIndex(calendarState)   //set this page to display
        
        self.calendarPageViewController = self.storyboard?.instantiateViewController(withIdentifier: "Calendar Page View Controller") as! UIPageViewController
        self.calendarPageViewController.dataSource = self
        let initialCalendarContentViewController = self.pageCalendarAtIndex(calendarPageInitialIndex) as CalendarTableViewController
        let calendarViewControllers = NSArray(object: initialCalendarContentViewController)
        self.calendarPageViewController.setViewControllers(calendarViewControllers as? [UIViewController], direction: .forward, animated: true, completion: nil)
        self.calendarPageViewController.view.frame = CGRect(x: 0, y: calendarViewTopMargin, width: self.view.frame.size.width, height: self.view.frame.size.height - calendarViewTopMargin - tabBarViewBottomMargin)
        self.addChildViewController(self.calendarPageViewController)
        self.view.addSubview(self.calendarPageViewController.view)
        self.calendarPageViewController.didMove(toParentViewController: self)
        
   

 
    }

    func navigateToCalendarState(_ newState: CalendarViewState) {
        
        let calendarPageIndex = LoadedData.timeTable.getDayPageIndex(newState)
        let weekPageIndex = LoadedData.timeTable.getWeekPageIndex(newState)
        
        var dayChanges: Bool = false
        var weekChanges: Bool = false
        
        if (newState.weeknum != calendarState.weeknum) {weekChanges = true}
        if (newState.weekday != calendarState.weekday) {dayChanges = true}
        if (weekChanges) {dayChanges = true}
        if (!weekChanges && !dayChanges) {return}
        
        
        var weekDirection = UIPageViewControllerNavigationDirection.forward
        var dayDirection = UIPageViewControllerNavigationDirection.forward
        if (newState.weeknum < calendarState.weeknum) {weekDirection = .reverse}
        if (newState.weekday < calendarState.weekday) {dayDirection = .reverse}
        if (weekChanges) {dayDirection = weekDirection}
        
        if dayChanges {
            let navigateToThisContentViewController = self.pageCalendarAtIndex(calendarPageIndex) as CalendarTableViewController
            let viewControllers = NSArray(object: navigateToThisContentViewController)
            self.calendarPageViewController?.setViewControllers(viewControllers as? [UIViewController], direction: dayDirection, animated: true, completion: nil)
        }
        
        if weekChanges {
            let navigateToThisContentViewController = self.pageWeekdaysAtIndex(weekPageIndex) as WeekdaysViewController
            let viewControllers = NSArray(object: navigateToThisContentViewController)
            self.weekdaysPageViewController?.setViewControllers(viewControllers as? [UIViewController], direction: weekDirection, animated: true, completion: nil)
        }
        
        if (weekChanges || dayChanges) {calendarState = newState}
    }
    
    func navigateToWeek(_ newWeek: Int) {
        let weekPageIndex = LoadedData.timeTable.getWeekPageIndex(CalendarViewState(weeknum: newWeek, weekday: 0))
        
        var weekChanges: Bool = false
        
        if (newWeek != calendarState.weeknum) {weekChanges = true}
        
        var weekDirection = UIPageViewControllerNavigationDirection.forward
        if (newWeek < calendarState.weeknum) {weekDirection = .reverse}
        
        if weekChanges {
            let navigateToThisContentViewController = self.pageWeekdaysAtIndex(weekPageIndex) as WeekdaysViewController
            let viewControllers = NSArray(object: navigateToThisContentViewController)
            self.weekdaysPageViewController?.setViewControllers(viewControllers as? [UIViewController], direction: weekDirection, animated: true, completion: nil)
        }
        
        if (weekChanges) {calendarState.weeknum = newWeek}
        
    }
    
    
    func navigateToDay(_ newState: CalendarViewState) {
        
        let calendarPageIndex = LoadedData.timeTable.getDayPageIndex(newState)
        
        var dayChanges: Bool = false
        var weekChanges: Bool = false
        
        if (newState.weeknum != calendarState.weeknum) {weekChanges = true}
        if (newState.weekday != calendarState.weekday) {dayChanges = true}
        if (weekChanges) {dayChanges = true}
        
        if (!dayChanges) {return}
        
        var weekDirection = UIPageViewControllerNavigationDirection.forward
        var dayDirection = UIPageViewControllerNavigationDirection.forward
        if (newState.weeknum < calendarState.weeknum) {weekDirection = .reverse}
        if (newState.weekday < calendarState.weekday) {dayDirection = .reverse}
        if (weekChanges) {dayDirection = weekDirection}
        
        if dayChanges {
            let navigateToThisContentViewController = self.pageCalendarAtIndex(calendarPageIndex) as CalendarTableViewController
            
            // the instance should know, that it's created by setViewControllers
            navigateToThisContentViewController.navigatedFromWeekPageController = true
            
            let viewControllers = NSArray(object: navigateToThisContentViewController)
            self.calendarPageViewController?.setViewControllers(viewControllers as? [UIViewController], direction: dayDirection, animated: true, completion: nil)
            
        }
        
        if (weekChanges || dayChanges) {calendarState = newState}
        
    }

    
    func setViewTitles(_ state: CalendarViewState, dateText: String? = nil) {
        
        if (dateText == nil) {
            let date = getDateFromCalendarState(state, year: getTodayYear())
            titleDate.text = contvertDateToString(date)     // Setting the subtitle of parent view controller

        } else {
            titleDate.text = dateText      // Setting the subtitle of parent view controller
        }
        
        
        titleWeekDay.text = getWeekdayNameFromNum(state.weekday) // Setting the title of parent view controller
        //titleWeekDay.text = "\(calendarState.weeknum).\(calendarState.weekday)"
    }
    
    
    
    override func viewDidLayoutSubviews() {
        //////////////////// Setup weekday bottom bar   ///////////////
        
        weekdayBottomBar.setWeekday(calendarState.weekday, animate: false)
        self.view.addSubview(weekdayBottomBar)
        
        ////////////////////////////////////////////////////////////////
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }

    
    override func viewDidAppear(_ animated: Bool) {
     
        updateUI()
        
        switch LoadedData.timeTable.viewType! {
            
            
        case .Person:
            if LoadedData.timeTable.viewPersonId != nil {
                if (TimeTracker.data.loggedUserId != LoadedData.timeTable.viewPersonId) {
                    addViewPersonActivatedBar()
                }
                else {
                    removeViewPersonActivatedBar()
                    updateUI()
                }
            }
            
            
        case .Group:
 
            if LoadedData.timeTable.viewGroupId != nil {
                    addViewPersonActivatedBar()
                }
                else {
                    removeViewPersonActivatedBar()
                    updateUI()
                }
        
        }
        
        

        
    }
    
    func updateUI(){
        
        //let calendarPageIndex = LoadedData.timeTable.getDayPageIndex(calendarState)
        //let navigateToThisContentViewController = self.pageCalendarAtIndex(calendarPageIndex) as CalendarTableViewController
        //let viewControllers = NSArray(object: navigateToThisContentViewController)
        //let dayDirection = UIPageViewControllerNavigationDirection.Forward
        //self.calendarPageViewController?.setViewControllers(viewControllers as? [UIViewController], direction: dayDirection, animated: false, completion: nil)
        
        for vc in (self.calendarPageViewController?.viewControllers)! {
            if let tvc = vc as? CalendarTableViewController {
                tvc.updateUI()
            }
         
        }
    }

    func addViewPersonActivatedBar() {
        viewPersonActivatedBar.isHidden = false
        
        switch LoadedData.timeTable.viewType! {
        case .Person:
            viewPersonActivatedBarButton.setTitle(LoadedData.timeTable.viewPersonName, for: .normal)
            viewPersonActivatedBar.backgroundColor = UIColor(hexString: "#285E97")
        case .Group:
            viewPersonActivatedBarButton.setTitle(LoadedData.timeTable.viewGroupName, for: .normal)
            viewPersonActivatedBar.backgroundColor = UIColor(hexString: "#9198A0")
        }
        
        
        let barHeight = viewPersonActivatedBar.frame.size.height - 0.5
        self.calendarPageViewController.view.frame = CGRect(x: 0, y: calendarViewTopMargin + barHeight, width: self.view.frame.size.width, height: self.view.frame.size.height - calendarViewTopMargin - tabBarViewBottomMargin - barHeight)
        
    }
    
    func removeViewPersonActivatedBar() {
        viewPersonActivatedBar.isHidden = true
        
        switch LoadedData.timeTable.viewType! {
        case .Person:
            viewPersonActivatedBarButton.setTitle(LoadedData.timeTable.viewPersonName, for: .normal)
        case .Group:
            viewPersonActivatedBarButton.setTitle(LoadedData.timeTable.viewGroupName, for: .normal)
        }
        
        let barHeight = CGFloat(0.0)
        self.calendarPageViewController.view.frame = CGRect(x: 0, y: calendarViewTopMargin + barHeight, width: self.view.frame.size.width, height: self.view.frame.size.height - calendarViewTopMargin - tabBarViewBottomMargin - barHeight)
        
    }

    

    
    
    
    
    
    
    
    
    //////////////// Page View Controller Functions ////////////////
    
    
    func pageCalendarAtIndex(_ i: Int) -> CalendarTableViewController
    {
       
        let firstDisplayingDay = LoadedData.timeTable.getDayPageIndex(CalendarViewState(weeknum: firstDisplayingWeek, weekday: 1))
        let lastDisplayingDay  = LoadedData.timeTable.getDayPageIndex(CalendarViewState(weeknum: lastDisplayingWeek, weekday: 7))

        var index = i
        if index > lastDisplayingDay {index = lastDisplayingDay}
        if index < firstDisplayingDay {index = firstDisplayingDay}
        
        // Calendar table view
        let pageContentViewController = self.storyboard?.instantiateViewController(withIdentifier: "Calendar Page Content Holder") as! CalendarTableViewController
        pageContentViewController.pageIndex = index
        pageContentViewController.calendarViewController = self
        
        return pageContentViewController
        
    }
    
    func pageWeekdaysAtIndex(_ i: Int) -> WeekdaysViewController
    {
        var index = i
        if index > lastDisplayingWeek {index = lastDisplayingWeek}
        if index < firstDisplayingWeek {index = firstDisplayingWeek}
        
        // Weekdays view
        let pageContentViewController = self.storyboard?.instantiateViewController(withIdentifier: "Weekdays Page Content Holder") as! WeekdaysViewController
        pageContentViewController.pageIndex = index
        pageContentViewController.calendarViewController = self
        
        return pageContentViewController
        
    }
    
    
    
    // Scroll page left
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
 
        if let pageViewControllerId = pageViewController.restorationIdentifier {
   
            switch pageViewControllerId {
                
            case "Calendar Page View Controller":
                
                let firstDisplayingDay = LoadedData.timeTable.getDayPageIndex(CalendarViewState(weeknum: firstDisplayingWeek, weekday: 1))
                
                let viewController = viewController as! CalendarTableViewController
                var index = viewController.pageIndex as Int
                
                if(index == firstDisplayingDay || index == NSNotFound) {return nil}
                
                index -= 1
                
                return self.pageCalendarAtIndex(index)
                
                
            case "Weekdays Page View Controller":
                
                let viewController = viewController as! WeekdaysViewController
                var index = viewController.pageIndex as Int
                
                if(index == firstDisplayingWeek || index == NSNotFound) {return nil}
                
                index -= 1

                return self.pageWeekdaysAtIndex(index)
                
                
            default:
                return nil
            }
            
            
        }
        return nil

        
        
    }
    
    
    // Scroll page right
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        if let pageViewControllerId = pageViewController.restorationIdentifier {

            switch pageViewControllerId {
                
            case "Calendar Page View Controller":
                
                let lastDisplayingDay  = LoadedData.timeTable.getDayPageIndex(CalendarViewState(weeknum: lastDisplayingWeek, weekday: 7))

                let viewController = viewController as! CalendarTableViewController
                var index = viewController.pageIndex as Int
                
                if (index == lastDisplayingDay || index == NSNotFound) {return nil}
                
                index += 1

                return self.pageCalendarAtIndex(index)
                
            case "Weekdays Page View Controller":
                
                let viewController = viewController as! WeekdaysViewController
                var index = viewController.pageIndex as Int
                
                if (index == lastDisplayingWeek || index == NSNotFound) {return nil}
                
                index += 1
                
                return self.pageWeekdaysAtIndex(index)
                
            default:
                return nil
            }
            
            
        }
        return nil
        
    }
        
    
    
    
    
    // Number of pages for our pageviewcontrollers
    
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        
        var pageCount = 0
        if let pageViewControllerId = pageViewController.restorationIdentifier {

            switch pageViewControllerId {
            case "Calendar Page View Controller":
                pageCount = (lastDisplayingWeek - firstDisplayingWeek + 1) * 7
            
            case "Weekdays Page View Controller":
                pageCount = lastDisplayingWeek - firstDisplayingWeek + 1
                
            default:
                pageCount = 0
            }
        }

        return pageCount
        
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "Show Profile of Active User" {
            if let vc = (segue.destination as? ProfileTableViewController) {
                //self.navigationController?.isNavigationBarHidden = false
     
                let backItem = UIBarButtonItem()
                backItem.title = "Расписание"
                navigationItem.backBarButtonItem = backItem
                
                vc.presenter.userId = LoadedData.timeTable.viewPersonId  
            }
        }
        
    }
    

    

}
