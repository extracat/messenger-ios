//
//  ExamModalViewController.swift
//  TimeTracker
//
//  Created by Anton on 05/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class ExamModalViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate {

    @IBAction func cancelModalView(_ recognizer: UITapGestureRecognizer) {
        if recognizer.state == .ended {
            closeModalView()    // May be we should not do this
            }
    }
    
    var tabBar: UITabBar? = nil
    var mark: String = ""
    var name: String = ""
    var projectTitle: String = ""
    var studentId: Int? = nil
    var projectId: Int? = nil
    var moduleCourseId: Int? = nil
    var vcParent: UITableViewController? = nil
    var sheetType: SheetType? = nil
    var oldMark: Int = 0
    var pickerNeverChanged: Bool = true
    
    @IBOutlet weak var examMarkPicker: UIPickerView!
    let pickerData = ["Нет оценки","4","5","6","7","8","9","10"]

    func getMark() -> Int {
        let mark = getPicker()
        
        switch mark {
            case "4":  return 4
            case "5":  return 5
            case "6":  return 6
            case "7":  return 7
            case "8":  return 8
            case "9":  return 9
            case "10": return 10
            
            default:   return 0
        }
    }
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBAction func closeModalView(_ sender: UIButton) {
        
        if pickerNeverChanged {return}
        
        let newMark = getMark()
        
        ///// SAVE DATA /////
        
        if sheetType != nil && newMark != oldMark {
            switch sheetType! {
            case .examination:
                
                if studentId != nil && moduleCourseId != nil {
                    
                    let thisParent = vcParent as? ExaminationSheetTableViewController
                    if thisParent != nil {
                        thisParent!.presenter.saveMark(moduleCourseId: moduleCourseId!, studentId: studentId!, mark: newMark)
                    }
                }
                
                
            case .prosmotr:
                
                if  projectId != nil && moduleCourseId != nil {
                    
                    let thisParent = vcParent as? ProsmotrSheetTableViewController
                    if thisParent != nil {
                        thisParent!.presenter.saveMark(moduleCourseId: moduleCourseId!, projectId: projectId!, mark: newMark)
                    }
                    
                }
                
                
            default:
                break
            }
        }
        
        /////////////////////
        
        closeModalView()
        
    }

    
    func closeModalView() {   // Closes This Modal View
        tabBar?.isHidden = false
        vcParent?.tableView.reloadData()
        self.dismiss(animated: false, completion: {}) //This is intended to dismiss the Info sceen.
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        examMarkPicker.dataSource = self
        examMarkPicker.delegate = self
        
        tabBar?.isHidden = true
        
        
        setPicker(mark)
        
        if sheetType != nil {
            switch sheetType! {
            case .examination:
                nameLabel.text? = name
            case .prosmotr:
                nameLabel.text? = projectTitle
            default:
                break
            }
        }
        
        oldMark = getMark()
       
    }

  

    
    
  

    //MARK: Data Sources
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    
    //MARK: Delegates
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        mark = pickerData[row]
        pickerNeverChanged = false
        
        let pickerMark = (getMark() == 0) ? "Нет" : String(getMark())
        
        if sheetType != nil {
            switch sheetType! {
            case .examination:
                nameLabel.text? = name + " - \(pickerMark)"
            case .prosmotr:
                nameLabel.text? = projectTitle + " - \(pickerMark)"
            default:
                break
            }
        }

    }
    
    func setPicker(_ setmark: String) {
        switch setmark {
        case "4": examMarkPicker.selectRow(1, inComponent: 0, animated: false)
        case "5": examMarkPicker.selectRow(2, inComponent: 0, animated: false)
        case "6": examMarkPicker.selectRow(3, inComponent: 0, animated: false)
        case "7": examMarkPicker.selectRow(4, inComponent: 0, animated: false)
        case "8": examMarkPicker.selectRow(5, inComponent: 0, animated: false)
        case "9": examMarkPicker.selectRow(6, inComponent: 0, animated: false)
        case "10": examMarkPicker.selectRow(7, inComponent: 0, animated: false)

        default:
            examMarkPicker.selectRow(0, inComponent: 0, animated: false)
        }
    }
    
    func getPicker() -> String {
        return mark
    }

    
    
}
