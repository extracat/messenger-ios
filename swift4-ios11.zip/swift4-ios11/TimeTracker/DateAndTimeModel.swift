//
//  DateAndTimeModel.swift
//  TimeTracker
//
//  Created by Anton on 06/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import Foundation


func getCalendar() -> Calendar {
    var calendar = Calendar(identifier: Calendar.Identifier.gregorian)
    calendar.firstWeekday = 2 // Monday (ISO 8601)
    calendar.minimumDaysInFirstWeek = 4 // First week = first Thursday (ISO 8601)
    return calendar
}


public struct DatesInterval {
    public var start: Date
    public var end: Date
    
    public static func == (left: DatesInterval, right: DatesInterval) -> Bool {
        return (left.start == right.start) && (left.end == right.end)
    }
    public static func != (left: DatesInterval, right: DatesInterval) -> Bool {
        return !(left == right)
    }
}

extension DatesInterval: Equatable {}


func getDatesIntervalForProfileStatistics() -> DatesInterval {
    
    let staticticsDate = getDateForProfileStatistics()
    let begin = staticticsDate.firstDateOfMonth()
    let end = begin.addMonths(1)
    
    return DatesInterval(start: begin, end: end)
}

func getDatesIntervalForMonth(_ month: Date) -> DatesInterval {
    
    let begin = month.firstDateOfMonth()
    let end = begin.addMonths(1)
    
    return DatesInterval(start: begin, end: end)
}

func getDateForProfileStatistics() -> Date {
    let date = Date()
    var staticticsDate = date.startOfDay()
    
    let todayDay = getTodayDay()
    if (todayDay <= 15) {
        staticticsDate = staticticsDate.addDays(-todayDay)
    }
    return staticticsDate
}



struct CalendarViewState {
    var weeknum: Int
    var weekday: Int
     
    func isToday() -> Bool {
        if (weekday == getTodayWeekday() && weeknum == getTodayWeeknum())
        {return true}
        else
        {return false}
    }

}

func == (left: CalendarViewState, right: CalendarViewState) -> Bool {
    return (left.weeknum == right.weeknum) && (left.weekday == right.weekday)
}

func != (left: CalendarViewState, right: CalendarViewState) -> Bool {
    return !(left == right)
}


func getTodayCalendarState() -> CalendarViewState {
    let todayState = CalendarViewState(weeknum: getTodayWeeknum(), weekday: getTodayWeekday())
    return todayState
}

func getTodayWeekday() -> Int {
    let date = Date()
    let calendar = getCalendar()

    let components = (calendar as NSCalendar).components(.weekday, from: date)
    let weekday = components.weekday
    return convertWeekdayToRussian(weekday!)
}


func getTodayWeeknum() -> Int {
    let date = Date()
    let calendar = getCalendar()
    
    let componentWeekOfYear = (calendar as NSCalendar).components(.weekOfYear, from: date)
    //let componentYearForWeekOfYear = calendar.components(.YearForWeekOfYear, fromDate: date)
    
    let week = componentWeekOfYear.weekOfYear
    //let year = componentYearForWeekOfYear.yearForWeekOfYear

    return week!
}

func getTodayDay() -> Int {
    let date = Date()
    let calendar = getCalendar()

    let components = (calendar as NSCalendar).components(.day, from: date)
    return components.day!
    
}
func getDay(_ date: Date) -> Int {

    let calendar = getCalendar()
    
    let components = (calendar as NSCalendar).components(.day, from: date)
    return components.day!
}

func getMonth(_ date: Date) -> Int {

    let calendar = getCalendar()
    
    let components = (calendar as NSCalendar).components(.month, from: date)
    return components.month!

}

func getYear(_ date: Date) -> Int {

    let calendar = getCalendar()
    
    let components = (calendar as NSCalendar).components(.year, from: date)
    return components.year!
}


func getTodayMonth() -> Int {
    let date = Date()
    let calendar = getCalendar()

    let components = (calendar as NSCalendar).components(.month, from: date)
    return components.month!
}
func getTodayYear() -> Int {
    let date = Date()
    let calendar = getCalendar()

    let components = (calendar as NSCalendar).components(.year, from: date)
    return components.year!
}

func getDateFromCalendarState(_ state: CalendarViewState, year: Int) -> Date {
    let calendar = getCalendar()
    
    var dateComponents = DateComponents()
    dateComponents.weekOfYear = state.weeknum
    dateComponents.yearForWeekOfYear = year
    dateComponents.weekday = convertWeekdayToAmerican(state.weekday)
   
    return calendar.date(from: dateComponents)!
}

func getCalendarStateFromDate (_ date: Date) -> CalendarViewState {
    let calendar = getCalendar()
    
    let componentWeekDay = (calendar as NSCalendar).components(.weekday, from: date)
    let componentWeekOfYear = (calendar as NSCalendar).components(.weekOfYear, from: date)
    let componentYearForWeekOfYear = (calendar as NSCalendar).components(.yearForWeekOfYear, from: date)
    
    let year = componentYearForWeekOfYear.yearForWeekOfYear
    let firstWeekOfYear = getDateFromCalendarState(CalendarViewState(weeknum:1, weekday:1), year: year!)
    let firstWeekOfThisYear = getDateFromCalendarState(CalendarViewState(weeknum:1, weekday:1), year: getTodayYear())
    let weeksOffset = firstWeekOfYear.weeksFrom(firstWeekOfThisYear)
    
    let weekday = convertWeekdayToRussian(componentWeekDay.weekday!)
    let weeknum = componentWeekOfYear.weekOfYear! + weeksOffset
    
    return CalendarViewState(weeknum: weeknum, weekday: weekday)
}


func convertWeekdayToRussian(_ crazyWeekDay: Int) -> Int
{
    if (crazyWeekDay >= 2) {
        return crazyWeekDay - 1
    } else {
        return 7
    }
}

func convertWeekdayToAmerican(_ normalWeekDay: Int) -> Int
{
    if (normalWeekDay <= 6) {
        return normalWeekDay + 1
    } else {
        return 1
    }
}

func convertWeekdayToJsonWeekDay(_ normalWeekDay: Int) -> JsonWeekDay
{
    if (normalWeekDay == 7) {
        return JsonWeekDay.Sunday
    } else {
        let jsonWeekDay = JsonWeekDay(rawValue: normalWeekDay)
        if jsonWeekDay != nil {
            return jsonWeekDay!
        }
        else {
            return JsonWeekDay.UnSupported
        }
    }
}

extension Date {
    func isGreaterThanDate(_ dateToCompare: Date) -> Bool {
        //Declare Variables
        var isGreater = false
        
        //Compare Values
        if self.compare(dateToCompare) == ComparisonResult.orderedDescending {
            isGreater = true
        }
        
        //Return Result
        return isGreater
    }
    
    func isLessThanDate(_ dateToCompare: Date) -> Bool {
        //Declare Variables
        var isLess = false
        
        //Compare Values
        if self.compare(dateToCompare) == ComparisonResult.orderedAscending {
            isLess = true
        }
        
        //Return Result
        return isLess
    }
    
    func equalToDate(_ dateToCompare: Date) -> Bool {
        //Declare Variables
        var isEqualTo = false
        
        //Compare Values
        if self.compare(dateToCompare) == ComparisonResult.orderedSame {
            isEqualTo = true
        }
        
        //Return Result
        return isEqualTo
    }
    
    func addMonths(_ monthsToAdd: Int) -> Date {
        let dateWithMonthsAdded = Calendar.current.date(byAdding: .month, value: monthsToAdd, to: self)

        //Return Result
        return dateWithMonthsAdded!
        
    }
    
    func addDays(_ daysToAdd: Int) -> Date {
        let secondsInDays: TimeInterval = Double(daysToAdd) * 60 * 60 * 24
        let dateWithDaysAdded: Date = self.addingTimeInterval(secondsInDays)
        
        //Return Result
        return dateWithDaysAdded
    }
    
    func addHours(_ hoursToAdd: Int) -> Date {
        let secondsInHours: TimeInterval = Double(hoursToAdd) * 60 * 60
        let dateWithHoursAdded: Date = self.addingTimeInterval(secondsInHours)
        
        //Return Result
        return dateWithHoursAdded
    }
    
    func addMinutes(_ minutesToAdd: Int) -> Date {
        let secondsInMinutes: TimeInterval = Double(minutesToAdd) * 60
        let dateWithMinutesAdded: Date = self.addingTimeInterval(secondsInMinutes)
        
        //Return Result
        return dateWithMinutesAdded
    }
    
    func weeksFrom(_ date: Date) -> Int {
        return (Calendar.current as NSCalendar).components(.weekOfYear, from: date, to: self, options: []).weekOfYear!
    }
    
    
    func firstDateOfMonth() -> Date {
        let day = getDay(self)
        return self.addDays(1 - day).startOfDay()
    }
    
    func lastDateOfMonth() -> Date {
        return self.firstDateOfMonth().addMonths(1).addDays(-1).startOfDay()
    }
    
    func startOfDay() -> Date {
        let calendar = getCalendar()
        return calendar.startOfDay(for: self)
    }


}

