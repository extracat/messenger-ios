//
//  AboutViewController.swift
//  TimeTracker
//
//  Created by Anton on 25/07/16.
//  Copyright © 2016 HSE. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController, UIWebViewDelegate {

    @IBOutlet weak var aboutWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let htmlFile = Bundle.main.path(forResource: "about", ofType: "html")
        let htmlString = try? String(contentsOfFile: htmlFile!, encoding: String.Encoding.utf8)
        aboutWebView.loadHTMLString(htmlString!, baseURL: nil)
        
    }

    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        if (request.url?.scheme == "mailto"){
            UIApplication.shared.openURL(request.url!)
        }
        return true
    }
   
}
